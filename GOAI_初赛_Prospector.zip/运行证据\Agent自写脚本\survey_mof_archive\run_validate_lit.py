# 自定义文献证据链验证 v2：论文块级匹配（块内材料×性质共现）+ 材料家族名
import json, re, os, sys
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0, os.getcwd())
sys.path.insert(0, "D:/@GOAI")
from literature_agent.discovery import DiscoveryHypothesis

OUT = Path("workspace/outputs/literature_survey/discovery")

source_text = ""
for cand in ("workspace/outputs/literature_survey/knowledge_graph.md",
             "workspace/outputs/literature_survey/paper_summaries.md"):
    p = Path(cand)
    if p.exists():
        source_text += p.read_text(encoding="utf-8", errors="replace") + "\n"
for md in sorted(Path("workspace/data/papers").glob("*.md")):
    source_text += md.read_text(encoding="utf-8", errors="replace") + "\n"

_LIT_PROPERTY_KWS = {
    "容量": ["capacity", "uptake", "loading", "mmol/g", "mol/kg", "容量"],
    "吸附": ["adsorption", "uptake", "capture", "isotherm", "吸附"],
    "选择性": ["selectivity", "separation factor", "选择性"],
    "焓": ["isosteric heat", "qst", "enthalpy", "kj/mol", "吸附热"],
    "效率": ["efficiency", "amine efficiency", "效率"],
    "稳定性": ["stability", "degradation", "cyclability", "稳定"],
    "再生": ["regeneration", "working capacity", "energy", "再生"],
    "循环": ["cyclability", "cycle", "working capacity", "循环"],
    "湿度": ["relative humidity", "rh", "humid", "water", "h2o", "湿度", "湿态"],
    "孔径": ["pore size", "aperture", "pore", "å", "nm", "孔径"],
    "压力": ["pressure", "bar", "kpa", "压力"],
    "缺陷": ["defect", "formate", "missing linker", "missing cluster", "缺陷", "甲酸"],
    "工作容量": ["working capacity", "工作容量"],
    "温度": ["temperature", "温度"],
}
PAPER_RE = re.compile(r'\b(p\d{1,3})\b')
VALUE_RE = re.compile(r'(\d+(?:\.\d+)?)\s*(mmol/g|mol/kg|mmol/cm3|mg/g|kJ/mol|m2/g|bar|K|%|eV)', re.I)
FAMILY_RE = re.compile(r'(mof[- ]?74|zif[- ]?\d+|uio[- ]?\d+|mil[- ]?\d+|hkust[- ]?\d+|dobpdc|dobdc|sifsix|tifsix|calf[- ]?20)', re.I)

def material_tokens(materials):
    toks = set()
    for m in materials[:6]:
        full = (m or "").strip().lower()
        if len(full) >= 3:
            toks.add(full)
        for part in re.split(r'[/\s,，、()（）]+', full):
            if len(part) >= 3:
                toks.add(part)
            fam = FAMILY_RE.search(part)
            if fam:
                toks.add(fam.group(1).replace(" ", "-"))
    return sorted(toks)

def property_keywords(prop):
    t = (prop or "").lower()
    kws = []
    for key, aliases in _LIT_PROPERTY_KWS.items():
        if key in t or t in key:
            kws.extend(aliases)
    if not kws:
        kws = [w for w in re.split(r'[\s/]+', t) if len(w) >= 3][:3]
    return kws

def split_blocks(text):
    """按论文块（## p\d+ 标题）和知识图谱小节（### 标题）切分，尽量保持论文独立性"""
    blocks = re.split(r'\n(?=#{1,3} )', text)
    return [b for b in blocks if len(b.strip()) > 30]

def evaluate(hyp):
    toks = material_tokens(hyp.materials)
    kws = property_keywords(hyp.property)
    blocks = split_blocks(source_text)
    paper_hits = set()
    value_hits = []
    for block in blocks:
        bl = block.lower()
        mat_hit = any(t in bl for t in toks)
        if not mat_hit:
            continue
        kw_hit = any(k in bl for k in kws)
        if not kw_hit:
            continue
        # 提取该块引用的论文 ID（块标题或正文）
        ids = PAPER_RE.findall(block)
        if ids:
            paper_hits.update(ids)
        else:
            # 无显式 ID 的块（如摘要块）→ 从标题行推断
            for line in block.splitlines()[:3]:
                m = re.match(r'#+\s*(p\d{1,3})', line.strip())
                if m:
                    paper_hits.add(m.group(1))
        for vm in VALUE_RE.finditer(block):
            v = abs(float(vm.group(1)))
            if 0 < v < 1e6:
                value_hits.append(v)
    value_hits = sorted(set(round(v, 3) for v in value_hits))[:20]
    return paper_hits, value_hits, toks, kws

with open(OUT / "hypotheses.json", encoding="utf-8") as f:
    hypotheses_data = json.load(f)

for idx, hdata in enumerate(hypotheses_data):
    hyp = DiscoveryHypothesis(**{k: v for k, v in hdata.items()
                                 if k in DiscoveryHypothesis.__dataclass_fields__})
    paper_hits, value_hits, toks, kws = evaluate(hyp)
    if len(paper_hits) >= 2:
        status = "literature_supported"
        note = f"文献证据链：{len(paper_hits)} 篇独立论文（{sorted(paper_hits)}）"
    elif len(paper_hits) == 1:
        status = "inconclusive"
        note = f"仅 1 篇独立论文支撑（{sorted(paper_hits)}），证据不足"
    else:
        status = "pending"
        note = "未找到材料×性质共现的论文证据"
    hyp.validation_status = status
    hyp.external_validation = {
        "overall_match": status == "literature_supported",
        "validation_source": "literature",
        "validation_notes": [note],
        "databases_checked": [],
        "supporting_evidence": [f"papers: {sorted(paper_hits)}", f"values: {value_hits[:8]}"],
        "details": {},
    }
    hypotheses_data[idx] = asdict(hyp)
    print(f"hyp[{idx}] {hyp.title[:36]} | {status} | 论文={len(paper_hits)} {sorted(paper_hits)[:6]} | 数值={len(value_hits)}")

with open(OUT / "hypotheses.json", "w", encoding="utf-8") as f:
    json.dump(hypotheses_data, f, ensure_ascii=False, indent=2)
print("文献证据链验证 v2 完成")
