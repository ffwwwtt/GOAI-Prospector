# -*- coding: utf-8 -*-
"""将 search_results.json 转为 papers.json：去重、按 DOI 唯一化、过滤无摘要论文"""
import json, hashlib

with open('workspace/data/literature_cache/search_results.json', 'r', encoding='utf-8') as f:
    results = json.load(f)

seen = {}
for r in results:
    doi = (r.get('doi') or '').strip().lower()
    title = (r.get('title') or '').strip()
    abstract = r.get('abstract') or ''
    if not abstract or len(abstract) < 200:
        continue
    key = doi if doi else hashlib.md5(title.encode()).hexdigest()[:16]
    if key in seen:
        # 保留分数更高的一条
        if r.get('score', 0) > seen[key].get('score', 0):
            seen[key] = r
    else:
        seen[key] = r

papers = {}
for i, (key, r) in enumerate(sorted(seen.items(), key=lambda kv: -kv[1].get('score', 0)), 1):
    pid = f"p{i}"
    authors = r.get('authors') or []
    if not authors:
        raw = r.get('raw_metadata') or {}
        authors = [a.get('name') for a in raw.get('author', [])]
    papers[pid] = {
        'title': r.get('title') or '',
        'authors': authors,
        'abstract': r.get('abstract') or '',
        'year': r.get('year') or (r.get('raw_metadata') or {}).get('publication_published_year'),
        'doi': r.get('doi') or '',
        'source': r.get('source') or '',
        'score': r.get('score', 0),
        'keywords': r.get('keywords') or [],
    }

with open('workspace/data/literature_cache/papers.json', 'w', encoding='utf-8') as f:
    json.dump(papers, f, ensure_ascii=False, indent=1)

print(f"total results: {len(results)}, unique papers with abstract: {len(papers)}")
# 打印前 30 篇标题，方便快速了解
for pid, p in list(papers.items())[:30]:
    print(pid, '|', p['title'][:90], '| DOI:', p['doi'][:40])
