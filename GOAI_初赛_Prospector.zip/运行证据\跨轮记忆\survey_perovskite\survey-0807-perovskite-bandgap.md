# 调研记忆：卤化物钙钛矿太阳能电池带隙稳定性

## 调研：[halide perovskite solar cells band gap stability]
日期：2025-08-XX

### 检索策略
- 检索词：halide perovskite band gap stability / mixed halide phase segregation photoinduced / CsPbI3 alpha phase stability / FAPbI3 thermal decomposition / band gap tuning composition engineering
- 数据源：sciverse(80) + arxiv(16)，共 96 篇唯一论文，年份 2016–2024，捕获效率 95%
- 深度阅读：p26（热力学带隙模型全文）、p55（CsPbI3 尺寸效应）、p53（组分工程）

### 知识图谱摘要
- 材料数：6（混合卤化物 MAPb/FA/CsPb(I,Br)₃、CsPbI₃、FAPbI₃、CsₓFA₁₋ₓPb(Br,I)₃、Pb-Sn、双钙钛矿）
- 性质数：5（带隙、光致分离阈值、混合焓、相稳定性、漂移动力学）
- 关键关系数：6（带隙可调↔分离倾向、A位→稳定性权衡、尺寸↓→稳定↑带隙↑、激发强度→分离程度、Cl⁻→抑制分离、Cs含量↑→光稳定↑）

### Top 研究空白
1. A 位 Cs vs X 位 Br 的带隙-稳定性权衡矛盾 — 高 — 0.7
   证据：p53（Cs 替代优于 Br）vs p26（CsPb 混合焓 45>MA 39 meV）
   验证方案：固定带隙（1.7 eV）对比分离阈值与速率
2. 带隙漂移动力学标度律缺失 — 高 — 0.8
   证据：p26（模型已就绪但无动力学数据）、p42
   验证方案：时间分辨 PL 提取速率 vs x_Br/I_exc/T
3. CsPbI₃ 稳定化策略带隙偏移未系统量化 — 中 — 0.75
   证据：p46/p50/p51/p58/p60/p64/p65
   验证方案：统一条件掺杂-带隙-稳定性三元图谱

### 发现结果（路线 A）
1. hyp[2] 固定带隙下 A 位 Cs vs X 位 Br 动力学权衡 — inconclusive（conf 0.70，贝叶斯搜索 41 候选，LLM 引导 4 次）
2. hyp[0] 带隙漂移速率标度律 — literature_supported（conf 0.65，LLM 引导 8 次）
3. hyp[4] 2D RP 间隔阳离子链长非单调关系 — inconclusive（new，novelty 0.80）
4. hyp[1]/hyp[3] — literature_supported（复现类）

### 反思
- 最令人惊讶：p53 与 p26 的"表面矛盾"——A 位无机化提高表观光稳定，但混合焓反而更大，说明动力学（载流子寿命/扩散）而非热力学主导分离，这是高价值假说
- 最高效搜索方向：mixed halide phase segregation（20 篇直接命中核心机制）
- 下一轮迭代：补充 2D RP 体系与 Sn 基体系的全文数据，充实 hyp[4] 验证；用 run_model_comparison 量化 Cs/Br 权衡
