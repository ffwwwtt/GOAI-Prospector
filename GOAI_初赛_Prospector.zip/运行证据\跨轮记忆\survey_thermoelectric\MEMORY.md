# Agent Experiment Memory — survey
- [热电材料 ZT 优化调研](survey-0802-热电材料.md) — 140 篇文献；核心发现：κ_L/κ≈0.5 PGEC 普适描述符（literature_supported）；Top Gap：κ_L/κ 跨体系验证 + SnSe ZT=2.6 争议；4 条假设已验证（2 supported / 1 inconclusive / 1 supported）

