# 调研记忆：热电材料 ZT 优化

## 检索策略
- 检索词（10 轮）：thermoelectric ZT optimization / PbTe band convergence / lattice thermal conductivity nanostructuring / SnSe single crystal / skutterudite filling / half-Heusler ZT / Mg3Sb2 / machine learning thermoelectric / Bi2Te3 room temperature / Cu2Se GeTe
- 数据源：sciverse(96) + arxiv(44)；年份 2011–2026；唯一论文 140 篇

## 知识图谱摘要（workspace/outputs/literature_survey/knowledge_graph.md）
- 材料数：27（SnSe、PbTe/SnTe、Skutterudite、HH、Mg3Sb2、GeTe、Cu2Se/Ag2Se、Bi2Te3 等）
- 性质数：35 条数值记录（ZT、κ_L、κ_L/κ、PF、载流子浓度、位错密度等）
- 关键关系数：5（能带汇聚、声子散射、PGEC κ_L/κ、载流子浓度、各向异性织构）

## Top 研究空白
1. κ_L/κ≈0.5 PGEC 描述符跨体系普适性 — 严重度：高 — 置信度 0.75
   证据：p19（仅 CoSb3/GeTe 两案例），p27, p48
   验证方案：跨体系统计 ZT vs κ_L/κ 倒 U 型峰值位置
2. SnSe 单晶 ZT=2.6 真实性争议 — 严重度：高 — 置信度 0.7
   证据：p48 vs p57/p59（密度/热容测量质疑）
   验证方案：全致密样品重新测量 κ(T)/C_p(T)
3. ML 预测（R²0.9+）vs 实验验证鸿沟 — 严重度：高 — 置信度 0.7
   证据：p1, p116, p19
   验证方案：直接预测 vs 分通道预测范式对比

## 发现结果（路线 A）
1. κ_L/κ≈0.5 描述符跨体系普适性 — literature_supported（conf 0.75）
   材料：跨体系（CoSb3→0.65, GeTe→0.44 等 6 样本）
   性质：ZT vs κ_L/κ 倒 U 型
   外部验证：文献证据链（p19 核心 + p27/p48 机理支持）；Materials Project 命中 3
2. 分通道预测缩小 ML 鸿沟 — inconclusive（conf 0.70）
3. 能带汇聚最优窗口 — literature_supported（conf 0.60）
4. 平均 ZT 替代峰值 ZT 指标 — literature_supported（conf 0.60）

## 反思
- 最令人惊讶的发现：κ_L/κ≈0.5 的普适性——CoSb3（0.95→0.65）与 GeTe（0.26→0.44）两个物理上相反的优化方向都收敛到同一描述符，说明 PGEC 不仅是概念而是可操作的设计罗盘
- 最高效搜索方向：'SnSe single crystal'（命中 Nature/Science 经典）、'machine learning thermoelectric'（命中 p19 描述符工作）
- 下一轮迭代应聚焦：扩充 κ_L/κ 定量样本（从更多体系提取），补足 run_model_comparison 数据；对 hyp[1] 分通道预测范式做元分析验证
