"""将 search_results.json 转换为 papers.json + papers_text.json 供 extract_knowledge 使用"""
import json, hashlib, os

cache_dir = "workspace/data/literature_cache"
with open(os.path.join(cache_dir, "search_results.json"), "r", encoding="utf-8") as f:
    results = json.load(f)

# 兼容不同结构：可能是 {"queries": {...}} 或 list
if isinstance(results, dict) and "queries" in results:
    items = []
    for q, papers in results["queries"].items():
        for p in papers:
            items.append(p)
elif isinstance(results, dict) and "results" in results:
    items = results["results"]
elif isinstance(results, list):
    items = results
else:
    # 尝试按任意键取列表
    items = []
    for v in results.values():
        if isinstance(v, list):
            items.extend(v)

# 去重（按 DOI 或 标题）
seen = {}
for p in items:
    if not isinstance(p, dict):
        continue
    doi = p.get("doi", "") or ""
    title = p.get("title", "") or ""
    key = doi if doi else title.lower().strip()
    if not key:
        continue
    if key not in seen:
        seen[key] = p

papers = {}
papers_text = {}
for i, (key, p) in enumerate(seen.items(), 1):
    pid = f"p{i}"
    title = p.get("title", "N/A")
    authors = p.get("authors", [])
    if isinstance(authors, list):
        authors_str = ", ".join(str(a) for a in authors[:8])
    else:
        authors_str = str(authors)
    abstract = p.get("abstract", "") or p.get("summary", "") or ""
    source = p.get("source", "")
    score = p.get("score", 0)
    year = p.get("year", "") or p.get("published", "")
    papers[pid] = {
        "title": title,
        "authors": authors_str,
        "abstract": abstract,
        "source": source,
        "doi": p.get("doi", ""),
        "score": score,
        "year": year,
    }
    papers_text[pid] = f"Title: {title}\nAuthors: {authors_str}\nAbstract: {abstract}"

with open(os.path.join(cache_dir, "papers.json"), "w", encoding="utf-8") as f:
    json.dump(papers, f, ensure_ascii=False, indent=2)
with open(os.path.join(cache_dir, "papers_text.json"), "w", encoding="utf-8") as f:
    json.dump(papers_text, f, ensure_ascii=False, indent=2)

print(f"Total unique papers: {len(papers)}")
sources = {}
for p in papers.values():
    s = p["source"]
    sources[s] = sources.get(s, 0) + 1
print("Sources:", sources)
