# 将 search_results.json 转换为 papers.json（paper_id -> title + abstract 文本）
import json, os

cache_dir = "workspace/data/literature_cache"
os.makedirs(cache_dir, exist_ok=True)

with open(os.path.join(cache_dir, "search_results.json"), "r", encoding="utf-8") as f:
    results = json.load(f)

# 结果结构可能是 list of dict 或 dict of queries
papers = {}
if isinstance(results, dict):
    # 可能是 {"query1": [papers...], ...} 或 {"papers": [...]}
    items = []
    for k, v in results.items():
        if isinstance(v, list):
            items.extend(v)
        elif isinstance(v, dict) and "papers" in v:
            items.extend(v["papers"])
    results = items

seen_titles = {}
idx = 1
for p in results:
    if not isinstance(p, dict):
        continue
    title = p.get("title", "") or p.get("Title", "") or ""
    abstract = p.get("abstract", "") or p.get("Abstract", "") or ""
    doi = p.get("doi", "") or p.get("DOI", "") or ""
    source = p.get("source", "") or p.get("Source", "") or ""
    if not title:
        continue
    tkey = title.lower().strip()
    if tkey in seen_titles:
        continue
    seen_titles[tkey] = idx
    pid = f"p{idx}"
    papers[pid] = {
        "title": title,
        "abstract": abstract,
        "doi": doi,
        "source": source,
    }
    idx += 1

# 同时输出纯文本版本供 extract_knowledge 使用
papers_text = {}
for pid, info in papers.items():
    txt = f"Title: {info['title']}\n"
    if info.get("doi"):
        txt += f"DOI: {info['doi']}\n"
    if info.get("abstract"):
        txt += f"Abstract: {info['abstract']}"
    papers_text[pid] = txt

with open(os.path.join(cache_dir, "papers.json"), "w", encoding="utf-8") as f:
    json.dump(papers, f, ensure_ascii=False, indent=2)

with open(os.path.join(cache_dir, "papers_text.json"), "w", encoding="utf-8") as f:
    json.dump(papers_text, f, ensure_ascii=False, indent=2)

print(f"总论文数: {len(papers)}")
print("已保存 papers.json 和 papers_text.json")
