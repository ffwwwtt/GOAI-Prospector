# -*- coding: utf-8 -*-
"""打印关键论文的完整摘要（按 score 排序的前 N 篇），便于阅读分析"""
import json

with open('workspace/data/literature_cache/papers.json', 'r', encoding='utf-8') as f:
    papers = json.load(f)

# 按 score 排序
sorted_papers = sorted(papers.items(), key=lambda kv: -kv[1].get('score', 0))

for pid, p in sorted_papers[:45]:
    print(f"\n{'='*100}")
    print(f"[{pid}] {p['title']}")
    print(f"DOI: {p['doi']} | Year: {p['year']} | Score: {p['score']}")
    print(f"Abstract: {p['abstract'][:1200]}")
