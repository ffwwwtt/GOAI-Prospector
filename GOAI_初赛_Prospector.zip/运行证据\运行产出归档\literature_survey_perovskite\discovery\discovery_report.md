# Structure-Property Relationship Discovery

**Generated:** 2026-08-02 14:05
**Total candidates explored:** 82
**Validated:** 0 | **Refuted:** 0
**Literature supported:** 3 | **Inconclusive:** 2 | **Pending:** 0
**Materials Project hits:** 0

## Search Summary

Explored 5 hypotheses via Bayesian optimization and MCTS; literature-supported 3. Model comparison available (hyp[3], n=13).

---

## Discovered Structure-Property Relationships

### 1. ❓ 2D RP混合卤化物钙钛矿间隔阳离子链长与带隙稳定性的非单调关系｜新知/已知：🆕 全新

**Confidence:** 0.50 | **Novelty:** 0.80 | **LLM Plausibility:** 0.50

**Description:** 合成间隔阳离子链长n=2、4、6、8的准2D混合卤化物钙钛矿薄膜（通式(RNH3)2FA2Pb3(I0.6Br0.4)10，R=CnH2n+1），在相同光强和温度下测量PL峰位漂移速率与暗态恢复速率，建立间隔阳离子结构参数与带隙稳定性的定量关系。

**Expected Relationship:** 间隔阳离子链长对带隙漂移速率呈U形关系：中等链长（n≈4）因有机层致密性最高而最有效阻挡卤化物迁移；过长链使层间范德华空隙增大、晶格柔软，反而促进离子重排；短链的量子限域增强会增加局域载流子密度，可能加速相分离。

**Materials:** 丁胺间隔准2D钙钛矿, 己胺间隔准2D钙钛矿, 辛胺间隔准2D钙钛矿
**Property:** 光致带隙漂移速率与暗态恢复速率

**Source Gap:** Gap 5
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p31
  - p36

**Scientific Explanation (LLM):**
> 我们只需要输出解释文本，3-5句中文科学解释，涵盖机制、文献关系、失效边界。不要编造数值。注意标题说非单调关系，预期关系是U形：中等链长最有效阻挡，过长链空隙大促进迁移，短链量子限域增强加速相分离。需要作为材料科学研究者写解释。注意“丁胺间隔准2D钙钛矿”丁胺链长n=4？丁胺是C4，己胺C6，辛胺C8。预期关系说中等链长（n≈4）最有效，那丁胺是n=4，己胺n=6，辛胺n=8。所以U形：n=4最低，n=6高？n=8更高？但说“过长链使层间范德华空隙增大”，n=6和8都是过长？短链指什么？丁胺是中等？有点矛盾。或许这里的n是指碳数？丁胺n=4，己胺n=6，辛胺n=8。预期说中等链长n≈4，那么短链可能指更短？但材料只有这三种，所以U形可能是丁胺最低，己胺和辛胺都高？或者“短链的量子限域增强”可能指更短的链如甲胺？但材料中没有。需要按给出的预期关系来写，不要纠结。注意“间隔阳离子链长对带隙漂移速率呈U形关系：中等链长（n≈4）因有机层致密性最高而最有效阻挡卤化物迁移；过长链使层间范德华空隙增大、晶格柔软，反而促进离子重排；短链的量子限域增强会增加局域载流子密度，可能加速相分离。”所以U形意

**External Validation:**
  - overall_match: False
  - validation_source: none
  - validation_notes: ['未找到任何数据库记录与文献证据支撑。']
  - databases_checked: []
  - supporting_evidence: []
  - details: {}

---

### 2. ❓ 固定带隙下A位Cs与X位Br对光稳定性的动力学权衡机制｜新知/已知：🟡 部分已知

**Confidence:** 0.70 | **Novelty:** 0.54 | **LLM Plausibility:** 0.70

**Description:** 设计两组带隙均约为1.7 eV的钙钛矿组分：一组A位Cs高/Br低，另一组A位Cs低/Br高，在相同激发强度、温度和气氛下追踪PL峰位漂移。对比p26给出的热力学混合焓与p53的光稳定性结论，判断光稳定性由热力学还是动力学主导。

**Expected Relationship:** 尽管含Cs组分的Br/I混合焓更高（热力学上更易分离），其光致分离速率仍更低且阈值强度更高；原因是Cs替代缩短载流子扩散长度和寿命，降低局域光生载流子密度，从而在动力学上抑制分离。该结果将证实光稳定性由动力学因素而非热力学混合焓直接决定。

**Materials:** A位Cs高、Br低的Cs/FA钙钛矿薄膜, A位Cs低、Br高的Cs/FA钙钛矿薄膜
**Property:** 光致卤化物分离的阈值激发强度与分离速率

**Source Gap:** Gap 3
**Search Method:** bayesian (30 iterations, 41 candidates)

**Evidence Chain:**
  - p26
  - p53

**Scientific Explanation (LLM):**
> 该假设的机制核心在于：光致卤化物分离不仅取决于热力学混合焓，更取决于光生载流子对离子迁移的驱动强度；A位Cs替代会缩短载流子扩散长度和寿命，使光生载流子更局域化于浅表层，但总体上降低了有效参与离子迁移的局域载流子密度与能量馈入速率，从而在动力学上抑制了分离速率并提高了触发分离所需的激发强度。这一观点与现有文献中“组分调控可改变卤化物分离热力学驱动力”的主流认知形成互补，但不完全一致，它强调在固定带隙情况下，即使Cs-rich组分具有更高的Br/I混合焓、热力学上更易分离，其光稳定性仍可因动力学限制而优于Br-rich组分，因此构成了对“热力学决定光稳定性”这一简化判断的修正或深化。该关系的失效边界可能出现在低激发强度或长时间稳态光照下，此时光生载流子密度不足或离子迁移达到准平衡，热力学混合焓的差异可能重新主导分离倾向；此外，若Cs替代同时引入额外缺陷态或改变薄膜微观结构与晶界密度，载流子局域化可能反而增强局部离子迁移，使动力学抑制效果被抵消。

**External Validation:**
  - overall_match: False
  - validation_source: none
  - validation_notes: []
  - databases_checked: ['literature']
  - supporting_evidence: []
  - details: {'literature': {'match': False, 'support_level': 'literature', 'papers': ['p26'], 'values': [39.0, 45.0, 103.0, 136.0], 'note': '仅 1 篇独立论文支撑，不足以判定'}}

---

### 3. 📚 混合卤化物钙钛矿带隙漂移速率的激发-温度-组分标度律｜新知/已知：🟡 部分已知

**Confidence:** 0.65 | **Novelty:** 0.51 | **LLM Plausibility:** 0.75

**Description:** 系统测量CsxFA1-xPb(I1-yBry)3系列薄膜在不同激发光强I_exc、温度T和Br含量y下的时间分辨PL峰位漂移，提取正向漂移速率常数k_drift和暗态恢复速率常数k_recovery。假设二者满足 k = A·I_exc^β·y^γ·exp(-E_a/k_BT)，并检验E_a随Cs含量x增大而增大的规律。

**Expected Relationship:** k_drift随激发光强和Br含量增大而增大，随温度升高按Arrhenius形式指数增大；A位Cs含量升高会增大卤化物迁移活化能，从而降低k_drift。原因是光生载流子与卤化物空位耦合驱动离子迁移，Br含量增大提高相分离热力学驱动力，而Cs导致的晶格收缩提高离子迁移势垒。

**Materials:** CsxFA1-xPb(I1-yBry)3薄膜, CsPb(I1-yBry)3薄膜
**Property:** 光致带隙漂移速率常数 k_drift 与暗态恢复速率常数 k_recovery

**Source Gap:** Gap 1
**Search Method:** bayesian (30 iterations, 41 candidates)

**Evidence Chain:**
  - p26
  - p32
  - p37
  - p38
  - p42

**Scientific Explanation (LLM):**
> 该构效关系在机制上成立，是因为光生载流子与卤化物空位间的耦合可降低离子迁移的活化能，而激发光强增强提供了更多非平衡载流子，从而加速卤化物迁移驱动的带隙漂移；同时，Br含量增大提高了混卤相分离的热力学驱动力，使富Br与富I区域更容易形成，因而表现为漂移速率常数增大；温度升高通过Arrhenius型热激活过程增强离子跳跃频率，而A位引入Cs引起晶格收缩，增大了卤化物迁移的几何阻碍与势垒，故抑制了漂移。已有文献对混合卤化物钙钛矿中的光致相分离、离子迁移活化能以及A位组分对晶格刚性的影响均有大量报道，因此该假设属于对已知机制的整合与标度关系的提出，但具体标度律形式和多因素耦合的定量表达式尚属新知。该关系的失效边界可能出现在极低光强下热恢复主导、组分接近纯Br或纯I端元使相分离驱动力消失、超高激发密度下载流子局域化或复合路径改变，以及温度过高导致结构相变或化学分解，这些条件下离子迁移与带隙漂移不再遵循上述标度律。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['literature']
  - supporting_evidence: []
  - details: {'literature': {'match': True, 'support_level': 'literature', 'papers': ['p26', 'p4', 'p53', 'p55', 'p64'], 'values': [1.1, 1.68, 1.75, 1.88, 2.0, 5.6, 10.0, 14.0, 14.8, 16.3, 17.0, 17.4, 18.0, 20.3, 

---

### 4. 📚 α-CsPbI3稳定化策略的带隙偏移与稳定性增益定量关联｜新知/已知：🔁 已有文献报道

**Confidence:** 0.60 | **Novelty:** 0.24 | **LLM Plausibility:** 0.70

**Description:** 在α-CsPbI3中分别采用Mn/Bi/Na元素掺杂以及PEO/两性离子添加剂策略制备薄膜，在统一条件下测量XRD相稳定性（相变温度或长期相保持时间）和UV-Vis带隙变化ΔEg。建立ΔEg与稳定性增益之间的标度关系，量化不同稳定化策略的带隙代价。

**Expected Relationship:** 元素掺杂引起的ΔEg绝对值与α相稳定性提升呈正相关，因为掺杂改变Pb-I轨道杂化并伴随晶格收缩/八面体倾斜，从而同时改变带隙和相稳定性；而添加剂或界面工程可在几乎不改变体相带隙（|ΔEg|<30 meV）的情况下提高稳定性。该关联可用于量化稳定化代价。

**Materials:** CsPbI3, Mn掺杂CsPbI3, Bi掺杂CsPbI3, Na掺杂CsPbI3, PEO-CsPbI3复合薄膜
**Property:** 带隙偏移ΔEg（相对未掺杂α-CsPbI3）

**Source Gap:** Gap 2
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p46
  - p50
  - p51
  - p58
  - p60
  - p64
  - p65

**Scientific Explanation (LLM):**
> 该假设在机制上具有合理性：掺杂元素进入晶格后会改变Pb-I轨道杂化强度，并可能诱导晶格收缩或八面体 tilt，这两者均会同时影响带隙大小和α相的热力学或动力学稳定性，因此带隙偏移幅度与稳定性增益之间可能共享同一结构根源。已有文献普遍观察到掺杂导致的带隙变化往往伴随相稳定性改善，但将两者定量关联并作为稳定化代价的度量，仍属一种新的简化框架，尚需更多体系验证。该关系的失效边界在于：当稳定性提升主要来自表面钝化、晶界修饰或应变释放等非体相效应时，带隙偏移可以很小甚至为零；反之，若掺杂引入了深能级缺陷或过度畸变，也可能出现带隙大幅变化而稳定性并未提升甚至下降的情况。此外，不同掺杂位点或电荷补偿机制会解耦电子结构与相稳定性之间的耦合，使该正相关不再成立。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['materials_project', 'nomad', 'literature']
  - supporting_evidence: []
  - details: {'materials_project': {'match': False, 'matching_entries': [], 'materials_found': [{'mp_id': 'mp-aaaciwec', 'formula': 'CsPbI3', 'band_gap': 1.4788, 'formation_energy': -1.238177400931034, 'match_type

---

### 5. 📚 带隙漂移速率作为钙钛矿器件运行稳定性早期预测因子的定量模型｜新知/已知：🔁 已有文献报道

**Confidence:** 0.55 | **Novelty:** 0.26 | **LLM Plausibility:** 0.65

**Description:** 对宽禁带混合卤化物钙钛矿太阳能电池（含不同界面钝化处理）同步进行最大功率点追踪下的PL光谱与PCE衰减测量，提取dEg/dt与dPCE/dt。检验二者是否存在正比关系，并考察电荷传输层离子阻挡能力对该比例系数的调节作用。

**Expected Relationship:** 带隙漂移越快，PCE衰减越快，二者呈正相关；但该斜率受电荷传输层离子阻挡能力调控。优化空穴/电子接触层后，光谱漂移和PCE衰减斜率均下降，说明离子迁移向界面的通量是连接光谱漂移与器件性能衰减的物理中介。

**Materials:** FABr钝化宽禁带钙钛矿薄膜, SAM/钙钛矿叠层器件, Cs/FA混合阳离子宽禁带钙钛矿器件
**Property:** PCE衰减速率 dPCE/dt 与带隙漂移速率 dEg/dt 的比例系数

**Source Gap:** Gap 4
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p7
  - p41
  - p53
  - p92

**Scientific Explanation (LLM):**
> 该构效关系成立的机制在于：钙钛矿薄膜的带隙漂移通常源于离子迁移引起的组分重构或缺陷演化，而同一离子迁移过程也会在器件内部积累界面电荷、诱导能带失配与非辐射复合，因此带隙漂移速率与PCE衰减速率共享物理根源，正相关关系具有合理性。已有文献已广泛报道离子迁移是钙钛矿器件滞后与降解的关键因素，但将带隙漂移速率作为定量早期预测因子并显式纳入电荷传输层对离子通量的调控，属于对现有认知的量化整合与模型化拓展。该关系的失效边界可能出现在离子迁移不是性能衰减主导路径的条件下，例如光照或温度引发的纯电子陷阱态退化、金属电极扩散导致的化学降解，或当封装与界面修饰已完全阻断离子通量时，光谱漂移与PCE衰减的耦合将被解除。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['literature']
  - supporting_evidence: []
  - details: {'literature': {'match': True, 'support_level': 'literature', 'papers': ['p17', 'p19', 'p23', 'p25', 'p26', 'p3', 'p4', 'p46', 'p49', 'p50', 'p51', 'p53', 'p54', 'p55', 'p57', 'p58', 'p59', 'p60', 'p6

---
