# Literature Survey — Paper Summaries

**Total papers:** 174
**Generated:** 2026-08-02T13:38:48.583549

---

**Sources:** sciverse(174)
**Common keywords:** cathode, capacity, ni-rich, cathodes, chemistry, stability, batteries, cycling, surface, engineering, layered, electrolyte, lithium, performance, abstract

---

### 1. {'title': 'Capacity Fading Mechanisms in Ni-Rich Single-Crystal\\nNCM Cathodes', 'authors': ['Hoon-Hee Ryu (4675450)', 'Been Namkoong (11126239)', 'Ja
**ID:** `p1`

### 2. {'title': 'Capacity Fading Mechanisms in Ni-Rich Single-Crystal NCM Cathodes', 'authors': ['Hoon‐Hee Ryu', 'Been Namkoong', 'Jae-Hyung Kim', 'Ilias Be
**ID:** `p2`

### 3. {'title': 'Fundamental and solutions of microcrack in Ni-rich layered oxide cathode materials of lithium-ion batteries', 'authors': ['Shouyi Yin', 'We
**ID:** `p3`

### 4. {'title': 'Understanding Co roles towards developing Co-free Ni-rich cathodes for rechargeable batteries', 'authors': ['Tongchao Liu', 'Lei Yu', 'Jiaj
**ID:** `p4`

### 5. {'title': 'Insights into Capacity Fading Mechanism and Coating Modification of High-Nickel Cathodes in Lithium-Ion Batteries', 'authors': ['Hexin Liu'
**ID:** `p5`

### 6. {'title': 'Superior Capacity Retention Spinel Oxyfluoride Cathodes for Lithium-Ion Batteries', 'authors': ['Wonchang Choi', 'Arumugam Manthiram'], 'ab
**ID:** `p6`

### 7. {'title': 'Advanced high-nickel layered oxide cathodes for lithium-ion batteries', 'authors': ['Wangda Li', '0000-0001-8103-4285'], 'abstract': 'The g
**ID:** `p7`

### 8. {'title': 'High-nickel layered oxide cathodes for high-energy-density lithium-ion batteries', 'authors': ['Jianyu Li', '0000-0003-2577-1672'], 'abstra
**ID:** `p8`

### 9. {'title': 'High-nickel layered oxide cathodes for high-performance lithium-ion batteries', 'authors': ['Xie, Qiang'], 'abstract': 'The ever-growing ma
**ID:** `p9`

### 10. {'title': 'Capacity Fading Mechanism of Ni-Rich NCA Cathode for Lithium-Ion Batteries', 'authors': ['Kang‐Joon Park', 'Gyeong Won Nam', 'Yang‐Kook Sun
**ID:** `p10`

### 11. {'title': 'Capacity Fading of Ni-Rich NCA Cathodes: Effect of Microcracking Extent', 'authors': ['Gyeong Won Nam', 'Nam-Yung Park', 'Kang-Joon Park', 
**ID:** `p11`

### 12. {'title': 'A Comparative Analysis of the Capacity Fading Mechanisms in Ni-Rich Single-Crystal and Polycrystalline Cathodes', 'authors': ['Hoon‐Hee Ryu
**ID:** `p12`

### 13. {'title': 'Exploring the Degradation Mechanism of Nickel-Rich NMC Cathode Materials', 'authors': ['Yiming Chen', 'Zulipiya Shadike'], 'abstract': "In 
**ID:** `p13`

### 14. {'title': 'Direct Observation of Dynamic Lithium Diffusion Behaviour in Nickel-Rich, LiNi0.8Mn0.1Co0.1O2 (NMC811) Cathodes using Operando Muon Spectro
**ID:** `p14`

### 15. {'title': 'Capacity Fade in Ni-Rich Cathodes: Additive Effects and Monitoring Surface Composition Changes', 'authors': ['Sarah Lucienne Guillot', 'Mon
**ID:** `p15`

### 16. {'title': 'Defect Engineering to Enhance Ni-Rich NMC811 Cathode Performance', 'authors': ['Sumaiyatul Ahsan', 'Abiram Krishnan', 'Faisal M. Alamgir'],
**ID:** `p16`

### 17. {'title': 'Cracking phenomena in single crystal Ni-rich NMC cathodes', 'authors': ['Ogley, Matthew', 'Paez Fajardo, Galo', 'Warnett, Jay'], 'abstract'
**ID:** `p17`

### 18. {'title': 'Inhibiting OxygenVacancies via Mo Doping to Enhancethe Cycle Stability of Ni-Rich Single-Crystal Cathodes', 'authors': ['Mingming Fan (1227
**ID:** `p18`

### 19. {'title': 'Controlling Molten-Salt Assisted Calcination for Single-Crystal Growth of Ni-Rich NMC Cathode Materials', 'authors': ['Joon Kyung Koong', '
**ID:** `p19`

### 20. {'title': 'Balancing Capacity and Cycling Stability of Ni‐Rich Cathode: Trace Amount of Cobalt Dopant is Unnecessary in Single‐Crystal', 'authors': ['
**ID:** `p20`

### 21. {'title': 'Characterizing Single Crystal Ni-Rich Cathode Materials: From Cathode-Electrolyte Interphase to Single Crystal Growth', 'authors': ['Jie Xi
**ID:** `p21`

### 22. {'title': 'Synergistic Degradation Mechanism in Single Crystal Ni-Rich NMC//Graphite Cells', 'authors': ['Galo J. Páez Fajardo', 'Eleni Fiamegkou', 'J
**ID:** `p22`

### 23. {'title': 'Stability Enhancement\\nand Microstructural Modification\\nof Ni-Rich Cathodes via Halide Doping', 'authors': ['Luqman Azhari (9865919)', '
**ID:** `p23`

### 24. {'title': 'Beyond Doping and Coating: Prospective Strategies\\nfor Stable High-Capacity Layered Ni-Rich Cathodes', 'authors': ['H. Hohyun Sun (8594694
**ID:** `p24`

### 25. {'title': 'Revisiting\\nCationic Doping Impacts in Ni-Rich Cathodes', 'authors': ['Xueyan Hou (4793748)', 'Takuya Katsumata (14521666)', 'Yuta Kimura 
**ID:** `p25`

### 26. {'title': 'Surface Modification Strategies for Improving the Cycling Performance of Ni-Rich Cathode Materials – Surface Modification Strategies for Im
**ID:** `p26`

### 27. {'title': 'Advancements in Addressing Microcrack Formation in Ni–Rich Layered Oxide Cathodes for Lithium–Ion Batteries', 'authors': ['Xu, Tianmei', 'W
**ID:** `p27`

### 28. {'title': 'Insight into Performance Degradation of Ni-Rich Layered Cathode Materials', 'authors': ['Sheng S. Zhang'], 'abstract': 'As a promising cath
**ID:** `p28`

### 29. {'title': 'Electrochemical Modeling on Crack Propagation within Ni-Rich Layered Cathode Materials', 'authors': ['Sunho Park', 'Joonam Park', 'Jihun So
**ID:** `p29`

### 30. {'title': 'Stabilizing High-Voltage and High-Capacity Cathode-Electrolyte Interface Using Functional Electrolyte Component', 'authors': ['Hee-Yeol Lee
**ID:** `p30`

### 31. {'title': 'Stabilizing High-Voltage Cathode-Electrolyte Interface Using High-Voltage Additive', 'authors': ['Hieu Quang Pham', 'Young‐Gil Kwon', 'Eui‐
**ID:** `p31`

### 32. {'title': 'High-Concentrated Binary-Salt Ether Electrolytes for High-Voltage Lithium Metal Batteries with Ni-Rich Cathode', 'authors': ['Zelin Li', 'X
**ID:** `p32`

### 33. {'title': 'Electrolytes Towards High Voltage Mn-Rich Cathodes', 'authors': ['Qian Liu', 'Qijia Zhu', 'Zhengcheng Zhang'], 'abstract': 'Earth-abundant,
**ID:** `p33`

### 34. {'title': 'Enhancing Cycling Stability and Capacity Retention of High-Capacity-High-Voltage Cathodes by Reengineering Interfaces Via Electrochemical F
**ID:** `p34`

### 35. {'title': 'Solvent Regulating Ni–O Bond Improves the Cyclabilityof High-Voltage Ni-Rich Cathodes in Nonflammable Electrolytes', 'authors': ['Xiaomei H
**ID:** `p35`

### 36. {'title': 'Solvent-Enriched Separator–Electrolyte Interface Stabilizes 4.7 V Ni-Rich Layered Cathodes', 'authors': ['Deqin Zeng', 'Jinze Wang', 'Long 
**ID:** `p36`

### 37. {'title': 'Cathode/Electrolyte Interface in High-Voltage Lithium-Ion Batteries', 'authors': ['Zhe-Yun Kee', 'Tai-Yu Pan', 'Wen-Dung Hsu'], 'abstract':
**ID:** `p37`

### 38. {'title': 'Understanding the High-Voltage Cycling Behavior of Ni-Rich Cathode', 'authors': ['Hanshuo Liu', 'Zhong Xie', 'Wei Qu'], 'abstract': 'Nowada
**ID:** `p38`

### 39. {'title': 'Adjusting\\nOxygen Redox Reaction and Structural Stability\\nof Li- and Mn-Rich Cathodes by Zr-Ti Dual-Doping', 'authors': ['Zhijie Feng (1
**ID:** `p39`

### 40. {'title': 'Zr-Doping Improves High-Voltage Cycling Stability of Slightly Li-Rich Nickel Oxide Cathodes', 'authors': ['Han Wang', 'Xiaoqiao Li', 'Yong 
**ID:** `p40`

### 41. {'title': 'Optimized\\nAl Doping Improves Both Interphase Stability\\nand Bulk Structural Integrity of Ni-Rich NMC Cathode Materials', 'authors': ['We
**ID:** `p41`

### 42. {'title': 'Cycling stability of lithium‐ion batteries based on Fe–Ti‐doped LiNi0.5Mn1.5O4 cathodes, graphite anodes, and the cathode‐additive Li3PO4',
**ID:** `p42`

### 43. {'title': 'Improved Cycle Life and Li-Ion Transport Parameters at Low Temperature in Doped Ni-Rich NMC Cathodes', 'authors': ['Ethan Williams', 'David
**ID:** `p43`

### 44. {'title': 'Reconstruction of magnetic exchange networks for high-performance Co-free Ni-rich cathodes', 'authors': ['万泽鑫', 'Xiaoyan Xie', 'Zhiyuan Hua
**ID:** `p44`

### 45. {'title': 'Co-free Li-rich compositions: New solid solutions for high-capacity cathodes', 'authors': ['Dr Jordi Jacas Biendicho', 'Dr Jekabs Grins', '
**ID:** `p45`

### 46. {'title': 'In Situ Doping Polyanions Enables Concentration-Gradient Ni-Rich Cathodes for Long-Life Lithium-Ion Batteries', 'authors': ['Lele Cai', 'Qi
**ID:** `p46`

### 47. {'title': 'Surface-Modified Ni-Rich Layered Cathode Materials Via Li-Reactive Inorganic Coatings', 'authors': ['Dina Becker', 'Richard Schmuch', 'Mart
**ID:** `p47`

### 48. {'title': 'High Voltage Operation of Ni‐Rich NMC Cathodes Enabled by Stable Electrode/Electrolyte Interphases', 'authors': ['Wengao Zhao', 'Jianming Z
**ID:** `p48`

### 49. {'title': 'Rational design of mechanically robust Ni-rich cathode materials via concentration gradient strategy', 'authors': ['Tongchao Liu', 'Lei Yu'
**ID:** `p49`

### 50. {'title': 'Challenges and Strategies towards Single‐Crystalline Ni‐Rich Layered Cathodes', 'authors': ['Lianshan Ni', 'Shu Zhang', 'Andi Di', 'Wentao 
**ID:** `p50`

### 51. {'title': 'Structural evolution and the capacity fade mechanism upon long-term cycling in Li-rich cathode material', 'authors': ['Bohang Song', 'Zongw
**ID:** `p51`

### 52. {'title': 'Crack-free single-crystalline Co-free Ni-rich LiNi0.95Mn0.05O2 layered cathode', 'authors': ['Lianshan Ni', 'Ruiting Guo', 'Susu Fang', 'Ju
**ID:** `p52`

### 53. {'title': 'Thermal Stability and Outgassing Behaviors of High‐nickel Cathodes in Lithium‐ion Batteries', 'authors': ['Zehao Cui', 'Arumugam Manthiram'
**ID:** `p53`

### 54. {'title': 'Degradation mechanisms of high capacity 18650 cells containing Si-graphite anode and nickel-rich NMC cathode', 'authors': ['Xuemin Li', 'An
**ID:** `p54`

### 55. {'title': 'Capacity Fading Mechanisms on Cycling a High-Capacity Secondary Sulfur Cathode', 'authors': ['Sang-Eun Cheon', 'Soo-Seok Choi', 'Ji-Seong H
**ID:** `p55`

### 56. {'title': 'The Origin of High‐Voltage Stability in Single‐Crystal Layered Ni‐Rich Cathode Materials', 'authors': ['Jianming Sun', 'Xin Cao', 'Huijun Y
**ID:** `p56`

### 57. {'title': 'The mechanism of side reaction induced capacity fading of Ni-rich cathode materials for lithium ion batteries', 'authors': ['Daozhong Hu', 
**ID:** `p57`

### 58. {'title': 'Long-Lasting Ni-Rich NCMA Cathodes via Simultaneous Microstructural Refinement and Surface Modification', 'authors': ['Hoon‐Hee Ryu', 'Hyun
**ID:** `p58`

### 59. {'title': 'Microstructure-optimized concentration-gradient NCM cathode for long-life Li-ion batteries', 'authors': ['Geon‐Tae Park', 'Hoon‐Hee Ryu', '
**ID:** `p59`

### 60. {'title': 'Improving the Structure and Cycling Stability of Ni-Rich Layered Cathodes by Dual Modification of Yttrium Doping and Surface Coating', 'aut
**ID:** `p60`

### 61. {'title': 'Variation of Electronic Conductivity within Secondary Particles Revealing a Capacity-Fading Mechanism of Layered Ni-Rich Cathode', 'authors
**ID:** `p61`

### 62. {'title': 'Spontaneous Strain Buffer Enables Superior Cycling Stability in Single-Crystal Nickel-Rich NCM Cathode', 'authors': ['He Zhu', 'Yu Tang', '
**ID:** `p62`

### 63. {'title': 'Intrinsic origin of intra-granular cracking in Ni-rich layered oxide cathode materials', 'authors': ['Kyoungmin Min', 'Eunseog Cho'], 'abst
**ID:** `p63`

### 64. {'title': 'Challenges and approaches of single-crystal Ni-rich layered cathodes in lithium batteries', 'authors': ['Jiangtao Hu', 'Hongbin Wang', 'Biw
**ID:** `p64`

### 65. {'title': 'Challenges and Modification Strategies of Ni-Rich Cathode Materials Operating at High-Voltage', 'authors': ['Caijian Liao', 'Fangkun Li', '
**ID:** `p65`

### 66. {'title': 'High capacity lithium-ion battery cathode using LiV3O8 nanorods', 'authors': ['Sudeep Sarkar', 'Harish Banda', 'Sagar Mitra'], 'abstract': 
**ID:** `p66`

### 67. {'title': 'Single-Crystalline Ni-Rich layered cathodes with Super-Stable cycling', 'authors': ['Lianshan Ni', 'Ruiting Guo', 'Wentao Deng', 'Baowei Wa
**ID:** `p67`

### 68. {'title': 'Surface Gradient Ni‐Rich Cathode for Li‐Ion Batteries', 'authors': ['Huan Chen', 'Huihui Yuan', 'Zhongqin Dai', 'Sheng Feng', 'Mengting Zhe
**ID:** `p68`

### 69. {'title': 'Improving the Thermal Stability of NMC 622 Li-Ion Battery Cathodes through Doping During Coprecipitation', 'authors': ['Albert L. Lipson', 
**ID:** `p69`

### 70. {'title': 'Cathodic behavior of (Co, Ti, Mg)-doped LiNiO2', 'authors': ['B. Chowdari', 'G. Rao', 'S. Chow'], 'abstract': 'Single-phase lithium nickel 
**ID:** `p70`

### 71. {'title': 'Nickel‐Rich Layered Cathode Materials for Lithium‐Ion Batteries', 'authors': ['Zhengcheng Ye', 'Lang Qiu', 'Wen Yang', 'Zhenguo Wu', 'Yuxia
**ID:** `p71`

### 72. {'title': 'Unraveling Mechanism for Microstructure Engineering toward High‐Capacity Nickel‐Rich Cathode Materials', 'authors': ['Lili Lin', 'Lihan Zha
**ID:** `p72`

### 73. {'title': 'Tailoring electrolyte enables high-voltage Ni-rich NCM cathode against aggressive cathode chemistries for Li-ion batteries', 'authors': ['F
**ID:** `p73`

### 74. {'title': 'Core/Double-Shell Type Gradient Ni-Rich LiNi<sub>0.76</sub>Co<sub>0.10</sub>Mn<sub>0.14</sub>O<sub>2</sub> with High Capacity and Long Cycl
**ID:** `p74`

### 75. {'title': 'Unraveling the nonlinear capacity fading mechanisms of Ni-rich layered oxide cathode', 'authors': ['Su Ma', 'Xiaodong Zhang', 'Shumeng Wu',
**ID:** `p75`

### 76. {'title': 'Preventing Interdiffusion during Synthesis of Ni-Rich Core–Shell Cathode Materials', 'authors': ['Divya Rathore', 'Matthew D. L. Garayt', '
**ID:** `p76`

### 77. {'title': 'Surface Modification on Nickel Rich Cathode Materials for Lithium‐Ion Cells: A Mini Review', 'authors': ['M. Akhilash', 'P. S. Salini', 'Bi
**ID:** `p77`

### 78. {'title': 'Advancements and Challenges in High-Capacity Ni-Rich Cathode Materials for Lithium-Ion Batteries', 'authors': ['Mehdi Ahangari', 'Benedek S
**ID:** `p78`

### 79. {'title': 'High‐Voltage Induced Surface and Intragranular Structural Evolution of Ni‐Rich Layered Cathode', 'authors': ['Hanshuo Liu', 'Zhong Xie', 'W
**ID:** `p79`

### 80. {'title': 'Isotropic Microstrain Relaxation in Ni-Rich Cathodes for Long Cycling Lithium Ion Batteries', 'authors': ['Zhihong Wang', 'Wu Wei', 'Qiang 
**ID:** `p80`

### 81. {'title': 'Ion exchange membranes as electrolyte to improve high temperature capacity retention of LiMn2O4 cathode lithium-ion batteries', 'authors': 
**ID:** `p81`

### 82. {'title': 'LixV2O5 nanobelts for high capacity lithium-ion battery cathodes', 'authors': ['Dmitrii A. Semenenko', 'Daniil M. Itkis', 'Ekaterina Pomera
**ID:** `p82`

### 83. {'title': 'Layer-by-layer delithiation during lattice collapse as the origin of planar gliding and microcracking in Ni-rich cathodes', 'authors': ['Ru
**ID:** `p83`

### 84. {'title': 'Single crystal Ni-rich NMC cathode materials for lithium-ion batteries with ultra-high volumetric energy density', 'authors': ['Ivan A. Moi
**ID:** `p84`

### 85. {'title': 'Understanding the Synthesis Kinetics of Single‐Crystal Co‐Free Ni‐Rich Cathodes', 'authors': ['Jingjie Liu', 'Yifei Yuan', 'Jianhui Zheng',
**ID:** `p85`

### 86. {'title': 'Architecting “Li-Rich Ni-Rich” Core-Shell Layered Cathodes for High-Energy Li-Ion Batteries', 'authors': ['Zhiwie Jing', 'Suning Wang', 'Vo
**ID:** `p86`

### 87. {'title': 'Unique insights into the design of low-strain single-crystalline Ni-rich cathodes with superior cycling stability', 'authors': ['Qiang Han'
**ID:** `p87`

### 88. {'title': 'Enhancing the structural stability and capacity retention of Ni-rich LiNi0.7Co0.3O2 cathode materials via Ti doping for rechargeable Li-ion
**ID:** `p88`

### 89. {'title': 'Storage degradation mechanism of layered Ni-rich oxide cathode material LiNi0.8Co0.1Mn0.1O2', 'authors': ['Mingru Su', 'Yi-Chang Chen', 'Ho
**ID:** `p89`

### 90. {'title': 'Cobalt-free nickel-rich cathode materials based on Al/Mg co-doping of LiNiO2 for lithium ion battery', 'authors': ['Lina Shen', 'Fanghui Du
**ID:** `p90`

### 91. {'title': 'Preparation of long-term cycling stable ni-rich concentration–gradient NCMA cathode materials for li-ion batteries', 'authors': ['Juliya Je
**ID:** `p91`

### 92. {'title': 'Surface-dependent stress-corrosion cracking in Ni-rich layered oxide cathodes', 'authors': ['Weifeng Wei', 'Zhengping Ding', 'Cheng Chen', 
**ID:** `p92`

### 93. {'title': 'Improving high-voltage cycling performance of nickel-rich NMC layered oxide cathodes for rechargeable lithium–ion batteries by Mg and Zr co
**ID:** `p93`

### 94. {'title': 'Origins and Importance of Intragranular Cracking in Layered Lithium Transition Metal Oxide Cathodes', 'authors': ['Jędrzej K. Morzy', 'Wesl
**ID:** `p94`

### 95. {'title': 'Mechanically and Chemically Co‐Robust Ni‐Rich Cathodes with Ultrahigh Capacity and Prolonged Cycle Life', 'authors': ['Bo Wang', 'Kuo Li', 
**ID:** `p95`

### 96. {'title': 'Achieving Long‐Life Ni‐Rich Cathodes with Improved Mechanical‐Chemical Properties Via Concentration Gradient Structure', 'authors': ['Zhiyo
**ID:** `p96`

### 97. {'title': 'Enhancing cyclic and in-air stability of Ni-Rich cathodes through perovskite oxide surface coating', 'authors': ['Peiyuan Guan', 'Yanzhe Zh
**ID:** `p97`

### 98. {'title': 'Surface modification of Sr-doped LaMnO3 coating by spray drying on Ni-rich LiNi0.8Mn0.1Co0.1O2 cathode material for lithium-ion batteries',
**ID:** `p98`

### 99. {'title': 'Lithium‐Ion Conductive Coatings for Nickel‐Rich Cathodes for Lithium‐Ion Batteries', 'authors': ['Yijia Shao', 'Jia Xu', 'Amardeep Amardeep
**ID:** `p99`

### 100. {'title': 'Dual-modification of Ni-rich cathode materials through strontium titanate coating and thermal treatment', 'authors': ['Peiyuan Guan', 'Jie 
**ID:** `p100`

### 101. {'title': 'Enhanced electrochemical performance of Ni-rich cathode material by N-doped LiAlO2 surface modification for lithium-ion batteries', 'author
**ID:** `p101`

### 102. {'title': 'Li‐Rich Mn–Mg Layered Oxide as a Novel Ni‐/Co‐Free Cathode', 'authors': ['Yongseok Lee', 'Hyunyoung Park', 'Min‐kyung Cho', 'Jinho Ahn', 'W
**ID:** `p102`

### 103. {'title': 'Oxygen Vacancies Driven by Co in the Deeply Charged State Inducing Intragranular Cracking of Ni‐Rich Cathodes', 'authors': ['Fuqiren Guo', 
**ID:** `p103`

### 104. {'title': 'Elucidating the Humidity-Induced Degradation of Ni-Rich Layered Cathodes for Li-Ion Batteries', 'authors': ['Leiting Zhang', 'E. Müller', '
**ID:** `p104`

### 105. {'title': 'Enhanced cycling stability and storage performance of Na0.67Ni0.33Mn0.67-xTixO1.9F0.1 cathode materials by Mn-rich shells and Ti doping', '
**ID:** `p105`

### 106. {'title': 'Pre‐Deoxidation of Layered Ni‐Rich Cathodes to Construct a Stable Interface with Electrolyte for Long Cycling Life', 'authors': ['Xing Chen
**ID:** `p106`

### 107. {'title': 'High-Performance High-Nickel Multi-Element Cathode Materials for Lithium-Ion Batteries', 'authors': ['Xinyong Tian', 'Ruiqi Guo', 'Ying Bai
**ID:** `p107`

### 108. {'title': "Advancing layered cathode material's cycling stability from uniform doping to non-uniform doping", 'authors': ['Kuan Wang', 'Pengfei Yan', 
**ID:** `p108`

### 109. {'title': 'Multiple-ion-doped lithium nickel oxides as cathode materials for lithium-ion batteries', 'authors': ['Guoxiu Wang', 'Steve Bewlay', 'Jane 
**ID:** `p109`

### 110. {'title': 'In-situ Ti4+-doped modification of layer-structured Ni-rich LiNi0.83Co0.11Mn0.06O2 cathode materials for high-energy lithium-ion batteries'
**ID:** `p110`

### 111. {'title': 'Operando Building of a Superior Interface Hybrid Film Enables Chemomechanically Durable Co-Free Ni-Rich Cathodes', 'authors': ['Haifeng Yu'
**ID:** `p111`

### 112. {'title': 'Kinetically Dormant Ni‐Rich Layered Cathode During High‐Voltage Operation', 'authors': ['Jiyu Cai', 'Xinwei Zhou', 'Luxi Li', 'Zhenzhen Yan
**ID:** `p112`

### 113. {'title': 'High‐Voltage Performance of Ni‐Rich NCA Cathodes: Linking Operating Voltage with Cathode Degradation', 'authors': ['Lamuel David', 'Debasis
**ID:** `p113`

### 114. {'title': 'Nanoscale operation of Ni-Rich cathode surface by polycrystalline solid electrolytes Li3.2Zr0.4Si0.6O3.6 coating', 'authors': ['Jianying Li
**ID:** `p114`

### 115. {'title': 'Mitigating the Kinetic Hysteresis of Co‐Free Ni‐Rich Cathodes via Gradient Penetration of Nonmagnetic Silicon', 'authors': ['Yijun Song', '
**ID:** `p115`

### 116. {'title': 'Prospects for spinel-stabilized, high-capacity lithium-ion battery cathodes', 'authors': ['Jason R. Croy', 'Joong Sun Park', 'Young Ho Shin
**ID:** `p116`

### 117. {'title': 'Multimodal electrochemistry coupled microcalorimetric and X-ray probing of the capacity fade mechanisms of Nickel rich NMC – progress and o
**ID:** `p117`

### 118. {'title': 'Systematic study of Co-free LiNi0.9Mn0.07Al0.03O2 Ni-rich cathode materials to realize high-energy density Li-ion batteries', 'authors': ['
**ID:** `p118`

### 119. {'title': 'Excellent Structural Stability-Driven Cyclability in P2-Type Ti-Based Cathode for Na-Ion Batteries', 'authors': ['Hari Narayanan Vasavan', 
**ID:** `p119`

### 120. {'title': 'High-nickel and cobalt-free layered LiNi0.90Mn0.06Al0.04O2 cathode for lithium-ion batteries', 'authors': ['Ruheng Xi', 'Jianru Zhang', 'Zi
**ID:** `p120`

### 121. {'title': 'Enhanced Structural Stability of Single-Crystalline Ni-Rich Cathode Enables Improved Cyclability in Pouch Cells', 'authors': ['Youqi Chu', 
**ID:** `p121`

### 122. {'title': 'Ce-doped NMC 811 synthesis as cathode material', 'authors': ['Moh. Wahyu Syafi’ul Mubarok', 'Muhammad Fakhrudin', 'Evvy Kartini'], 'abstrac
**ID:** `p122`

### 123. {'title': 'Tungsten‐based Li‐rich rock salt stabilized Co‐free Ni‐rich layered oxide cathodes', 'authors': ['Bing-Chen Li', 'Mei Wang', 'Bing-Yuan Han
**ID:** `p123`

### 124. {'title': 'High-capacity dilithium hydroquinone cathode material for lithium-ion batteries', 'authors': ['Yong Lü', 'Haoqin Han', 'Zhuo Yang', 'Youxua
**ID:** `p124`

### 125. {'title': 'Structure/interface synergy stabilizes high-nickel cathodes for lithium-ion batteries', 'authors': ['Guihong Mao', 'Liming Zeng', 'Jieyu Ya
**ID:** `p125`

### 126. {'title': 'Improved cycling stability of Ni-rich LiNi0.8Co0.1Mn0.1O<sub>2</sub> cathode materials by optimizing Ti doping', 'authors': ['Nengneng Wang
**ID:** `p126`

### 127. {'title': 'Research on Nb doping–coating composite modification of LiNiO2 cathode material for lithium-ion batteries', 'authors': ['Jing Li', 'Yongmin
**ID:** `p127`

### 128. {'title': 'Boosting the Structural Stability of High‐Voltage Sodium Layered Cathodes via Site‐Selective La/Ti Co‐Doping', 'authors': ['Sreelakshmy The
**ID:** `p128`

### 129. {'title': 'Co-free Ni-rich layered cathode with long-term cycling stability', 'authors': ['Park, G-T'], 'abstract': 'Introducing Mo into a Ni-rich lay
**ID:** `p129`

### 130. {'title': 'Integrated Modification Strategy Enables Remarkable Cyclability and Thermal Stability of Ni-Rich Cathode Materials for Lithium-Ion Batterie
**ID:** `p130`

### 131. {'title': 'Co‐Doping Engineered High Performance Ni‐Rich Layered Cathode', 'authors': ['Kaili Li', 'Weixin Chen', 'Mingqiu Duan', 'Zhiling Liu', 'Dilx
**ID:** `p131`

### 132. {'title': 'Enhanced electrochemical performance of Ni-rich layered LiNi0.9Co0.05Mn0.05O2 cathode material via synergistic modification of cerium dopin
**ID:** `p132`

### 133. {'title': 'Ni-Rich Layered Oxide Cathodes/Sulfide Electrolyte Interface in Solid-State Lithium Battery', 'authors': ['Yiman Feng', 'Zhixing Wang', 'Du
**ID:** `p133`

### 134. {'title': 'Concentration-gradient of Li-rich Mn-based cathode materials with enhanced cycling retention', 'authors': ['Lanlan Cheng', 'Wenyan Yang', '
**ID:** `p134`

### 135. {'title': 'Addressing Unfavorable Influence of Particle Cracking with a Strengthened Shell Layer in Ni-Rich Cathodes', 'authors': ['Meng Liu', 'Zhongm
**ID:** `p135`

### 136. {'title': 'High-voltage electrolyte design for a Ni-rich layered oxide cathode for lithium-ion batteries', 'authors': ['Jun Hu', 'Fangyuan Cheng', 'Ch
**ID:** `p136`

### 137. {'title': 'Sodium‐Rich, Co‐Ni‐Free P2‐Layered Manganese Oxide Cathodes for Sodium‐Ion Batteries', 'authors': ['Zulkifli', 'Balaji Sambandam', 'Ahmad N
**ID:** `p137`

### 138. {'title': 'Synergistic doping chemistry enable the cycling properties of single-crystal Ni-rich cathode for lithium-ion batteries', 'authors': ['Bao Z
**ID:** `p138`

### 139. {'title': 'Zr/Ti trace Co-doping induced disordered structure to enhance the cycling stability of Li-rich Mn-based layered oxide cathodes', 'authors':
**ID:** `p139`

### 140. {'title': 'Engineering Reversible Lattice Structure for High‐Capacity Co‐Free Li‐Rich Cathodes with Negligible Capacity Degradation', 'authors': ['Gua
**ID:** `p140`

### 141. {'title': 'Delithiation coupling with surface reconstruction during capacity degradation in Ni-rich layered cathodes', 'authors': ['Peng Wang', 'Lang 
**ID:** `p141`

### 142. {'title': 'Stabilizing the Interphase in an Ultra-High-Nickel Cathode Enabling High-Performance Lithium-Ion Batteries', 'authors': ['Qing Zhao', 'Zhib
**ID:** `p142`

### 143. {'title': 'Research Progress on the Capacity Fading Mechanisms of High-Nickel Ternary Layered Oxide Cathode Materials', 'authors': ['Xiang Li', 'Ge Wu
**ID:** `p143`

### 144. {'title': 'High-Voltage Fluoride-Free Electrolytes for Ni-Rich Cathodes Offering Superior Water Resistance', 'authors': ['Chengkun Liu', 'Tao Yang', '
**ID:** `p144`

### 145. {'title': 'Improving electrochemical performance of Ni-rich layered oxide cathodes via one-step dual modification strategy', 'authors': ['Yuan-lin CAO
**ID:** `p145`

### 146. {'title': 'Submicron single-crystal structure for enhanced structural stability of LiNi0.8Mn0.2O2 Ni-rich cobalt-free cathode materials', 'authors': [
**ID:** `p146`

### 147. {'title': 'Origin and Suppression of Intragranular Cracks for Long‐Cycling High‐Ni Co‐Free Cathodes', 'authors': ['Zhiming Xiao', 'Xinyou He', 'Fenghu
**ID:** `p147`

### 148. {'title': 'Designing Advanced Electrolytes for High‐Voltage High‐Capacity Disordered Rocksalt Cathodes', 'authors': ['Ridwan A. Ahmed', 'Rohith Sriniv
**ID:** `p148`

### 149. {'title': 'Enhanced Long-Term Cycling Life of Ni-Rich NMC Cathodes in High-Voltage Lithium–Metal Batteries', 'authors': ['Fengxia Xin', 'Weiran Zhang'
**ID:** `p149`

### 150. {'title': 'Robust Concentration Gradient Co-Free Ni-Rich Cathodes Enable Long-Life and Safe Operations in High-Voltage Li-Ion Batteries', 'authors': [
**ID:** `p150`

### 151. {'title': 'Storage-Induced Surface/Interfacial Degradation of Ni-Rich Layered Cathodes', 'authors': ['Jun Yang', 'Pingping Yang', 'Luyao Zheng', 'Hong
**ID:** `p151`

### 152. {'title': 'Structural Stability During Charge-Discharge Cycles in Zr-doped LiCoO<sub>2</sub>Powders', 'authors': ['Seon-Hye Kim', 'Kwang-Bo Shim', 'Ja
**ID:** `p152`

### 153. {'title': 'Outstanding Electrochemical Performance of Ni-Rich Concentration-Gradient Cathode Material LiNi0.9Co0.083Mn0.017O2 for Lithium-Ion Batterie
**ID:** `p153`

### 154. {'title': 'Modification Strategies of High‐Nickel Layered Oxide Cathode for Lithium‐Ion Batteries', 'authors': ['Mengxi Cai', 'Wen Yang', 'Zhenguo Wu'
**ID:** `p154`

### 155. {'title': 'Charge Compensation Mechanisms in Ni‐Rich NMC Cathodes', 'authors': ['Jesús Díaz-Sánchez', 'Ingeborg Sellæg Ellingsen', 'Elena Salagre', 'J
**ID:** `p155`

### 156. {'title': 'Improved cycling stability of P2-type Na0.71Co0.96O2 cathode material by optimizing Ti doping', 'authors': ['Xueying Li', 'Jiangang Wang', 
**ID:** `p156`

### 157. {'title': 'Hybrid Doping Strategy with High‐Entropy Cu/Fe Surface Modification and Zr Bulk Incorporation for Ni‐Rich Cathodes', 'authors': ['Jaemin Ki
**ID:** `p157`

### 158. {'title': 'Layered Ni-rich Cathode Materials', 'authors': ['Seung‐Taek Myung', 'Chang‐Heum Jo', 'Aishuak Konarov'], 'abstract': '<jats:p>Recent lithiu
**ID:** `p158`

### 159. {'title': 'Lithium Selenide: Unlocking a High-Capacity Cathode for Lithium-Ion Batteries', 'authors': ['Lu Cheng', 'Jiatong Jiang', 'Daoling Peng', 'S
**ID:** `p159`

### 160. {'title': 'Ultra‐High Nickel Oxides as Cathode Materials for High‐Energy Lithium‐Ion Batteries', 'authors': ['Yilong Han', 'Changlu Zheng', 'Zhichao L
**ID:** `p160`

### 161. {'title': 'Synergistic Coupling of High Capacity Li1.2Mn0.54Ni0.13Co0.13O2 and High Voltage LiMn1.6Ni0.4O4 Lithium-Ion Battery Cathodes', 'authors': [
**ID:** `p161`

### 162. {'title': 'Achieving Fast Charging and Superior Cycling Stability Single‐Crystal Ni‐Rich Cathodes by Ultrafast Aqueous Washing', 'authors': ['Kaixin L
**ID:** `p162`

### 163. {'title': 'An old blending strategy can enhance capacity retention of Ni-rich cathode materials', 'authors': ['Puttida Nanthamitr', 'Chanikarn Tomon',
**ID:** `p163`

### 164. {'title': 'Recent Development on the Preparation Processes of Co‐Free Ni‐Rich Layered Oxide Cathode Materials', 'authors': ['Jingzhuo Tang', 'Xiuhua Z
**ID:** `p164`

### 165. {'title': 'Coating Strategies of Ni-rich Layered Cathode in LIBs', 'authors': ['Yimeng Wang', 'Kai Liu', 'Baoguo Wang'], 'abstract': '锂离子电池(LIBs)因具有更高
**ID:** `p165`

### 166. {'title': 'Capacity Fading Mechanism of Ni-Rich Cathode Materials Focusing on Particle Interior', 'authors': ['Nam-Yung Park', 'Sang-Mun Han', 'Yang‐K
**ID:** `p166`

### 167. {'title': 'Mechanism of Capacity Fading of Li-Rich Layer-Structured Cathode Materials Based on TEM/Electrochemical Analyses', 'authors': ['Kuan‐Zong F
**ID:** `p167`

### 168. {'title': 'Pushing High Capacity with Thermodynamically Stable Interface for Single Crystalline Nickel-rich Cathode', 'authors': ['Jue Wu', 'Haoming Z
**ID:** `p168`

### 169. {'title': 'Improvement of Cycling Stability of Core–Shell Structured Ni-Rich NMC Cathodes by Using a Tungsten Oxide Stabilization Interlayer', 'author
**ID:** `p169`

### 170. {'title': 'The insights into the effect of Mg doping on the LiNiO2 cathode with Li/Ni dual sites', 'authors': ['Yongzhong Chen', 'C. G. Shu', 'Linglin
**ID:** `p170`

### 171. {'title': 'Entropic electrolyte engineering for stabilizing the cathode-electrolyte interphase in high-voltage lithium-rich cathodes', 'authors': ['Hu
**ID:** `p171`

### 172. {'title': 'The Carbon-Electrolyte Interface at High Cathodic Voltages', 'authors': ['Ann Mari Svensson', 'Benedicte Eikeland Nilssen', 'Ahmet Oguz Tez
**ID:** `p172`

### 173. {'title': 'High Voltage Electrolytes to Stabilize Ni-Rich Lithium Battery Performance', 'authors': ['Christopher Poches', 'Amir Abdul Razzaq', 'Haiden
**ID:** `p173`

### 174. {'title': 'Ta/Ti Codoped Concentration Gradient High-Ni Cathodes for Long-Life Li-Ion Batteries', 'authors': ['Hui Xiao', 'Lele Cai', 'Qiang Han', 'Ha
**ID:** `p174`
