# Structure-Property Relationship Discovery

**Generated:** 2026-08-02 14:05
**Total candidates explored:** 26
**Validated:** 0 | **Refuted:** 0
**Literature supported:** 5 | **Inconclusive:** 0 | **Pending:** 0
**Materials Project hits:** 0

## Search Summary

Explored 5 hypotheses via Bayesian optimization and MCTS; literature-supported 5.

---

## Discovered Structure-Property Relationships

### 1. 📚 掺杂元素描述符与容量保持率提升幅度的定量构效关系｜新知/已知：🆕 全新

**Confidence:** 0.75 | **Novelty:** 0.90 | **LLM Plausibility:** 0.85

**Description:** 针对Gap 3中掺杂元素种类繁多但缺乏定量描述符模型的问题，提出掺杂元素的M-O键解离能、离子价态以及与Ni2+的离子半径失配度可以预测容量保持率的提升幅度。M-O键越强、阳离子价态越高，越能稳定氧骨架和表面结构；而半径失配度过大会引入局部晶格应变，抵消稳定化效果。该假设可通过在固定基体LiNi0.8Co0.1Mn0.1O2中分别以相同摩尔分数（如1-2 mol%）掺杂Al、Ti、Zr、Mg、Mo、Nb、W，并测量循环保持率来构建多描述符回归模型。

**Expected Relationship:** Δretention与掺杂阳离子M-O键焓和价态正相关，与离子半径失配度负相关；预计Zr和Mo的改善效果优于Al和Mg，W和Nb在高电压下同样有效。该关系可通过多描述符线性回归或机器学习模型验证。

**Materials:** LiNi0.8Co0.1Mn0.1O2, Al掺杂LiNi0.8Co0.1Mn0.1O2, Ti掺杂LiNi0.8Co0.1Mn0.1O2, Zr掺杂LiNi0.8Co0.1Mn0.1O2, Mg掺杂LiNi0.8Co0.1Mn0.1O2, Mo掺杂LiNi0.8Co0.1Mn0.1O2, Nb掺杂LiNi0.8Co0.1Mn0.1O2, W掺杂LiNi0.8Co0.1Mn0.1O2
**Property:** 容量保持率提升幅度（Δretention vs 未掺杂）

**Source Gap:** Gap 3
**Search Method:** bayesian (15 iterations, 26 candidates)

**Evidence Chain:**
  - p18
  - p23
  - p25
  - p39
  - p40
  - p41
  - p43
  - p44

**Scientific Explanation (LLM):**
> 该构效关系在机制上具有合理性：掺杂阳离子与氧的M-O键焓越高，越能增强晶格氧的稳定性，抑制高电压循环中氧空位的形成与不可逆相变；高价态掺杂离子可通过强库仑排斥作用减少Li/Ni阳离子混排，并缓冲脱嵌锂过程中的晶胞体积变化，而离子半径失配度过大则易引入局域畸变和应力集中，反而加速微裂纹扩展与容量衰减。这一“键焓-价态-半径失配”联合描述符框架，与此前文献中关于Zr、Ti、Al掺杂提升NCM811结构稳定性的零散报道在定性趋势上一致，但将其归纳为可量化的多描述符线性或机器学习模型，属于对已有机制的整合与新知拓展。其失效边界可能出现在掺杂量较高时，此时过量掺杂剂偏析于晶界或形成惰性第二相，使电化学活性面积显著下降，描述符预测的稳定化收益被界面阻抗增大所抵消；此外在超高压或极端温度条件下，氧析出和晶间断裂等失效模式可能由局部动力学过程主导，而非单纯由掺杂阳离子的平衡态描述符决定，因此该关系对工况外推的适用性有限。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['literature']
  - supporting_evidence: []
  - details: {'literature': {'match': True, 'support_level': 'literature', 'papers': ['p1', 'p161', 'p74'], 'values': [], 'source': 'knowledge_graph.md + paper_summaries.md'}}

---

### 2. 📚 Ni含量-容量保持率trade-off的量化标度｜新知/已知：🆕 全新

**Confidence:** 0.65 | **Novelty:** 0.70 | **LLM Plausibility:** 0.75

**Description:** 针对Gap 4中Ni含量增加导致容量上升但保持率下降缺乏统一数学关系的问题，提出在相同测试条件下（如1C、200圈、4.3V），容量保持率随Ni摩尔分数x的增加呈现分段线性下降，且在高Ni区（x≥0.9）下降斜率显著增大。原因在于随Ni含量升高，Li/Ni混排加剧、表面Ni4+反应活性增强，并且微裂纹起始传播电位降低。该假设可通过统一测试不同Ni含量（x=0.7/0.8/0.88/0.9/0.95）的NCM/NCA样品，并用线性或分段函数拟合保持率-Ni含量数据来验证。

**Expected Relationship:** 容量保持率R与Ni含量x满足R = A - Bx，在x<0.9时B约为每0.1 Ni降低5-12个百分点；在x≥0.9时因微裂纹和表面反应加剧，B增大至约15-20个百分点每0.1 Ni。

**Materials:** LiNi0.7Co0.1Mn0.2O2, LiNi0.8Co0.1Mn0.1O2, LiNi0.88Co0.08Mn0.04O2, LiNi0.9Co0.05Mn0.05O2, LiNi0.95Co0.02Mn0.03O2
**Property:** 容量保持率（1C/200圈/4.3V后%）

**Source Gap:** Gap 4
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p8
  - p10
  - p11
  - p13
  - p24

**Scientific Explanation (LLM):**
> 该假设的机制基础在于：随着Ni含量升高，层状氧化物中Ni³⁺/Ni⁴⁺氧化还原对的比例增加，高活性Ni⁴⁺在充电态下极易与电解液发生副反应，并在颗粒表面形成岩盐相或尖晶石相钝化层，导致阻抗增长和容量衰减；同时，Ni含量增加会加剧Li/Ni阳离子混排及晶格各向异性变化，在长循环中诱发微裂纹，使新鲜表面持续暴露于电解液，进一步加速衰减，因此容量保持率随Ni含量上升呈近似线性下降。这一“Ni含量-容量保持率”负相关关系在多种高镍正极（NCM、NCA等）的循环报告中已有广泛报道，但将其分段线性化为“x<0.9斜率较缓、x≥0.9斜率陡增”的定量标度，则是对已有趋势的一种半定量归纳，可视为对已知规律的细化与显式化。该关系的失效边界可能出现在低Ni区间（如x<0.6）或特殊改性体系中：当Co/Mn比例、掺杂元素、表面包覆或单晶形貌显著改变衰减主导机制时，容量保持率可能不再单纯受Ni含量控制；此外，在极低倍率、较低截止电压或短循环圈数下，表面副反应和微裂纹尚未充分发展，该线性关系也可能不成立。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['literature']
  - supporting_evidence: []
  - details: {'literature': {'match': True, 'support_level': 'literature', 'papers': ['p1', 'p161', 'p74'], 'values': [], 'source': 'knowledge_graph.md + paper_summaries.md'}}

---

### 3. 📚 Co含量由益转害的截止电压阈值｜新知/已知：🆕 全新

**Confidence:** 0.60 | **Novelty:** 0.72 | **LLM Plausibility:** 0.70

**Description:** 针对Gap 2中Co对容量保持率作用方向矛盾的问题，提出Co的作用方向取决于截止电压的假设。在较低截止电压（<4.4 V）下，微量Co可稳定层状结构、抑制阳离子混排，从而提升容量保持率；但在较高截止电压（≥4.4 V）下，Co比Ni更易参与表面不可逆相变，并促进Ni4+溶解和表面重构，导致Co含量越高、容量衰减越快。该假设可通过Co含量梯度（0/2/5/10 at%）与截止电压（4.2/4.4/4.6 V）的矩阵实验，并定量表征表面重构厚度来验证。

**Expected Relationship:** 容量保持率对Co含量的斜率为正时对应的截止电压较低，斜率为负时对应的截止电压较高，临界截止电压位于4.4-4.5 V之间；Co含量越高，高电压循环后表面岩盐相层厚度和Ni溶解量越大。

**Materials:** LiNi0.8CoyMn0.2-yO2 (y=0, 0.02, 0.05, 0.10), LiNi0.88CoyMn0.12-yO2 (y=0, 0.02, 0.05)
**Property:** 容量保持率（如0.5C/200圈后%）

**Source Gap:** Gap 2
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p4
  - p20
  - p90
  - p123
  - p147

**Scientific Explanation (LLM):**
> 在较低截止电压下，Co的引入可抑制循环过程中的阳离子混排并维持层状结构的可逆性，从而提升容量保持率；然而当截止电压升高至4.4–4.5 V以上时，高氧化态Co会加剧表面晶格氧的释放，促进岩盐相层增厚及过渡金属（尤其Ni）溶出，使Co的积极作用转变为劣化因素。这一“由益转害”的电压依赖行为与文献中关于Co含量对高镍正极表面结构稳定性影响存在矛盾报道的现象相呼应，但对Co作用方向随截止电压发生翻转的临界区间给出了更清晰的构效关系描述，属于对已有知识的细化与整合。该关系的失效边界可能出现在Co含量极低或极高的极端组成中，因为此时界面退化与体相稳定性的主导机制发生改变，亦可能受电解液添加剂、温度或倍率等测试条件的干扰而偏离上述阈值。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['literature']
  - supporting_evidence: []
  - details: {'literature': {'match': True, 'support_level': 'literature', 'papers': ['p1', 'p161', 'p74'], 'values': [], 'source': 'knowledge_graph.md + paper_summaries.md'}}

---

### 4. 📚 单晶粒径对容量保持率的非单调影响及最优尺寸｜新知/已知：🆕 全新

**Confidence:** 0.50 | **Novelty:** 0.85 | **LLM Plausibility:** 0.60

**Description:** 针对Gap 5中单晶粒径与容量保持率之间缺乏标度关系的问题，提出在1-10 μm粒径范围内，单晶Ni-rich正极的容量保持率随粒径增大呈先升后降的非单调变化，存在最优粒径（约1-3 μm）。粒径过小时，比表面积大导致表面副反应和界面阻抗增长显著；粒径过大时，Li扩散路径变长，内部Li浓度梯度和两相共存应力增加，导致颗粒内部裂纹和结构退化。该假设可通过制备粒径梯度为1/2/3/5/8 μm的单晶LiNi0.8Co0.1Mn0.1O2，在相同电化学条件下测循环保持率，并拟合非单调函数来验证。

**Expected Relationship:** 容量保持率随单晶粒径d的变化呈倒U型，可用R = R0 + a·exp(-d/b) - c·d^α描述；峰值粒径约在1-3 μm。d<1 μm时界面阻抗增长主导衰减，d>5 μm时Li浓度梯度和内部裂纹主导衰减。

**Materials:** 单晶LiNi0.8Co0.1Mn0.1O2, 单晶LiNi0.8Mn0.2O2, 单晶LiNi0.95Mn0.05O2
**Property:** 容量保持率（如0.5C/4.3V/200圈后%）

**Source Gap:** Gap 5
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p1
  - p146
  - p84
  - p87

**Scientific Explanation (LLM):**
> 该构效关系在机制上可能成立：当单晶粒径过小时，晶界与表面占比显著增加，循环中界面副反应积累导致阻抗增长，成为容量衰减的主要来源；而当粒径过大时，锂离子在颗粒内部的固相扩散路径变长，充放电过程中易形成明显的Li浓度梯度，诱发晶内裂纹与结构退化，从而降低容量保持率。因此，中等粒径（约1–3 μm）可在界面副反应与内部应力之间取得最优平衡，形成倒U型关系。该假设与文献中关于“单晶化可减少晶界裂纹、但过大颗粒加剧内部应变”的既有结论一致，属于对粒径效应非单调性的综合归纳而非全新发现。其失效边界在于：若材料体系本身以表面 reactivity 为主导（如高镍含量或高温工况），则小粒径下的界面衰减更严重，最优尺寸可能向更大粒径偏移；反之，若电解液添加剂能有效钝化表面，则小粒径下的阻抗增长被抑制，倒U型关系可能减弱甚至消失。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['literature']
  - supporting_evidence: []
  - details: {'literature': {'match': True, 'support_level': 'literature', 'papers': ['p1', 'p161', 'p74'], 'values': [], 'source': 'knowledge_graph.md + paper_summaries.md'}}

---

### 5. 📚 单晶/多晶容量保持率翻转的粒径-电压-倍率耦合条件｜新知/已知：🟡 部分已知

**Confidence:** 0.55 | **Novelty:** 0.47 | **LLM Plausibility:** 0.65

**Description:** 针对Gap 1中单晶与多晶容量保持率结论相互矛盾的问题，提出一个可检验的耦合假设：单晶相对于多晶的容量保持率优势并非绝对，而是由粒径、截止电压、倍率和Ni含量共同决定。在低电压（≤4.2 V）低倍率（≤0.2C）下，单晶内部Li浓度不均匀和两相共存引起的结构缺陷可能占据主导，导致其保持率低于多晶；而在高电压（≥4.3 V）高倍率（≥1C）下，多晶晶间微裂纹快速扩展成为主要衰减机制，单晶的无晶界结构则表现出更高保持率。该假设可通过单晶vs多晶在不同粒径（1/3/5/10 μm）、电压（4.2/4.3/4.5 V）、倍率（0.1/0.5/1C）和Ni含量（0.7/0.8/0.9）下的正交矩阵实验验证。

**Expected Relationship:** 单晶容量保持率与多晶容量保持率的差值随截止电压和倍率升高而由负转正，存在一个临界电压和临界倍率；临界条件随Ni含量升高而降低。原因在于高电压高倍率放大多晶的晶间开裂，而单晶的连续无缝结构能抑制这种机械衰减，但在温和循环条件下，单晶内部Li分布不均成为更突出的衰减因素。

**Materials:** LiNi0.7Co0.1Mn0.2O2, LiNi0.8Co0.1Mn0.1O2, LiNi0.9Co0.05Mn0.05O2
**Property:** 循环容量保持率（如1C/4.3V/200圈后%）

**Source Gap:** Gap 1
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p1
  - p2
  - p62
  - p67
  - p121

**Scientific Explanation (LLM):**
> 该假设在机制上具有合理性：高截止电压与高倍率会加剧多晶颗粒内一次粒子间的各向异性收缩/膨胀，诱发生成晶间微裂纹并导致电接触恶化和副反应加剧，而单晶颗粒因无晶界连续结构可显著抑制此类机械衰减，因此单晶与多晶的容量保持率差值随电压和倍率升高由负转正；同时高镍材料因各向异性应变更大，使临界电压和临界倍率随Ni含量升高而降低。这一关系与文献中“单晶优于多晶在高电压下循环稳定性”的已知结论一致，但明确将“低电压/低倍率下单晶劣势”与“翻转临界条件”纳入同一框架，具有一定新知价值。其失效边界可能出现在极低倍率或较低截止电压下，此时晶间开裂被压制，单晶内部Li+浓度梯度导致的局部应变和不可逆相变反而主导衰减，使单晶容量保持率低于多晶；此外在超高倍率或极端低温下，动力学限制可能改变失效模式，使该翻转规律不再适用。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['literature']
  - supporting_evidence: []
  - details: {'literature': {'match': True, 'support_level': 'literature', 'papers': ['p1', 'p126', 'p153', 'p161', 'p74'], 'values': [], 'source': 'knowledge_graph.md + paper_summaries.md'}}

---
