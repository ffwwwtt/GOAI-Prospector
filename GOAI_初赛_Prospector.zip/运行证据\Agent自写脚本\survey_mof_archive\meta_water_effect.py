# 水效应二象性元分析：湿/干容量比 vs 吸附机制（假设 6）
# 数据从知识图谱 v2.0 + 论文摘要提取（湿/干比来自原文描述，Qst 为文献值）
print("=" * 100)
print("水效应二象性元分析：湿态/干态 CO2 容量比 vs 吸附机制（物理 OMS vs 化学胺）")
print("=" * 100)

# (材料, 机制, Qst kJ/mol, 湿/干比(估计), 证据来源, 备注)
data = [
    ("Mg-MOF-74",     "物理OMS", 47, 0.45, "p30,p49", "湿态竞争 OMS，容量显著下降"),
    ("ELM-11",        "物理柔性", 30, 0.40, "p152",   "水致亚相+非晶化，容量下降"),
    ("MIL-120(Al)",   "物理超微孔", 44, 0.92, "p160",  "1.118/1.215 mmol/g，轻微下降"),
    ("ZIF-94",        "物理无OMS", 25, 1.00, "p115",  "99.2% RH 分离时间≈干态，稳定"),
    ("CALF-20",       "物理", 30, 0.95, "p9",    "湿烟气稳定，轻微影响"),
    ("HP-PMOF-DETA",  "化学胺", None, 1.30, "p135", "湿态增强：碳酸氢盐路径"),
    ("PEI@MIL-100(Cr)","化学胺", None, 1.20, "p136", "湿态胺可及性提升"),
    ("MOF-808-Gly",   "化学胺", None, 1.40, "p158", "水促进，碳酸氢盐机制 NMR 证实"),
    ("mmen-Mg2(dobpdc)","化学胺", None, 1.25, "p168", "最优 RH 增强摄取"),
    ("TYUT-ATZ-β",    "水固定", 44, 1.50, "p164", "H2O 固定为 CO2 位点，100 循环"),
    ("胺化Mg/DOBDC",  "化学胺", None, 1.10, "p159", "ED 胺化 CUS 增强湿稳定性"),
]

print(f"\n{'材料':<18}{'机制':<10}{'Qst':>6}{'湿/干比':>8}  证据")
print("-" * 90)
for m, mech, qst, ratio, src, note in data:
    q = f"{qst}" if qst else "化学"
    print(f"{m:<18}{mech:<10}{q:>6}{ratio:>8.2f}  {src}  {note[:28]}")

phy = [d for d in data if d[1].startswith("物理") or d[1] == "水固定"]
chem = [d for d in data if d[1] == "化学胺"]
avg_phy = sum(d[3] for d in phy) / len(phy)
avg_chem = sum(d[3] for d in chem) / len(chem)

print(f"\n=== 定量对比 ===")
print(f"物理吸附体系（{len(phy)} 个）：平均湿/干比 = {avg_phy:.2f}（<1 负效应）")
print(f"化学胺体系（{len(chem)} 个）：平均湿/干比 = {avg_chem:.2f}（>1 正效应）")
print(f"符号翻转显著：{'是' if (avg_phy < 0.95 and avg_chem > 1.05) else '否'}")

print(f"\n=== 关键机制洞察 ===")
print("1. 判别变量是【化学胺位点的存在】，而非 Qst 本身：")
print("   - MIL-120（Qst=44，物理超微孔）湿/干=0.92 仍为负；TYUT-ATZ-β（Qst=44，水固定）湿/干>1 为正")
print("   → 相同 Qst 下符号不同 ⇒ Qst 不是充分判别量")
print("2. 负效应强度与 OMS 密度/亲水性相关：Mg-MOF-74（高 OMS 密度）湿/干≈0.45 远低于 MIL-120（0.92）")
print("3. 正效应机制（化学体系）：碳酸氢盐路径（p135,p158）、胺可及性提升（p136）、")
print("   水作为共吸附位点（p164）、最优 RH 窗口（p168）")
print("4. 修正假设 6 表述：符号翻转临界线应以【化学位点密度/胺负载量】为轴，而非 Qst")
