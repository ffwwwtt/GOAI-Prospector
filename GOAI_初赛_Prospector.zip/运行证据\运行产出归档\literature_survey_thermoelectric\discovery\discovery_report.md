# Structure-Property Relationship Discovery

**Generated:** 2026-08-02 14:05
**Total candidates explored:** 41
**Validated:** 0 | **Refuted:** 0
**Literature supported:** 3 | **Inconclusive:** 1 | **Pending:** 0
**Materials Project hits:** 0

## Search Summary

Explored 4 hypotheses via Bayesian optimization and MCTS; literature-supported 3. Model comparison available (hyp[3], n=9).

---

## Discovered Structure-Property Relationships

### 1. ❓ 分通道预测范式缩小ML与实验验证鸿沟｜新知/已知：🆕 全新

**Confidence:** 0.70 | **Novelty:** 0.80 | **LLM Plausibility:** 0.70

**Description:** 当前ML模型直接预测ZT虽取得高R²，但实验验证成功率低。本假设提出将ZT分解为S、σ、κ_e、κ_L分别预测后组合的方法，由于其内嵌物理约束（如Wiedemann-Franz定律、κ_L/κ平衡），跨体系外推能力更强。

**Expected Relationship:** 预期在留一材料系外推测试中，分通道模型的R²显著高于直接预测模型，且预测的高ZT候选经过实验验证的比例更高。因为分通道模型强制符合物理规律，减少外推时的非物理偏差。

**Materials:** 热电材料数据库（Starry, 160k数据集）
**Property:** ZT预测精度（R²/MAE）

**Source Gap:** Gap 3
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p1
  - p116
  - p19

**Scientific Explanation (LLM):**
> 分通道预测范式通过将热电性能分解为独立物理量（如电导率、塞贝克系数、热导率）分别建模，再合成ZT，迫使模型学习符合输运物理内在约束的映射关系，从而在留一材料系外推时避免直接预测ZT所容易产生的非物理组合偏差，这可能是其R²更高且候选材料实验验证成功率提升的机制基础。该思路与材料信息学中“物理约束注入可提升模型泛化性”的既有结论一致，但将其系统应用于大规模热电数据库并验证外推场景的优越性，属于对已有认知的实证拓展。其失效边界可能出现在某单一物性预测本身误差过大或材料系外推超出训练集化学空间时，此时分通道的误差传递效应反而会放大最终ZT偏差，且对载流子多机制耦合或强关联体系，独立分通道假设可能不再成立。

**External Validation:**
  - overall_match: False
  - validation_source: none
  - validation_notes: ['未找到任何数据库记录与文献证据支撑。']
  - databases_checked: []
  - supporting_evidence: []
  - details: {}

---

### 2. 📚 κ_L/κ≈0.5描述符的跨体系普适性验证｜新知/已知：🆕 全新

**Confidence:** 0.75 | **Novelty:** 0.65 | **LLM Plausibility:** 0.85

**Description:** 基于Starry数据统计，高ZT材料在κ_L/κ≈0.5附近聚集。本假设旨在验证该平衡点是否适用于PbTe、SnSe、Half-Heusler、Mg3Sb2、Bi2Te3等主流体系。若成立，则κ_L/κ可作为普适的优化描述符。

**Expected Relationship:** 预期各体系最优ZT对应的κ_L/κ均在0.5±0.15范围内；对于κ_L/κ>0.5的体系，降低κ_L能显著提升ZT；对于<0.5的体系，提升电子热导率（或功率因子）更有效。原因是声子与电子传导的平衡点由载流子输运和热输运的共同优化决定。

**Materials:** PbTe, SnSe, Half-Heusler, Mg3Sb2, Bi2Te3
**Property:** 晶格热导率与总热导率之比 (κ_L/κ)

**Source Gap:** Gap 1
**Search Method:** bayesian (30 iterations, 41 candidates)

**Evidence Chain:**
  - p19
  - p27
  - p48
  - p50
  - p77
  - p88

**Scientific Explanation (LLM):**
> 该构效关系可能成立的内在机制在于：热电优值ZT同时受功率因子、电子热导率与晶格热导率的耦合调控，而κ_L/κ反映了声子传导与电子传导在总热输运中的相对权重；当二者贡献接近时，载流子浓度对电输运和热输运的竞争性影响往往处于最优折中，因而最优ZT对应的κ_L/κ落在0.5附近并不意外。这一描述符本质上是对“声子-电子热输运平衡点”的量化，与文献中普遍认同的“晶格热导率并非越低越好，需兼顾电输运性能”的观点一致，属于对已有认知的跨体系归纳而非全新原理。其失效边界可能出现在两类情形：一是载流子有效质量或能谷简并度极高、导致功率因子对载流子浓度极度敏感时，最优ZT可能偏离该平衡点；二是强非谐性或声子-电子强耦合体系中，晶格热导率与电子输运的独立性假设不再成立，使得该比例关系无法单独作为普适判据。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['materials_project', 'nomad', 'literature']
  - supporting_evidence: []
  - details: {'materials_project': {'match': False, 'matching_entries': [], 'materials_found': [{'mp_id': 'mp-aaafngpc', 'formula': 'TePb', 'band_gap': 0.09700000000000042, 'formation_energy': -0.4682373150000032,

---

### 3. 📚 能带汇聚最优窗口的定量判据｜新知/已知：🔁 已有文献报道

**Confidence:** 0.60 | **Novelty:** 0.21 | **LLM Plausibility:** 0.70

**Description:** 能带汇聚可提升Seebeck系数和PF，但同时增加电子热导率κ_e。本假设预测存在一个最优带间距ΔE*，使PF增益与κ_e代价达到平衡，从而最大化ZT。可用于设计PbTe及类似体系。

**Expected Relationship:** 随着ΔE减小（能带汇聚增强），PF先近似线性增加随后趋于饱和，而κ_e近似线性增加，因此ZT作为ΔE的函数呈倒U型，最优ΔE*位于PF增益斜率与κ_e代价斜率交点处。该判据可定量指导掺杂浓度和组分选择。

**Materials:** PbTe, PbTe-Mg, PbTe-Sn, PbTe-Mn
**Property:** 热电优值ZT

**Source Gap:** Gap 4
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p27
  - p22
  - p24
  - p30

**Scientific Explanation (LLM):**
> 该假设的机制合理性在于：能带汇聚通过增加参与电输运的能谷简并度，在不显著改变载流子散射机制的前提下提升塞贝克系数和电导率的协同增益，使功率因子随能带间距ΔE减小而近似线性上升；但能带汇聚同时也会增大态密度有效质量和载流子浓度，导致电导率增大而电子热导率κ_e近似线性增加，因此ZT随ΔE变化存在极值，最优ΔE*出现在功率因子增益斜率与电子热导率代价斜率相等的平衡点。这一“最优窗口”思想与文献中PbTe基材料能带汇聚提升热电性能的已知结论一致，但将其定量化为基于斜率交点的判据属于对已有机制的细化与推广，可为掺杂和组分调控提供更明确的搜索方向。该判据的失效边界可能出现在强合金散射或声子-电子耦合显著的区域，此时电导率与κ_e的关系偏离线性，或当ΔE过小时能带完全合并导致有效质量突增和载流子迁移率急剧下降，功率因子饱和甚至回落，倒U型关系不再成立。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['materials_project', 'nomad', 'literature']
  - supporting_evidence: []
  - details: {'materials_project': {'match': False, 'matching_entries': [], 'materials_found': [{'mp_id': 'mp-aaafngpc', 'formula': 'TePb', 'band_gap': 0.09700000000000042, 'formation_energy': -0.4682373150000032,

---

### 4. 📚 以平均ZT代替峰值ZT作为材料优化指标｜新知/已知：🔁 已有文献报道

**Confidence:** 0.60 | **Novelty:** 0.18 | **LLM Plausibility:** 0.70

**Description:** 多数研究以峰值ZT为目标，但器件效率取决于工作温区上的平均ZT。本假设预测某些材料峰值ZT虽高但ZT(dev)低，而宽温区材料ZT_avg更高。通过统计可识别此类陷阱材料。

**Expected Relationship:** 预期ZT_avg与峰值ZT之间不存在强正相关；存在峰值高但ZT_avg低的材料（如窄温区显示高ZT），也存在峰值适中但ZT_avg高的材料（如宽温区平坦ZT曲线）。因此应采用ZT_avg作为优化指标。

**Materials:** SnSe, Bi2Te3, GeTe, Mg3Sb2
**Property:** 平均热电优值 ZT_avg

**Source Gap:** Gap 6
**Search Method:** bayesian (0 iterations, 0 candidates)

**Evidence Chain:**
  - p49
  - p122
  - p56

**Scientific Explanation (LLM):**
> 该假设的机制在于，热电材料的实际服役性能取决于其在工作温区内累积的转换效率，而峰值ZT仅反映单一温度点的最优表现；若材料仅在窄温区呈现尖锐的高ZT峰，其在宽温差场景下的平均效率必然受限，反之，宽温区内平坦且较高的ZT曲线往往能带来更高的ZT_avg，因此两者之间并非必然强正相关。这与已有文献中关于SnSe、Bi2Te3、GeTe、Mg3Sb2等材料的热电优化讨论趋势一致，即研究者已逐步认识到仅优化峰值ZT可能误导材料筛选，转而关注宽温域性能或平均ZT，因而该假设属于对现有认知的明确化与指标化，并非全新发现。其失效边界可能出现在材料应用温区极窄、且工作温度恰好固定在峰值附近的情形，此时峰值ZT与ZT_avg的差异对实际性能影响很小；此外，若材料性能随温度呈单调快速变化且温区跨度有限，峰值ZT仍可能近似代表平均性能，则该替代指标的优越性会减弱。

**External Validation:**
  - overall_match: True
  - validation_source: literature
  - validation_notes: ['无机数据库未覆盖/未命中时，文献证据链（≥2 篇独立论文）作为补充验证。']
  - databases_checked: ['materials_project', 'nomad', 'literature']
  - supporting_evidence: []
  - details: {'materials_project': {'match': False, 'matching_entries': [], 'materials_found': [{'mp_id': 'mp-aaacpcpc', 'formula': 'SnSe', 'band_gap': 0.23909999999999965, 'formation_energy': -0.44187147953125105

---
