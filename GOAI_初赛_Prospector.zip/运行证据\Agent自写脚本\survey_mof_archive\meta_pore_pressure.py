# 孔径-压力-容量元分析：从知识图谱提取数据点，检验 d* vs log10(P) 负相关（假设 4）
import numpy as np

# (材料, 孔径 Å, 压力 bar, 容量 mmol/g, 场景, 论文)
points = [
    ("ZU-16-Co (TIFSIX-3-Co)", 3.62, 0.01, 2.63, "DAC/痕量", "p78"),
    ("ZU-16-Co (TIFSIX-3-Co)", 3.62, 1.0, 2.87, "1bar", "p78"),
    ("SIFSIX-2-Cu-i", 3.8, 0.15, 2.5, "烟气/低压", "p82"),   # 估计孔径~3.8Å
    ("MIL-120(Al)", 4.78, 0.15, 1.215, "湿烟气", "p160"),
    ("TYUT-ATZ-β", 4.0, 0.15, 2.8, "湿烟气(62.7cm3/cm3≈2.8)", "p164"),  # 估计
    ("ZIF-94", 3.8, 1.0, 2.38, "1bar", "p115"),
    ("MOF-74(Ni)", 11.0, 1.0, 6.61, "1bar", "p17"),
    ("Ni1Co1-MOF-74", 11.0, 1.0, 8.30, "1bar", "p29"),
    ("agw Cu MOF", 15.0, 20.0, 21.2, "高压", "p151"),
    ("MOF-303", 8.0, 15.0, 12.35, "高压PSA", "p138"),
    ("MOF-177+TEPA", 12.0, 0.15, 4.2, "胺体系(化学)", "p40"),  # 化学吸附，标注
    ("PEI/MIL-101", 3.4, 0.15, 4.2, "胺体系(化学)", "p38"),
    ("CALF-20", 5.0, 0.15, 2.0, "湿烟气", "p9"),
]

print(f"{'材料':<24}{'孔径Å':>6}{'P(bar)':>8}{'q(mmol/g)':>10}{'场景':<16}{'log10P':>7}")
print("-" * 90)
# 分物理吸附（非胺体系）分析 d* vs P
phy = [p for p in points if "胺" not in p[4]]
for m, d, P, q, scen, src in points:
    print(f"{m:<24}{d:>6.2f}{P:>8.3f}{q:>10.2f}{scen:<16}{np.log10(P):>7.2f}")

print("\n=== 物理吸附体系：最优孔径 vs 压力窗口 ===")
for P_target, label in [(0.01, "DAC/痕量"), (0.15, "烟气"), (1.0, "1bar"), (15.0, "高压")]:
    # 找每个压力下容量最高的材料
    cands = [p for p in phy if abs(np.log10(p[1]) - np.log10(P_target)) < 1.0]
    if cands:
        best = max(cands, key=lambda p: p[2])
        print(f"  {label:<8} P~{P_target:>6.2f} bar → 最优孔径约 {best[1]:.1f} Å ({best[0]}, q={best[2]} mmol/g)")

print("\n=== 相关性检验：log10(P) vs 孔径（物理吸附体系） ===")
X = np.array([np.log10(p[2]) for p in phy])   # log10(压力)
Y = np.array([p[1] for p in phy])             # 孔径
corr = np.corrcoef(X, Y)[0, 1]
print(f"  数据点: {len(phy)} 个 | Pearson r = {corr:.3f}")
print(f"  → {'支持：最优孔径随压力降低而减小' if corr > 0.5 else '不支持'}")

# 不同压力下最优孔径区间估计
print("\n=== 压力-最优孔径带经验关系（物理吸附） ===")
for P_target, label in [(0.01, "DAC 400ppm"), (0.15, "烟气 15%"), (1.0, "1 bar"), (15.0, "高压 PSA")]:
    scored = sorted(phy, key=lambda p: -p[2] * np.exp(-0.5 * ((np.log10(p[1]) - np.log10(P_target)) / 0.8) ** 2))
    top3 = scored[:3]
    d_range = (min(p[1] for p in top3), max(p[1] for p in top3))  # p[1]=孔径
    mats = ", ".join(p[0].split(" (")[0] for p in top3)
    print(f"  {label:<14} P={P_target:>6.2f} bar → 孔径带约 {d_range[0]:.1f}-{d_range[1]:.1f} Å [{mats}]")
