# 提取新增论文（p121 起）的摘要到独立文件
import json, os

cache_dir = "workspace/data/literature_cache"
with open(os.path.join(cache_dir, "papers.json"), encoding="utf-8") as f:
    papers = json.load(f)

# 找到 p121 的起始位置（新增论文）
new_ids = sorted([pid for pid in papers.keys() if int(pid[1:]) > 120], key=lambda x: int(x[1:]))
lines = []
lines.append("# 新增论文摘要（p121–p166，第二轮补充检索）\n")
for pid in new_ids:
    info = papers[pid]
    lines.append(f"## {pid} — {info['title']}")
    if info.get("doi"):
        lines.append(f"- DOI: {info['doi']}")
    if info.get("source"):
        lines.append(f"- Source: {info['source']}")
    if info.get("abstract"):
        lines.append(f"\n{info['abstract']}")
    lines.append("\n---\n")

out = "workspace/outputs/literature_survey/paper_summaries_new.md"
with open(out, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
print(f"已生成 {out}，共 {len(new_ids)} 篇新增论文")
print(f"文件大小: {os.path.getsize(out)/1024:.0f} KB")
