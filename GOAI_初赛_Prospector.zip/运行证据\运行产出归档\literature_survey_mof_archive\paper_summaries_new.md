# 新增论文摘要（p121–p166，第二轮补充检索）

## p121 — Solvent-derived defects suppress adsorption in MOF-74
- DOI: 10.1038/s41467-023-38155-8
- Source: sciverse

Defects in metal-organic frameworks (MOFs) have great impact on their nano-scale structure and physiochemical properties. However, isolated defects are easily concealed when the frameworks are interrogated by typical characterization methods. In this work, we unveil the presence of solvent-derived formate defects in MOF-74, an important class of MOFs with open metal sites. With multi-dimensional solid-state nuclear magnetic resonance (NMR) investigations, we uncover the ligand substitution role of formate and its chemical origin from decomposed N,N-dimethylformamide (DMF) solvent. The placement and coordination structure of formate defects are determined by 13C NMR and density functional theory (DFT) calculations. The extra metal-oxygen bonds with formates partially eliminate open metal sites and lead to a quantitative decrease of N2 and CO2 adsorption with respect to the defect concentration. In-situ NMR analysis and molecular simulations of CO2 dynamics elaborate the adsorption mechanisms in defective MOF-74. Our study establishes comprehensive strategies to search, elucidate and manipulate defects in MOFs.

---

## p122 — Boosting the CO2 adsorption performance by defect-rich hierarchical porous Mg-MOF-74
- DOI: 10.1016/j.cej.2023.144052
- Source: sciverse

Adsorbents with high adsorption capacity and high selectivity are crucial for carbon capture, utilization and storage (CCUS) technology applied to industrial flue gas to reduce carbon emissions. In this paper, a defect-rich porous Mg-MOF-74 was synthesized by using the same method as described in [12]. The adsorption isotherm indicating that the weak coordination of Cl- may interfere with the normal coordination process of metal centers and organic ligands, which cause the formation of crystal defects. Through the analysis of a series of characterizations, ligand deletion of Mg-MOF-74 prepared with Mg2Et3H2O was confirmed, and the deleted ligand was found to be a functionalized Mg-MOF-74 with a surface area of 1.5m2 . This result is consistent with that led to mesopores accounting for 36.9% , and the width of mesopores reached 13.1nm . Compared with traditional Mg-MOF-74 the adsorption heat of CO2 at zero load of the defect-rich hierarchical porous Mg-MOF-74 increased from 36~kJ~mol-1 to 46~kJ~mol-1 , and the saturated adsorption capacity of CO2 under ambient conditions was increased from 100% to 150% . The adsorption energy of Mg-MOF-74 increased by 20% compared with that of the remaining Mg-MOF-74 ,which increased by 20 times. Compared with the saturated adsorption capacity for traditional Mg-MOF-74 the equivalent adsorption capacity of hierarchical porous Mg-MOF-74 only needs 17.9kpa, indicating that it is suitable for carbon capture operation in a real flue environment. Calculations of density functional theory (DFT) calculations were performed on the basis of the experimental results obtained from the literature, including the presence of defects, which is regarded to play a key role in improving the CO2 capture performance.

---

## p123 — Enhanced selective CO2 adsorption in MOFs: Balance between open metal sites concentration and pore size
- DOI: 10.1016/j.seppur.2025.134465
- Source: sciverse

---

## p124 — CO2: DIRECT AIR CAPTURE (DAC)
- DOI: 10.13140/rg.2.2.27253.84960
- Source: sciverse

---

## p125 — Machine Learned Force Field Modeling of Metal Organic Frameworks for CO2 Direct Air Capture
- DOI: 10.2172/2426624
- Source: sciverse

Direct air capture (DAC) is a method for removing CO2 directly from air. Metal organic frameworks (MOFs) have been studied as DAC sorbent materials because of their structural and chemical diversity. Thermodynamic calculations using classical force fields are often used to evaluate MOFs for their performance in separations such as CO2 capture. Machine-learned force fields (MLFFs) can use machine learning to form quantitative relationships between a material’s chemical structure and the forces and energies predicted by more accurate quantum mechanical calculations, such as dispersion-corrected density functional theory (DFT). These descriptions of forces and energies can be used to improve the accuracy of adsorption calculations. In this work, classical models were used to pre-screen MOFs for CO2 capture. DFT calculations were then used to examine the adsorption mechanism. Next, MLFF models were developed for MOFs to achieve DFT-level accuracy for the forces and energies associated with MOF flexibility and CO2 adsorption. These methods were parametrized based on thousands of DFT calculations of CO2 in flexible MOFs and used to predict MOF structural properties as well as CO2 adsorption properties.

---

## p126 — Design of Amine-functionalized Oxide Sorbents for Direct Air Capture of CO2
- DOI: 10.48448/dcn4-gz78
- Source: sciverse

Chemical processes that extract CO2 from the atmosphere – also referred to as direct air capture (DAC) technologies – offer potential to produce negative emissions technologies (NETs), which are needed to stabilize the climate. DAC, if rapidly developed and deployed alongside other NETs, can help bridge the transition to a predominantly renewable/nuclear energy future. In this lecture, I will describe the design and synthesis, characterization and application of new amine/oxide hybrid materials that we have developed as cornerstones of new technologies for the removal of CO2 from ultra-dilute streams such as air. These chemisorbents efficiently remove CO2 from such streams, and the CO2 capacities are not degraded by the presence of water, unlike in the case of physisorbents such as zeolites. Numerous materials design parameters such as amine type, amine density, support structure, and material stability will be explored.

---

## p127 — Metal Organic Framework Screening for Direct Air Capture of Ppm-Level Co2
- DOI: 10.2139/ssrn.4676495
- Source: sciverse

---

## p128 — Direct Air Carbon Capture Using Metal-Organic Frameworks (MOFs)
- DOI: 10.36561/ing.28.16
- Source: sciverse

Direct Air Carbon Capture (DACC) technology is used to remove CO₂ directly from the atmosphere, helping tackle climate change and excessive greenhouse gas emissions efficiently. In this study, a techno-economic analysis of DACC has been carried out, including its working mechanisms, energy needs, and costs, as well as a summary of the current research status. This research compares two leading metal-organic frameworks (MOFs) — MIL-101(Cr)-PEI-800 and mmen-Mg₂(dobpdc) — focusing on their energy consumption, CO₂ adsorption, and cost. This study investigates the performance of these MOFs in a temperature vacuum swing adsorption (TVSA) process, which cyclically varies temperature and pressure to capture CO₂ and regenerate adsorbents. Among all materials, mmen-Mg₂(dobpdc) achieves the best performance with a much higher capacity and a favourable nonlinear isotherm shape, indicating significantly improved efficiency and lower energy input. DACC systems based on advanced MOFs hold great promise for minimizing non-point source emissions and should thus be considered essential components of a climate change mitigation strategy. This study contributes to direct future research and development toward more efficient and cost-effective MOFs in DACC applications.

---

## p129 — Challenges and Opportunities: Metal–Organic Frameworks for Direct Air Capture
- DOI: 10.1002/adfm.202307478
- Source: sciverse

Global reliance on fossil fuel combustion for energy production has contributed to the rising concentration of atmospheric CO2, creating significant global climate challenges. In this regard, direct air capture (DAC) of CO2 from the atmosphere has emerged as one of the most promising strategies to counteract the harmful effects on the environment, and the further development and commercialization of this technology will play a pivotal role in achieving the goal of net‐zero emissions by 2050. Among various DAC adsorbents, metal–organic frameworks (MOFs) show great potential due to their high porosity and ability to reversibly adsorb CO2 at low concentrations. However, the adsorption efficiency and cost‐effectiveness of these materials must be improved to be widely deployed as DAC sorbents. To that end, this perspective provides a critical discussion on several types of benchmark MOFs that have demonstrated high CO2 capture capacities, including an assessment of their stability, CO2 capture mechanism, capture‐release cycling behavior, and scale‐up synthesis. It then concludes by highlighting limitations that must be addressed for these MOFs to go from the research laboratory to implementation in DAC devices on a global scale so they can effectively mitigate climate change.

---

## p130 — Modified metal–organic framework by a novel coordinatively unsaturated amine grafting mechanism for direct air capture of CO2
- DOI: 10.1016/j.cej.2022.140431
- Source: sciverse

This study aimed to improve the carbon dioxide \\((\\mathrm{CO}_{2})\\) capture and kinetics performance for direct air capture (CARE) technology. The CARE technology is a process of gasification, oxidation, and hydrolysis of ethanolamine (AEEA) to functionalize coordinatively unsaturated metal sites in MIL-100(Fe), UO-66(Fe), and MIL-100(Fe). Grating experiments indicated that the grafting process is the reaction between metal sites and hydrogen peroxide (HPO) molecules. The catalysts used were HPO and CO. The catalysts used were HPO and CO, which are both active catalysts for grafting without destroying the active site. Moreover, the adsorbed \\(\\mathrm{CO}_{2}\\) amounts of MFC-AEEA at \\(400~\\mathrm{ppm}\\) were \\(1.91\\mathrm{mmol / g}\\) of \\(−25^{\\circ}C\\) and \\(2.42\\mathrm{mmol / g}\\) of \\(0^{\\circ}C\\) and the structural decomposition temperature exceeded \\(300^{\\circ}C\\) . The catalytic activity of the catalysts was also increased by \\(15\\%\\) with increasing \\(\\mathrm{CO}_{2}\\) concentration. In addition, the internal heat and mass transfer processes were accelerated, resulting in low semi-adsorption times below 21 min. Moreover, \\(\\mathrm{CO}_{2}\\) capture cycles were established at \\(25^{\\circ}C\\) for adsorption and \\(80^{\\circ}C\\) for desorption. The results showed that the catalysts could efficiently generate more \\(1.66\\mathrm{mmol / g}\\) after seven cycles, demonstrating a renewable energy consumption and high stability.

---

## p131 — Suitability of a diamine functionalized metal–organic framework for direct air capture
- DOI: 10.1039/d3sc02554c
- Source: sciverse

The increase in the atmospheric carbon dioxide level is a significant threat to our planet, and therefore the selective removal of CO2 from the air is a global concern. Metal-organic frameworks (MOFs) are a class of porous materials that have shown exciting potential as adsorbents for CO2 capture due to their high surface area and tunable properties. Among several implemented technologies, direct air capture (DAC) using MOFs is a promising strategy for achieving climate targets as it has the potential to actively reduce the atmospheric CO2 concentration to a safer levels. In this study, we investigate the stability and regeneration conditions of N,N'-dimethylethylenediamine (mmen) appended Mg2(dobpdc), a MOF with exceptional CO2 adsorption capacity from atmospheric air. We employed a series of systematic experiments including thermogravimetric analysis (TGA) coupled with Fourier transformed infrared (FTIR) and gas chromatography mass spectrometer (GCMS) (known as TGA-FTIR-GCMS), regeneration cycles at different conditions, control and accelerated aging experiments. We also quantified CO2 and H2O adsorption under humid CO2 using a combination of data from TGA-GCMS and coulometric Karl-Fischer titration techniques. The quantification of CO2 and H2O adsorption under humid conditions provides vital information for the design of real-world DAC systems. Our results demonstrate the stability and regeneration conditions of mmen appended Mg2(dobpdc). It is stable up to 50% relative humidity when the adsorption temperature varies from 25-40 °C and the best regeneration condition can be achieved at 120 °C under dynamic vacuum and at 150 °C under N2.

---

## p132 — Cold Temperature Direct Air CO<sub>2</sub> Capture with Amine-Loaded Metal–Organic Framework Monoliths
- DOI: 10.1021/acsami.3c13528
- Source: sciverse

Zeolites, silica-supported amines, and metal-organic frameworks (MOFs) have been demonstrated as promising adsorbents for direct air CO2 capture (DAC), but the shaping and structuring of these materials into sorbent modules for practical processes have been inadequately investigated compared to the extensive research on powder materials. Furthermore, there have been relatively few studies reporting the DAC performance of sorbent contactors under cold, subambient conditions (temperatures below 20 °C). In this work, we demonstrate the successful fabrication of adsorbent monoliths composed of cellulose acetate (CA) and adsorbent particles such as zeolite 13X and MOF MIL-101(Cr) by a 3D printing technique: solution-based additive manufacturing (SBAM). These monoliths feature interpenetrated macroporous polymeric frameworks in which microcrystals of zeolite 13X or MIL-101(Cr) are evenly distributed, highlighting the versatility of SBAM in fabricating monoliths containing sorbents with different particle sizes and density. Branched poly(ethylenimine) (PEI) is successfully loaded into the CA/MIL-101(Cr) monoliths to impart CO2 uptakes of 1.05 mmol gmonolith-1 at -20 °C and 400 ppm of CO2. Kinetic analysis shows that the CO2 sorption kinetics of PEI-loaded MIL-101(Cr) sorbents are not compromised in the monoliths compared to the powder sorbents. Importantly, these monoliths exhibit promising working capacities (0.95 mmol gmonolith-1) over 14 temperature swing cycles with a moderate regeneration temperature of 60 °C. Dynamic breakthrough experiments at 25 °C under dry conditions reveal a CO2 uptake capacity of 0.60 mmol gmonolith-1, which further increases to 1.05 and 1.43 mmol gmonolith-1 at -20 °C under dry and humid (70% relative humidity) conditions, respectively. Our work showcases the successful implementation of SBAM in making DAC sorbent monoliths with notable CO2 capture performance over a wide range of sorption temperatures, suggesting that SBAM can enable the preparation of efficient sorbent contactors in various form factors for other important chemical separations.

---

## p133 — Direct air capture of CO2 in designed metal-organic frameworks at lab and pilot scale
- DOI: 10.1016/j.ccst.2023.100145
- Source: sciverse

The direct air capture (DAC) of CO2 is a promising strategy for decelerating the growing concentration of atmospheric CO2 to control global warming. However, DAC remains a grand challenge, calling for technologies with high CO2 capture capacity at ultra-low partial pressure (around 400 ppm) under humid conditions. Recently, metal-organic frameworks (MOFs) have been demonstrated as outstanding sorbents for gas capture and separation owing to their intrinsic porous properties. MOFs have been widely studied for CO2 capture from industrial gas mixtures, but DAC has more demanding recognition capacity, selectivity and efficiency requirements. In this review, we extensively summarize the current progress in designing MOFs for DAC at both laboratory and pilot scales, with specific attention to structure design strategies for enhancing CO2 capture at low partial pressures, and detailed discussion on efficient CO2/H2O capture selectivity or CO2-H2O co-capture at a molecular level. In addition, the thermodynamic process, design of a reactor for DAC via MOFs and related practical examination for pilot-scale studies are highlighted, and current challenges and prospects are elaborated upon.

---

## p134 — Capturing carbon dioxide from air by using amine-functionalized metal-organic frameworks
- DOI: 10.1016/j.cjsc.2024.100267
- Source: sciverse

---

## p135 — Constructing Amine-Functionalized Hierarchically Porous Porphyrin-Based Metal–Organic Frameworks for Highly Enhanced Direct Air Capture of CO<sub>2</sub>
- DOI: 10.1021/acsami.5c11754
- Source: sciverse

Direct air capture (DAC) of carbon dioxide (CO 2 ) has emerged as a prominent negative carbon emission technology for mitigating the greenhouse effect. Among various adsorbents, amine-functionalized metal–organic frameworks (MOFs) have shown exciting potential as adsorbents for atmospheric CO 2 capture. However, the intrinsic microporosity of many MOFs restricts amine loading and uniform dispersion, diminishing the CO 2 adsorption efficiency. In this study, we synthesized a series of hierarchically porous porphyrin-based MOF (HP-PMOF) featuring high-density defects and a combination of micro- and meso- and macropores. The HP-PMOF was subsequently functionalized with short-chain alkyl amines (diethylenetriamine (DETA) and tetraethylenepentamine (TEPA)) and polyamines (polyethylenimine (PEI)) to form HP-PMOF–Amine composites. Evaluations of these adsorbents demonstrated a significantly enhanced CO 2 capture performance in DAC applications. Static CO 2 adsorption isotherms revealed that HP-PMOF–DETA achieved the highest CO 2 uptake of 1.40 mmol g –1, representing increases of 140 and 20 times over unmodified PMOF and HP-PMOF, respectively. Dynamic DAC performance measurements showed that HP-PMOF–DETA maintained 84% regeneration efficiency after ten cycles under 400 ppm of CO 2 . Breakthrough tests demonstrated enhanced CO 2 adsorption capacity across varying relative humidity (0–80%) compared with dry conditions. Mechanistic insights from in situ DRIFTS studies and DFT calculations indicated that, under dry conditions, physisorption and chemisorption synergistically occur between CO 2 and amine groups of DETA, forming carbamate or carbamic acid species. Under humid conditions, water facilitated the adsorption of CO 2 by promoting the conversion of ammonium carbamate to bicarbonate. This work underscores the significant potential of amine-functionalized hierarchically porous MOFs for advancing the efficacy of DAC technologies.

---

## p136 — Efficient and stable direct air capture with amine-functionalized MIL-100(Cr) metal-organic framework
- DOI: 10.1016/j.efmat.2025.02.003
- Source: sciverse

Metal–organic frameworks (MOFs) are promising for Direct Air Capture (DAC) due to their tunable pore structures, large surface areas, and chemical functionalization. Amine-functionalized MOFs significantly enhance CO 2 adsorption, yet most studies focus on adsorption capacity, with limited research on the impacts of water vapor and oxidative stability in practical DAC applications. Herein, MIL-100(Cr) was modified with polyethyleneimine (PEI), tetraethylenepentamine (TEPA), and diethanolamine (DEA) via impregnation, and their CO 2 capture performance under DAC conditions was systematically evaluated, including adsorption capacity, cyclic stability, water resistance, and oxidative stability. PEI-modified MIL-100(Cr) exhibited the best CO 2 adsorption capacity, achieving 1.21 mmol g −1 at the same level of amine incorporation and retained over 90 % of its initial capacity after 20 cycles. Under humid conditions, the CO 2 adsorption performance of solid amine materials was further improved, due to the enhanced utilization of amine sites, particularly increased accessibility of secondary amines. Furthermore, the PEI-modified MIL-100(Cr) exhibited superior oxidative stability compared to TEPA-modified adsorbents. This study provides valuable insights for optimizing MOF-based adsorbents in practical DAC applications. • MIL-100(Cr) was modified with PEI, TEPA, and DEA by impregnation. • CO 2 uptake over Cr-50%PEI reaches 1.21 mmol g −1 with better adsorption and stability. • Humid conditions enhance CO 2 adsorption by improving amine efficiency. • Cr-50%PEI exhibits strong coordination and high oxidative stability.

---

## p137 — Evaluating metal–organic frameworks for post-combustion carbon dioxide capture via temperature swing adsorption
- DOI: 10.1039/c1ee01720a
- Source: sciverse

Two representative metal–organic frameworks, Zn4O(BTB)2 (BTB3− = 1,3,5-benzenetribenzoate; MOF-177) and Mg2(dobdc) (dobdc4− = 1,4-dioxido-2,5-benzenedicarboxylate; Mg-MOF-74, CPO-27-Mg), are evaluated in detail for their potential use in post-combustion CO2 capture via temperature swing adsorption (TSA). Low-pressure single-component CO2 and N2 adsorption isotherms were measured every 10 °C from 20 to 200 °C, allowing the performance of each material to be analyzed precisely. In order to gain a more complete understanding of the separation phenomena and the thermodynamics of CO2 adsorption, the isotherms were analyzed using a variety of methods. With regard to the isosteric heat of CO2 adsorption, Mg2(dobdc) exhibits an abrupt drop at loadings approaching the saturation of the Mg2+ sites, which has significant implications for regeneration in different industrial applications. The CO2/N2 selectivities were calculated using ideal adsorbed solution theory (IAST) for MOF-177, Mg2(dobdc), and zeolite NaX, and working capacities were estimated using a simplified TSA model. Significantly, MOF-177 fails to exhibit a positive working capacity even at regeneration temperatures as high as 200 °C, while Mg2(dobdc) reaches a working capacity of 17.6 wt % at this temperature. Breakthrough simulations were also performed for the three materials, demonstrating the superior performance of Mg2(dobdc) over MOF-177 and zeolite NaX. These results show that the presence of strong CO2 adsorption sites is essential for a metal–organic framework to be of utility in post-combustion CO2 capture via a TSA process, and present a methodology for the evaluation of new metal–organic frameworks via analysis of single-component gas adsorption isotherms.

---

## p138 — Advanced metal–organic framework materials for efficient CO2/CH4 separation using pressure swing adsorption – numerical study
- DOI: 10.1007/s10450-026-00672-5
- Source: sciverse

Abstract Efficient CO₂ separation from biogas is essential for enhancing methane quality and supporting sustainable energy production. In this study, CO₂/CH₄ separation is investigated using a one-dimensional computational fluid dynamics model implemented in COMSOL Multiphysics and validated against published experimental data for MIL-53(Al). Several metal–organic frameworks, including MOF-303, MIL-160, aluminum fumarate, HKUST-1, and UIO-66, are systematically compared under identical operating conditions. The results demonstrate that MOF-303 exhibits the highest CO₂ selectivity and adsorption capacity, achieving an equilibrium uptake of 12.35 mol/kg at 15 bar and 298 K, significantly outperforming the other investigated materials. Building on this finding, the model is further applied to examine the influence of bed geometry on CO₂ capture using MOF-303. The analysis reveals that increasing bed length while reducing bed diameter substantially enhances adsorption performance, with a maximum uptake of 42.15 kg CO₂ per kg of MOF per day at an optimized geometry. These results demonstrate the combined importance of adsorbent selection and bed design and provide new insights into the optimization of MOF-based PSA systems for high-efficiency biogas upgrading.

---

## p139 — Discrimination of Hexane Isomers by Temperature Swing Adsorption in a Rigid Aluminum Metal–Organic Framework
- DOI: 10.1021/acsmaterialslett.6c00119
- Source: sciverse

The efficient separation of alkane isomers with similar physicochemical properties remains a persistent challenge for the petrochemical industry. Adsorptive separation using metal-organic frameworks (MOFs) offers an energy-efficient alternative to conventional distillation. Herein, we report temperature swing discrimination of hexane isomers with different degrees of branching using MIL-120, a rigid aluminum pyromellitate-based MOF. MIL-120 features uniform one-dimensional channels with an aperture of ∼5.5 Å. At 30 °C, it selectively adsorbs linear and monobranched hexanes while excluding the dibranched isomer. Upon heating to 120 °C, both mono- and dibranched isomers are completely excluded, whereas linear hexane remains strongly adsorbed. Breakthrough experiments validate the temperature swing separation performance. Adsorption heat analysis combined with ab initio calculations provides a quantitative measure of distinct differences in adsorption enthalpies, binding energies, and diffusion barriers responsible for the observed separation efficiency, highlighting the potential of this MOF for efficient separation of alkane isomers via temperature swing adsorption.

---

## p140 — Metal-Organic Framework Targeting for Optimal Pressure Swing Adsorption Processes
- DOI: 10.1016/b978-0-323-85159-6.50049-x
- Source: sciverse

---

## p141 — Tailoring Electrical Conductivity of Metal-Organic Frameworks for Electrothermal Swing Adsorption Applications
- DOI: 10.7939/81886
- Source: sciverse

Metal-organic frameworks (MOFs), particularly CuBTC, have shown the potential to revolutionize pollution control. CuBTC, in particular, has demonstrated superior efficiency and selectivity in removing volatile organic compounds (VOCs) from the air. However, the low thermal stability and strong affinities of MOFs with adsorbed materials complicate the recovery and reuse of the adsorbents. Electrothermal regeneration utilizes the adsorbent's electrical resistivity against the electrical current to heat it, enabling rapid release and recovery of the adsorbate. However, it is not typically suitable for most MOFs due to their inherent electrical insulating properties, which hinder their ability to conduct electricity and generate heat. The first phase of this study focused on the adsorption capabilities of CuBTC and FeBTC, two well-known MOFs with the same organic ligand but different metal centers. CuBTC, with its larger surface area, displayed higher efficiency at lower concentrations. FeBTC, on the other hand, showed a comparable ability to adsorb VOCs at higher concentrations, likely due to its larger pore volume. The study also noted challenges in regenerating these MOFs after 2-methylpyridine adsorption, likely due to strong chemisorption. However, effective desorption with other VOCs suggests that these adsorbents could be regenerated. These findings underscore the pollution control potential of CuBTC and FeBTC. The second phase of this study was dedicated to improving CuBTC's electrical conductivity to facilitate electrothermal regeneration. By integrating carbon nanotubes (CNTs), porous carbon, and graphene during the synthesis process, the study achieved an electrical resistivity within the targeted range of 0.1 to 10 Ω.m while maintaining the MOF's adsorption properties. Notably, modifications with porous carbon effectively preserved CuBTC's surface area and adsorption capabilities, balancing between reduced electrical resistivity and adsorption capacity. The second objective of the research's second phase was to examine various techniques for modifying CuBTC's electrical resistivity, including in-situ solvothermal, in-situ sonication methods, and post-synthesis modifications. X-ray diffraction (XRD) analysis confirmed that CuBTC's fundamental crystalline structure was preserved, while transmission electron microscopy (TEM) images demonstrated the even distribution of carbon-based materials. Additionally, TEM images revealed that the sonication-assisted synthesis method effectively prevented carbon cluster formation and thus reduced electrical resistivity. Thermogravimetric analysis (TGA) was employed to determine the thermal stability and amount of the modifiers in the final products, confirming their efficacy and ensuring sample durability under operational conditions. The study found that incorporating moderate amounts of carbonaceous modifiers, particularly through sonication, balanced the adsorption capabilities and resistivity of CuBTC. This drawback highlighted the superior effectiveness of carbon-based materials in achieving desired electrical characteristics while maintaining efficient adsorption properties. In the third phase, electrothermal heating regeneration was compared to traditional thermal regeneration. CNT and porous carbon were incorporated into CuBTC and optimized for the best adsorption and electrothermal regeneration performance. Techniques used included in-situ sonication with CNT, in-situ solvothermal method with porous carbon, and post-synthesis physical mixing of porous carbon with CuBTC. These modifications reduced CuBTC's electrical resistivity while retaining its adsorption capacity. CuBTC was subjected to multiple adsorption-desorption cycles using traditional thermal and electrothermal regeneration techniques, effectively releasing adsorbed VOCs in both methods. However, the electrothermal regeneration process consumed considerably less energy and accelerated the regeneration process. This efficiency allows for shorter cycle times for continuous operation and demonstrates higher desorption efficiencies than traditional methods. In conclusion, various modification methods were investigated to introduce electrical conductivity into MOFs while maintaining their adsorption characteristics. These methods were successful in producing samples that allowed for electrothermal regeneration. Adding carbonaceous modifiers to CuBTC has preserved its adsorptive properties while reducing its electrical resistivity, making it suitable for electrothermal regeneration processes. Electrothermal regeneration reached the desorption temperature of 120 °C in 13 to 15 minutes, with heating rates ranging from 8.2 to 9.6 °C per minute. The conventional method reached the same temperature in 48 minutes, with a heating rate of approximately 2.5 °C per minute. Over a 2-hour regeneration period, electrothermal regeneration consumed considerably lower energy than conventional, ranging from 142 to 242 kJ/g depending on the sample, compared to a consistent 600 kJ/g used by the conventional method. The electrothermal regeneration technique has outperformed conventional heating methods' energy efficiency and speed, promoting more sustainable and effective pollution control practices.

---

## p142 — Machine Learning the Hydrogen Adsorption Capacity of Metal Organic Frameworks
- DOI: 10.26434/chemrxiv-2025-mccz2
- Source: sciverse

High-throughput virtual screening and machine learning (ML) are powerful tools for accelerating the discovery of nanoporous adsorbents for gas storage applications, including metal-organic frameworks (MOFs). Besides the nature of the data and the models, ML performance is strongly dependent on the MOF representation. In this work, we extended the molecular atom-atom, bond-bond, bond-atom (AABBA) autocorrelations to generate vector representations of MOFs for ML models. AABBA vectors encoded both the atomic and bond properties of the MOF metal nodes and linkers, enhancing accuracy in the prediction of gas storage properties. In particular, we computed the gravimetric and volumetric adsorption capacities for the adsorption of hydrogen into 11,500 MOFs. The data, which is made openly available together with the ML models code, was computed with Grand Canonical Monte Carlo simulations to train neural networks predicting the isothermal hydrogen deliverable capacity at room temperature. Further, feature engineering based on a gradient boosting algorithm highlighted the benefits of reducing the dimensionality of the AABBA representation, while keeping the autocorrelation of the bond properties.

---

## p143 — Remarkable CO2/CH4 selectivity and CO2 adsorption capacity exhibited by polyamine-decorated metal–organic framework adsorbents
- DOI: 10.1039/c3cc43352h
- Source: sciverse

Solid porous dual amine-decorated metal-organic framework (MOF) adsorbents with tunable porosity have been prepared. The adsorbents exhibit remarkable CO2/CH4 selectivity and CO2 adsorption capacity at low pressures.

---

## p144 — Modeling of CO2 adsorption capacity by porous metal organic frameworks using advanced decision tree-based models
- DOI: 10.1038/s41598-021-04168-w
- Source: sciverse

In recent years, metal organic frameworks (MOFs) have been distinguished as a very promising and efficient group of materials which can be used in carbon capture and storage (CCS) projects. In the present study, the potential ability of modern and powerful decision tree-based methods such as Categorical Boosting (CatBoost), Light Gradient Boosting Machine (LightGBM), Extreme Gradient Boosting (XGBoost), and Random Forest (RF) was investigated to predict carbon dioxide adsorption by 19 different MOFs. Reviewing the literature, a comprehensive databank was gathered including 1191 data points related to the adsorption capacity of different MOFs in various conditions. The inputs of the implemented models were selected as temperature (K), pressure (bar), specific surface area (m2/g) and pore volume (cm3/g) of the MOFs and the output was CO2 uptake capacity (mmol/g). Root mean square error (RMSE) values of 0.5682, 1.5712, 1.0853, and 1.9667 were obtained for XGBoost, CatBoost, LightGBM, and RF models, respectively. The sensitivity analysis showed that among all investigated parameters, only the temperature negatively impacts the CO2 adsorption capacity and the pressure and specific surface area of the MOFs had the most significant effects. Among all implemented models, the XGBoost was found to be the most trustable model. Moreover, this model showed well-fitting with experimental data in comparison with different isotherm models. The accurate prediction of CO2 adsorption capacity by MOFs using the XGBoost approach confirmed that it is capable of handling a wide range of data, cost-efficient and straightforward to apply in environmental applications.

---

## p145 — Evaluation of diamine-appended metal-organic frameworks for post-combustion CO2 capture by vacuum swing adsorption
- DOI: 10.1016/j.seppur.2018.10.015
- Source: sciverse

Five different diamine-sapped metal-organic frameworks (MOFs) that show a S-shaped CO2 isotherm are evaluated for post-combustion CO2 capture from dry flue gas using a vacuum swing adsorption process. A 1000 molar volume of the MOF was used as a reference. The MOF was treated with 15% H2O2 for 30min to achieve an optimal optimization to maximize CO2 purity and recovery showed a key link between the feed temperature, evacuation pressure and process performance. The MOFs that achieve a target CO2 purity ≥90% and recovery ≥90% were selected. The MOF was then used as a reference for the feed temperature, evaporation pressure and recovery rate. The adsorbent, menon-Mn60(diblock), menon-Mg60(diblock) and Zedite 13× showed minimum parasitic energies of 142, 152 and 167kWh / zoneCO2 cusp, respectively and maximum productivity of 0.4, 0.45 and 0.65mMCO2·a−1s−1, respectively while achieving CO2 purity ≥95% and recovery ≥98%. The MOF with the unique shape of the CO2 isotherm were found to be the key reasons for a linear energy consumption.

---

## p146 — Mesoporous Metal–Organic Frameworks with Exceptionally High Working Capacities for Adsorption Heat Transformation
- DOI: 10.1002/adma.201704350
- Source: sciverse

Pore size is one of the most important parameters of adsorbents, and mesoporous materials have received intense attention for large guests. Here, a series of mesoporous coordination polymers underlying a new framework prototype for fast expansion of pore size is reported and the profound effect of pore size on adsorption heat transformation is demonstrated. Three isostructural honeycomb-like frameworks are designed and synthesized by combining ditopic linear metal oxalate chains and triangular tris-pyridine ligands. Changing the ligand bridging length from 5.5 to 8.6 and 9.9 Å gives rise to effective pore diameter from 20 to 33 and 37 Å, surface area from 2096 to 2630 and 2749 m2 g-1 , and pore volume from 1.19 to 1.93 and 2.36 cm3 g-1 , respectively. By virtue of the unique and tunable isotherm shape of mesopores, exceptionally large working capacity up to 1.19 g g-1 or 0.38 g cm-3 for adsorption heat transformation can be achieved using R-134a (1,1,1,2-tetrafluroethane) as a working fluid.

---

## p147 — A metal-organic framework (MOF)-based temperature swing adsorption cycle for postcombustion CO2 capture from wet flue gas
- DOI: 10.1016/j.ces.2021.117399
- Source: sciverse

We report a simulation-based feasibility study of a single-stage temperature swing adsorption (TSA) process for the removal of NOx from a coal-fired power plant. The TSA process involves a two-stage process: first, the steam is cooled from a wet flue gas without pre-drying as a desiccant pre-layer. Two cycles comprising four and five steps are compared. A non-isothermal and non-isobaric in-house simulator including suitably modeled by the TSA model [15] are used to simulate the process. The TSA model is based on 2000-2001 data from 3000-4000 years of data. The variables investigated are moisture-saturated fugas at two feed and three regeneration temperatures. The TSA model is based on 1998-2001 data from 1998-2001. The TSA model is based on 2000-2001 data from 2000-2001. The wet flue gas from a coal-fired power plant (after SO2/NOx removal). The maximum productivity attained is 9.8kgCO2m−3adsorberh−1 for 153CO2, 82% N2, and 35H2O fed at 25°C (i.e., 95% relative humidity). The TSA model is based on 1998-2001 data from 1998-2001.

---

## p148 — Estimation of CO2 adsorption in high capacity metal−organic frameworks: Applications to greenhouse gas control
- DOI: 10.1016/j.jcou.2020.101256
- Source: sciverse

In recent decades, adsorption of high amounts of carbon dioxide (CO2) in metal-organic frameworks (MOFs) has received attention and is studied broadly. As a main principle, most scientists have accepted that CO2 can be absorbed into the atmosphere by the adsorbed species. The adsorption process is a complex process involving multiple potential of Particle Swarm Optimization Adaptive Neuro-Fuzzy Inference System (PSO-ANFIS), Differential Evolution-ANFIS (DE-ANFIS), Radial Basis Function Artificial Neural Network (RBF-ANN) and Least Squares Regression (LSRR). The LSRR approach is used to estimate the adsorption rate of MOFs on the surface of the adsorbent. The pressure (P) supplemented with the property of MOFs was investigated. The inputs of the models are temperature, pressure, surface area and pore volume of MOFs. An extensive databank containing 506 data gathered from the literature was used for models development. The obtained SAARD values for the developed models are shown in Table 1. The results show that the model is able to predict the adsorption rate of MOFs. This analysis demonstrated that operational pressure and pore volume of MOFs are the most effective parameters on CO2 adsorption by MOFs. It is found that LSSVM model is an outstanding tool for estimating adsorption of CO2 in the atmosphere. The proposed method is based on the LSRR approach and is used for modeling MOFs, which is straightforward, capable and cost-efficient.

---

## p149 — Computational exploration of metal–organic frameworks for CO2/CH4 separation via temperature swing adsorption
- DOI: 10.1016/j.ces.2014.08.003
- Source: sciverse

Molecular simulations were performed to investigate the performance of 151 metal-organic frameworks (MOFs) with large chemical and topological diversity on CO2/CH4 separation via temperature swing. The MOFs were prepared by using a single-step process, including removal of the target criterion and combined with other three commonly used ones (CO), working capacity, adsorption selectivity and regenerability) to explore the structure-property relationships for the separation of the target system. The results show that the four evaluation criteria exhibit intimate correlations with the performance of MOFs. The MOF properties are also well characterized by the following characteristics: The range of this parameter, it can be used as a good indicator for the preliminary screening of MOFs and the tailoring of new materials. Furthermore, from the structural database considered in current study, CuO is one of the most promising materials to possess the best performance by taking into account thermal and water-stable properties into account.

---

## p150 — Experimental Results of Pressure Swing Adsorption (PSA) for Pre-combustion CO2 Capture with Metal Organic Frameworks
- DOI: 10.1016/j.egypro.2017.03.1364
- Source: sciverse

Vacuum Pressure Swing Adsorption (VPSA) has already proved that it can be used for capture of CO2 from the tail gas of the PSA process for hydrogen purification. The demo operated in Port Arthur by Air Products has already captured more than 1 million metric tons of CO2. In this work we are evaluating the utilization of a formulated metal-organic framework (UTSA-16) for capture of CO2 from steam-methane reforming off-gases with the aim of selectively capture CO2, while allowing hydrogen and other components to pass through it, aiming to remove the requirement of vacuum for CO2 capture in this application. We have measured quaternary breakthrough curves with 76% H2, 17% CO2, 3% CH4 and 4% CO simulating the off-gas of a typical steam-methane reformer. We have also simulated the results using a mathematical model that constitutes the basis for design and improvement of the PSA unit.

---

## p151 — A highly porous agw-type metal–organic framework and its CO2 and H2 adsorption capacity
- DOI: 10.1039/c3ce41119b
- Source: sciverse

An unsymmetrical tricarboxylate ligand with linking alkyne moiety has been used to construct a highly porous metal–organic framework with agw topology. The obtained Cu(II) MOF exhibits a high BET surface area of 3337.0 m2 g−1, a large capacity of CO2 (21.2 mmol g−1 at 298 K and 20 bar) and a good H2 adsorption (5.8 wt% at 77 K and 20 bar).

---

## p152 — Mechanism of CO2 Capacity Reduction of Flexible Metal-Organic Framework Caused by Water Adsorption
- DOI: 10.3389/fmats.2022.825592
- Source: sciverse

Elastic layer-structured metal-organic framework (MOF)-11 {ELM-11: [Cu(BF4)2 (4,4′-bipyridine)2]}, which is a crystalline porous material, is a promising adsorbent for high-throughput and high-efficiency separation processes of CO2 because of its peculiar adsorption characteristics originating from the flexibility of the crystal framework. However, the exposure of ELM-11 to water vapor has been reported to reduce its CO2 capacity, which is problematic for processing feed gases that contain a certain concentration of water vapor. In this study, we investigated the stability of ELM-11 against water vapor exposure to reveal the mechanism of CO2 capacity reduction. Our combined measurements of adsorption isotherms and X-ray diffraction patterns indicated that the CO2 capacity reduction was caused by the partial formation of a crystalline subphase upon adsorption of water molecules and the subsequent formation of an amorphous phase to relax the crystalline grain boundaries. Because a higher supply rate of water molecules resulted in a larger amount of subphase formation, we concluded that the structural subphase was a metastable kinetically controlled structure, formed through the rate-dependent adsorption of water molecules. These results suggest that slowing the adsorption rate is an effective approach to suppress the formation of the subphase; therefore, we proposed the covering of ELM-11 surfaces with porous shells. We used ELM-12 {[Cu(CF3SO3)2 (4,4′-bipyridine)2]} as a shell material because of its robust stability against water adsorption and affinity with ELM-11. The ELM-12 shell decreased the adsorption rate of water molecules compared with that of bare ELM-11, resulting in the suppression of subphase formation and preventing CO2 capacity reduction. Although further optimization of the shell thickness and coverage is required to keep the capacity completely unchanged, controlling the adsorption rate of water molecules is successfully demonstrated to be possible with shell formation, which is key for industrial applications of ELM-11.

---

## p153 — Hydrogen Adsorption on PCN‐250(Fe) Metal Organic Framework: Temperature and Pressure Swings
- DOI: 10.1002/masy.202300036
- Source: sciverse

This manuscript is reporting hydrogen adsorption uptake of PCN‐250(Fe) metal organic framework (MOF) at temperature of 300, 126K, and pressure in between 6 and 10bar. X‐ray diffraction spectrum of PCN‐250(Fe) confirms crystalline structure, however Fourier transform infrared (FT‐IR) spectrum showing dominant bonding structure of COOH, N = N, and Fe─O functional groups. SEM images confirm surface morphology as an octahedrons of average crystalline size upto 50µm. Thermogravimetric analysis (TGA) confirms excellent thermal stability upto 450°C. The hydrogen adsorption uptake of 0.80 wt% has been found at 126 K and pressure of 10bar attributes adsorption occurs due to the structural and physical properties like topology, porosity, and presence of open metal sites as well as surface area.It is suggested that PCN‐250(Fe) as an adsorbent material offers as an intensive way of storing H2atlow temperature and at ambient pressure.

---

## p154 — Charting the CO2 capture performance of a phase-change metal-organic framework in a pressure-vacuum swing adsorption process
- DOI: 10.26434/chemrxiv-2023-zx95t
- Source: sciverse

Metal-organic frameworks (MOFs) that display step-shaped adsorption isotherms, i.e., phase-change MOFs, represent a relatively small subset of all known MOFs. Yet, they are rapidly emerging as promising sorbents to achieve excellent gas separation performances with little energy demand. In this work, we assessed F4_MIL-140A(Ce), a recently discovered phase-change MOF adsorbent for CO2 capture in two scenarios using a pressure-vacuum swing adsorption process, namely a coal-fired power plant flue gas (12.5 %mol CO2), and a steel plant flue gas (25.5 %mol CO2). Four CO2 and three N2 adsorption isotherms were collected on F4_MIL-140A(Ce) over a range of temperatures and modelled using a bespoke equation for step-shaped isotherms. We accurately measured the heat capacity of F4_MIL-140A(Ce), a key thermodynamic property for a sorbent, using a method based on differential scanning calorimetry that overcomes the issues associated with the poor thermal conductivity of MOF powders. We then used these experimental data as input in a process optimisation framework and we compared the CO2 capture performance of F4_MIL-140A(Ce) to that of other “canonical” sorbents, including, zeolite 13X, activated carbon and three MOFs (i.e., HKUST-1, UTSA-16 and CALF-20). We found that F4_MIL-140A(Ce) outranks other sorbents, in terms of recovery and purity, in most of the simulated process conditions. We attribute such promising performance to the non-hysteretic step-shaped isotherm, the low uptake capacity for N2 and the mild heat of CO2 adsorption displayed by F4_MIL-140A(Ce).

---

## p155 — Data-driven design of metal–organic frameworks for wet flue gas CO2 capture
- DOI: 10.1038/s41586-019-1798-7
- Source: sciverse

Limiting the increase of CO2 in the atmosphere is one of the largest challenges of our generation1. Because carbon capture and storage is one of the few viable technologies that can mitigate current CO2 emissions2, much effort is focused on developing solid adsorbents that can efficiently capture CO2 from flue gases emitted from anthropogenic sources3. One class of materials that has attracted considerable interest in this context is metal-organic frameworks (MOFs), in which the careful combination of organic ligands with metal-ion nodes can, in principle, give rise to innumerable structurally and chemically distinct nanoporous MOFs. However, many MOFs that are optimized for the separation of CO2 from nitrogen4-7 do not perform well when using realistic flue gas that contains water, because water competes with CO2 for the same adsorption sites and thereby causes the materials to lose their selectivity. Although flue gases can be dried, this renders the capture process prohibitively expensive8,9. Here we show that data mining of a computational screening library of over 300,000 MOFs can identify different classes of strong CO2-binding sites-which we term 'adsorbaphores'-that endow MOFs with CO2/N2 selectivity that persists in wet flue gases. We subsequently synthesized two water-stable MOFs containing the most hydrophobic adsorbaphore, and found that their carbon-capture performance is not affected by water and outperforms that of some commercial materials. Testing the performance of these MOFs in an industrial setting and consideration of the full capture process-including the targeted CO2 sink, such as geological storage or serving as a carbon source for the chemical industry-will be necessary to identify the optimal separation material.

---

## p156 — Identification of Metal-Organic Frameworks for CO2 Capture from Humid Flue Gas: Integrating Molecular Simulation, Machine Learning, and Experimental Synthesis
- DOI: 10.26434/chemrxiv.15004247/v1
- Source: sciverse

Increasing global CO2 emissions are driving efforts to develop advanced carbon capture materials. Metal-organic frameworks (MOFs) show great promise as CO2 adsorbents, yet maintaining performance under humid flue gas conditions remains a major challenge. Herein, we present an integrated computational high-throughput screening workflow that begins with a library of over 110,000 experimental MOF structures, explicitly includes the effects of water in adsorption simulations, and incorporates machine learning-based stability analysis to identify promising candidates from among existing MOFs. Guided by this workflow, we synthesized a top-performing MOF that demonstrates exceptional tolerance to humid conditions, maintaining high CO2 uptake at elevated relative humidity. We further revealed key structure-property relationships and structural motifs that offer valuable design principles for next-generation MOFs for CO2 capture in humid conditions.

---

## p157 — Carbon dioxide capture from humid flue gas using amino-functionalised ionic liquid hybrid metal-organic frameworks
- DOI: 10.2139/ssrn.5703670
- Source: sciverse

---

## p158 — Carbon Dioxide Capture Chemistry of Amino Acid Functionalized Metal–Organic Frameworks in Humid Flue Gas
- DOI: 10.1021/jacs.1c13368
- Source: sciverse

Metal-organic framework-808 has been functionalized with 11 amino acids (AA) to produce a series of MOF-808-AA structures. The adsorption of CO2 under flue gas conditions revealed that glycine- and dl-lysine-functionalized MOF-808 (MOF-808-Gly and -dl-Lys) have the highest uptake capacities. Enhanced CO2 capture performance in the presence of water was observed and studied by using single-component sorption isotherms, CO2/H2O binary isotherm, and dynamic breakthrough measurements. The key to the favorable performance was uncovered by deciphering the mechanism of CO2 capture in the pores and attributed to the formation of bicarbonate as evidenced by 13C and 15N solid-state nuclear magnetic resonance spectroscopy studies. On the basis of these results, we examined the performance of MOF-808-Gly in simulated coal flue gas conditions and found that it is possible to capture and release CO2 by vacuum swing adsorption. MOF-808-Gly was cycled at least 80 times with full retention of performance. This study significantly advances our understanding of CO2 chemistry in MOFs by revealing how strongly bound amine moieties to the MOF backbone create the chemistry and environment within the pores, leading to the binding and release of CO2 under mild conditions without application of heat.

---

## p159 — Functionalization of Metal–Organic Frameworks for Enhanced Stability under Humid Carbon Dioxide Capture Conditions
- DOI: 10.1002/cssc.201500580
- Source: sciverse

Metal-organic frameworks (MOFs) have been highlighted recently as promising materials for CO2 capture. However, in practical CO2 capture processes, such as capture from flue gas or ambient air, the adsorption properties of MOFs tend to be harmed by the presence of moisture possibly because of the hydrophilic nature of the coordinatively unsaturated sites (CUSs) within their framework. In this work, the CUSs of the MOF framework are functionalized with amine-containing molecules to prevent structural degradation in a humid environment. Specifically, the framework of the magnesium dioxybenzenedicarboxylate (Mg/DOBDC) MOF was functionalized with ethylenediamine (ED) molecules to make the overall structure less hydrophilic. Structural analysis after exposure to high-temperature steam showed that the ED-functionalized Mg/DOBDC (ED-Mg/DOBDC) is more stable under humid conditions, than Mg/DOBDC, which underwent drastic structural changes. ED-Mg/DOBDC recovered its CO2 adsorption capacity and initial adsorption rate quite well as opposed to the original Mg/DOBDC, which revealed a significant reduction in its capture capacity and kinetics. These results suggest that the amine-functionalization of the CUSs is an effective way to enhance the structural stability of MOFs as well as their capture of humid CO2 .

---

## p160 — CO2 capture from wet flue gas using a water-stable and cost-effective metal-organic framework
- DOI: 10.1016/j.xcrp.2023.101470
- Source: sciverse

We report the use of MIL-120 as a water-stable and cost-effective metal-organic framework (MOF) for selectively capturing CO2 from wet flue gas. Synthesized using inexpensive and environmentally benign reagents in water, MIL-120 possesses one-dimensional pores decorated with hydroxyl-bridged Al(III) ions and benzene rings with an interstitial spacing of 4.78 Å. Carbon dioxide isotherms show steep uptake at low pressure, and the affinity of MIL-120 for CO2 is 44 kJ mol−1. CO2-loading 13C solid-state nuclear magnetic resonance and Fourier transform infrared spectra tracking the sorption of CO2 into MIL-120 revealed that the interplay of pore size, functionality, and dimensionality is vital for CO2 restriction within the pores of MIL-120. Breakthrough experiments reveal that MIL-120 can capture CO2 from dry and wet flue gas with uptake capacities of 1.215 and 1.118 mmol g−1, respectively. Our work highlights the synthetic benefits of MIL-120 and elucidates its selective capture of CO2 from wet flue gas.

---

## p161 — Enhancing hydrophobicity via core–shell metal organic frameworks for high-humidity flue gas CO2 capture
- DOI: 10.1016/j.cjche.2023.03.002
- Source: sciverse

---

## p162 — CO2 capture from wet flue gas using transition metal inserted porphyrin-based metal-organic frameworks as efficient adsorbents
- DOI: 10.1016/j.seppur.2022.122058
- Source: sciverse

---

## p163 — Large-Scale Screening and Machine Learning for Metal–Organic Framework Membranes to Capture CO2 from Flue Gas
- DOI: 10.3390/membranes12070700
- Source: sciverse

To combat global warming, as an energy-saving technology, membrane separation can be applied to capture CO2 from flue gas. Metal-organic frameworks (MOFs) with characteristics like high porosity have great potential as membrane materials for gas mixture separation. In this work, through a combination of grand canonical Monte Carlo and molecular dynamics simulations, the permeability of three gases (CO2, N2, and O2) was calculated and estimated in 6013 computation-ready experimental MOF membranes (CoRE-MOFMs). Then, the relationship between structural descriptors and permeance performance, and the importance of available permeance area to permeance performance of gas molecules with smaller kinetic diameters were found by univariate analysis. Furthermore, comparing the prediction accuracy of seven classification machine learning algorithms, XGBoost was selected to analyze the order of importance of six structural descriptors to permeance performance, through which the conclusion of the univariate analysis was demonstrated one more time. Finally, seven promising CoRE-MOFMs were selected, and their structural characteristics were analyzed. This work provides explicit directions and powerful guidelines to experimenters to accelerate the research on membrane separation for the purification of flue gas.

---

## p164 — Immobilization of H <sub>2</sub> O in Diffusion Channel of Metal–Organic Frameworks for Long‐Term CO <sub>2</sub> Capture from Humid Flue Gas
- DOI: 10.1002/adma.202410500
- Source: sciverse

Utilizing physisorption for CO2 capture in humid flue gas presents challenges, with H2O molecules either damaging the adsorbent or competing with CO2 for adsorption, compromising long-term stability. Herein, a counter-intuitive strategy is proposed to address this issue by immobilizing H2O into metal-organic framework (TYUT-ATZ, TYUT = Taiyuan University of Technology, ATZ = 3-amino-1,2,4-triazole) as binding sites for CO2 capture from humid airflow. Through tailoring the -NH2 group numbers and pore sizes creates ingenious H2O sites, preserving CO2 adsorption space and enhancing CO2 adsorption interactions in 1D channels. The well-constructed TYUT-ATZ-β demonstrates a high CO2 adsorption capacity (62.7 cm3 cm-3) at 0.15bar and outstanding CO2/N2 (15/85) selectivity (2031) at 298 K, while also exhibits the highest CO2/H2O uptake ratio in humid flue gas due to its excellent water stability and unique H2O site. Consequently, it shows top-performing CO2 enrichment ability with easy regeneration in long-term separation experiments (over 100 cycles) under high-humidity (75% RH). Gas adsorption isotherms, single-crystal analysis, selectivity calculations, and contrastive breakthrough experiments comprehensively validate this artful H2O immobilization strategy in MOFs for efficient CO2 capture in humid flue gas, satisfying the application requirements of high selectivity, rapid regeneration, and long-term stability.

---

## p165 — Fluorido-bridged iron-based metal-organic frameworks for carbon dioxide capture in humid flue gas
- DOI: 10.1016/j.fuel.2024.131669
- Source: sciverse

---

## p166 — Metal−Organic Frameworks for Capturing Carbon Dioxide from Flue Gas
- DOI: 10.1021/bk-2021-1393.ch014
- Source: sciverse

The environment is facing a major issue from global warming. Carbon dioxide (CO2) is surging in the global climate system, and its surged concentration may lead to a serious condition in the future. Humans are a major threat to the environment as they explore and utilize natural resources without thinking about the consequences. Because CO2 is building up in the atmosphere, capturing and sequestering it is a main concern. In this chapter, the capture and sequestration are described, with mainly physical and chemical technologies, which are used for CO2 capture and storage. These technologies include amine-functioned adsorbent, open nitrogen site, hybrid membrane separation, zeolites, and phosphate and sulfonate functionalization. There are many techniques that can be utilized for capturing CO2 from flue gas including absorption, adsorption, filtrations, and membrane separation, but adsorption is found to be a more economical method because it is cost-effective and consumes less energy. In this chapter, the capture of CO2 from effluent gas utilizing MOFs is described. A summarized usage of stored CO2 and MOFs is also explained. Carbon capture and storage uses three methods including precombustion capture of CO2, the oxy-fuel process, and post-combustion confinement. Advantages and disadvantages are described in this chapter. Post-combustion capture is the most efficient process because it allows process functioning and can be effortlessly attached to functioning system units. Sources of CO2 are summarized with pie charts, and data about composition of fuel properties, ignition air, wet-released gas, and dry exhaust effluent gas are described in tabular form.

---
