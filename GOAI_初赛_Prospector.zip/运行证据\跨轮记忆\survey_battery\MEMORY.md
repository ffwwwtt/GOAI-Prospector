# Agent Experiment Memory — survey

## 调研：[锂离子电池高镍正极容量保持率]
- [调研记忆 0802](survey-0802-高镍正极容量保持率.md) — 174 篇文献；9 组构效关系；Top Gap：单晶/多晶矛盾、Co 阈值、掺杂描述符构效关系；5 条假设全部 literature_supported

