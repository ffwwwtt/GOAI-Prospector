# 独立执行 validate_discovery（绕过 survey_state 缓存）
import json, os, sys
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0, os.getcwd())
sys.path.insert(0, "D:/@GOAI")
from literature_agent.discovery import MaterialsProjectValidator, DiscoveryHypothesis

OUT = Path("workspace/outputs/literature_survey/discovery")
with open(OUT / "hypotheses.json", encoding="utf-8") as f:
    hypotheses_data = json.load(f)

validator = MaterialsProjectValidator()
for idx, hdata in enumerate(hypotheses_data):
    hyp = DiscoveryHypothesis(**{k: v for k, v in hdata.items()
                                 if k in DiscoveryHypothesis.__dataclass_fields__})
    try:
        result = validator.validate(hyp)
    except Exception as e:
        print(f"hyp[{idx}] 验证异常: {e}")
        continue
    vs = result.get("validation_source", "none")
    if result.get("overall_match"):
        hyp.validation_status = "validated" if vs == "database" else "literature_supported"
    elif result.get("databases_checked") or result.get("validation_notes"):
        hyp.validation_status = "inconclusive"
    else:
        hyp.validation_status = "pending"
    hyp.external_validation = result
    hypotheses_data[idx] = asdict(hyp)
    ev = result.get("supporting_evidence", [])
    print(f"hyp[{idx}] {hyp.title[:38]} | status={hyp.validation_status} | "
          f"db={result.get('databases_checked')} | evidence={len(ev)} | "
          f"notes={('; '.join(result.get('validation_notes', [])[:1]))[:60]}")

with open(OUT / "hypotheses.json", "w", encoding="utf-8") as f:
    json.dump(hypotheses_data, f, ensure_ascii=False, indent=2)
print("验证完成，已更新 hypotheses.json")
