# -*- coding: utf-8 -*-
"""将 search_results.json 转为 {paper_id: Title+Abstract} 格式，供 extract_knowledge 使用"""
import json, hashlib

with open('workspace/data/literature_cache/search_results.json', encoding='utf-8') as f:
    results = json.load(f)

papers = {}
seen = set()
for i, r in enumerate(results):
    title = r.get('title', '').strip()
    abstract = r.get('abstract', '').strip()
    if not title:
        continue
    # 按标题去重（归一化）
    key = title.lower().replace(' ', '').replace('\n', '')
    if key in seen:
        continue
    seen.add(key)
    pid = f"p{len(papers)+1}"
    text = f"Title: {title}\n"
    if r.get('authors'):
        text += f"Authors: {', '.join(r['authors'])}\n"
    if r.get('doi'):
        text += f"DOI: {r['doi']}\n"
    if r.get('source'):
        text += f"Source: {r['source']}\n"
    if r.get('year'):
        text += f"Year: {r['year']}\n"
    if abstract:
        text += f"Abstract: {abstract}\n"
    papers[pid] = text

with open('workspace/data/literature_cache/papers.json', 'w', encoding='utf-8') as f:
    json.dump(papers, f, ensure_ascii=False, indent=1)

print(f"转换完成：{len(papers)} 篇唯一论文")
# 打印前 5 个 id 便于核对
for pid in list(papers)[:5]:
    print(pid, papers[pid].split('\n')[0])
