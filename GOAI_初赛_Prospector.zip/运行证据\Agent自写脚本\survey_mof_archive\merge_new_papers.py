# 增量合并：保留现有 papers.json 的 ID，只添加新论文（p121 起）
import json, os

cache_dir = "workspace/data/literature_cache"
papers_path = os.path.join(cache_dir, "papers.json")
text_path = os.path.join(cache_dir, "papers_text.json")
results_path = os.path.join(cache_dir, "search_results.json")

with open(papers_path, encoding="utf-8") as f:
    papers = json.load(f)
with open(results_path, encoding="utf-8") as f:
    results = json.load(f)

if isinstance(results, dict):
    items = []
    for k, v in results.items():
        if isinstance(v, list):
            items.extend(v)
        elif isinstance(v, dict) and "papers" in v:
            items.extend(v["papers"])
    results = items

existing_titles = {p["title"].lower().strip() for p in papers.values() if p.get("title")}
added = 0
for p in results:
    if not isinstance(p, dict):
        continue
    title = (p.get("title") or "").strip()
    if not title:
        continue
    tkey = title.lower()
    if tkey in existing_titles:
        continue
    # 新论文
    nid = f"p{len(papers) + 1}"
    papers[nid] = {
        "title": title,
        "abstract": p.get("abstract", ""),
        "doi": p.get("doi", ""),
        "source": p.get("source", ""),
    }
    existing_titles.add(tkey)
    added += 1

# 重建 papers_text.json
papers_text = {}
for pid, info in papers.items():
    txt = f"Title: {info['title']}\n"
    if info.get("doi"):
        txt += f"DOI: {info['doi']}\n"
    if info.get("abstract"):
        txt += f"Abstract: {info['abstract']}"
    papers_text[pid] = txt

with open(papers_path, "w", encoding="utf-8") as f:
    json.dump(papers, f, ensure_ascii=False, indent=2)
with open(text_path, "w", encoding="utf-8") as f:
    json.dump(papers_text, f, ensure_ascii=False, indent=2)

print(f"原有论文: {len(papers) - added}，新增: {added}，总论文数: {len(papers)}")
# 打印新增论文的标题
if added:
    for pid in list(papers.keys())[-added:]:
        print(f"  {pid}: {papers[pid]['title'][:80]}")
