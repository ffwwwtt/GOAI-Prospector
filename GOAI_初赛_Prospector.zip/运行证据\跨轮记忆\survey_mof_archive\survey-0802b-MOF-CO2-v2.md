## 调研：MOF 材料用于 CO2 捕获（第二轮迭代 v2.0）
- 日期：2026-08-02（第二轮，基于 v1.0 的 120 篇扩展至 180 篇）
- 状态：阶段一 + 阶段二全部完成

### 检索策略（本轮新增 6 轮，总 24 轮）
- 新检索词：MOF-74 defect engineering、direct air capture DAC amine MOF、MOF CO2 working capacity TSA/PSA regeneration、MOF CO2 humid flue gas water stability breakthrough、amine appended M2(dobpdc) cooperative insertion、MOF CO2 review techno-economic scale-up
- 唯一论文：120 → 180（新增 p121–p180）
- 捕获效率：86%

### 知识图谱摘要（v2.0）
- 材料数：40 | 性质记录：87 | 跨体系关系：14（R1–R14，新增 R9 缺陷二象性、R10 水效应二象性、R11 胺-阶梯压力、R12 水固定、R13 循环-等温线形状、R14 ML 特征）
- 新板块：二胺接枝 M2(dobpdc)、湿烟气稳定 MOF、DAC 前沿材料
- 审计：5 冲突（3 个为审计误读已澄清，2 个真实矛盾：MOF-74 容量 3.0 vs 6.61、Qst 23 vs 52）

### Top 研究空白（10 个，新增 4 个）
1. **Gap 7【新·矛盾】缺陷类型二象性**（高/0.85）：p121 甲酸缺陷抑制 vs p122 配体缺失缺陷提升——缺陷角色决定方向
2. **Gap 8【新·矛盾】水效应二象性**（高/0.85）：物理吸附水竞争（p30）vs 化学吸附水促进（p135/p136/p158/p164/p168）
3. **Gap 9【新·未探索】循环级性能**（高/0.75）：TSA/VSA 工作容量、再生能耗、氧化稳定性被系统性忽视（p137/p145/p154/p176）
4. Gap 1（合成-容量映射，强化）、Gap 2（双金属）、Gap 4（OMS-湿度）延续
5. **Gap 10【新·缺失】胺结构-阶梯压力-工作容量定量映射**（中/0.8，p167/p170/p173）

### 发现结果（路线 A，8 个假设，全部 literature_supported）
| # | 假设 | 置信度 | 关键证据 |
|---|---|---|---|
| 5 | **缺陷类型决定容量效应方向** | 0.98 | p121, p122（本轮最高价值） |
| 1 | 双金属非对称协同 | 0.97 | p29, p7, p17 |
| 2 | 胺最优负载量预测 | 0.99 | p38, p40, p41, p135, p136 |
| 6 | **水效应二象性临界线** | 0.85 | p30, p135, p136, p158, p164, p168 |
| 7 | **等温线形状-循环性能** | 0.75 | p137, p145, p154（证据最少，待强化） |
| 0/3/4 | 合成火山形/OMS-湿度/孔径-压力 | 0.82–0.97 | 延续 v1.0 |

### 反思
- 最令人惊讶的发现：**缺陷类型二象性**——两篇独立论文（Nat Commun 2023 vs CEJ 2023）对"缺陷提升还是抑制 MOF-74 吸附"给出相反结论，本质是缺陷化学角色（占位 OMS vs 造孔）不同。评分最高的假设（0.984）恰好来自这个矛盾。
- 最高效搜索方向：缺陷工程 + DAC 补充检索（6 轮新增 60 篇，含 Nature 2015/2019、JACS 2017、Adv Mater 等关键证据）。
- 工具经验：generate_hypotheses 会覆盖 hypotheses.json 且受 survey_state 缓存限制；绕过方案 = 脚本复制工具逻辑直接调 DiscoveryEngine（见 workspace/code/survey/run_discovery_all.py、run_validate_lit.py）。
- 下一轮聚焦：① 强化 hyp[7] 循环性能证据（补充 TSA/VSA 过程文献）；② CRAFTED 数据库定量验证孔径-压力窗口；③ 缺陷类型标注化的实验数据库构建。
