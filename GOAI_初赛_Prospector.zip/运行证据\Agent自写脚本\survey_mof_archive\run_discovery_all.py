# 独立执行 discovery search（绕过 survey_state 缓存限制）
# 复制 pi_agent/tools.py 中 h_run_discovery_search 的核心逻辑
import json, re, os, sys
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0, os.getcwd())
sys.path.insert(0, "D:/@GOAI")
from literature_agent.discovery import DiscoveryEngine, DiscoveryHypothesis

OUT = Path("workspace/outputs/literature_survey/discovery")
OUT.mkdir(parents=True, exist_ok=True)

# ── 1. 加载假设 ──
with open(OUT / "hypotheses.json", encoding="utf-8") as f:
    hypotheses_data = json.load(f)
print(f"加载 {len(hypotheses_data)} 个假设")

# ── 2. 证据源（与工具一致：知识图谱 + 全文缓存） ──
kg_md = Path("workspace/outputs/literature_survey/knowledge_graph.md")
parts = [kg_md.read_text(encoding="utf-8", errors="replace")] if kg_md.exists() else []
papers_dir = Path("workspace/data/papers")
if papers_dir.exists():
    total = sum(len(p) for p in parts)
    for md in sorted(papers_dir.glob("*.md")):
        txt = md.read_text(encoding="utf-8", errors="replace")
        if total + len(txt) > 300_000:
            parts.append(f"\n\n<!-- 全文缓存过多，已截断：{md.name} -->\n")
            break
        parts.append(txt)
        total += len(txt)
source_text = "\n\n".join(parts)
print(f"证据源: {len(source_text)} 字符")

# ── 3. 工具私有方法复制 ──
_PROPERTY_KEYWORD_MAP = {
    "选择性": ["selectivity", "separation factor"],
    "容量": ["capacity", "uptake", "loading"],
    "吸附": ["adsorption", "uptake", "capture"],
    "焓": ["isosteric heat", "qst", "enthalpy"],
    "再生": ["regeneration", "working capacity", "energy"],
    "稳定性": ["stability", "degradation", "cyclability"],
    "扩散": ["diffusion", "kinetics"],
    "催化": ["catalysis", "tof", "conversion", "activity"],
    "效率": ["efficiency"],
    "能耗": ["energy penalty", "regeneration energy"],
    "循环": ["cyclability", "cycle"],
}
_VALUE_UNIT_RE = re.compile(
    r'(\d+(?:\.\d+)?)\s*(mmol/g|mol/kg|mmol/cm3|mg/g|kJ/mol|wt%|m2/g|bar|K|%|h|min|eV)',
    re.IGNORECASE,
)
_PROPERTY_UNIT_BUCKETS = (
    (("mmol/g", "mol/kg", "mmol/cm3", "mg/g", "wt%"),
     ("容量", "capacity", "uptake", "loading", "吸附", "capture", "adsorption")),
    (("kj/mol",), ("焓", "qst", "enthalpy", "等量吸附热", "吸附热")),
    (("m2/g",), ("bet", "surface area", "比表面积", "表面积")),
    (("bar",), ("压力", "pressure")),
    (("k",), ("温度", "temperature")),
    (("%", "wt%"), ("效率", "efficiency")),
)

def _property_keywords(property_name):
    kws = set()
    text = (property_name or "").lower()
    for zh, en_list in _PROPERTY_KEYWORD_MAP.items():
        if zh in text:
            kws.update(en_list)
    for tok in re.findall(r'[a-z][a-z0-9\-]{1,20}', text):
        if len(tok) >= 2:
            kws.add(tok)
    return sorted(kws) or ["adsorption", "capacity", "selectivity"]

def _unit_filter(property_name):
    text = (property_name or "").lower()
    matched = set()
    for units, kws in _PROPERTY_UNIT_BUCKETS:
        if any(k in text for k in kws):
            matched.update(units)
    return matched or None

def _build_evidence_index(source_text, hyp):
    blocks = [b.strip() for b in re.split(r'\n(?=#{1,3} )', source_text) if len(b.strip()) > 60]
    if not blocks:
        blocks = [source_text]
    material_tokens = set()
    for m in (hyp.materials or []):
        for part in re.split(r'[/\s,，、]+', m):
            part = part.strip()
            if len(part) >= 3 and not part.isdigit():
                material_tokens.add(part.lower())
    material_tokens.update(
        m.lower() for m in re.findall(
            r'\b(?:[A-Z][a-z]?\d+[A-Za-z0-9]*(?:-[A-Za-z0-9]+)*|ZIF-\d+|UiO-\d+|MIL-\d+|HKUST-\d+|IRMOF-\d+|MOF-\d+)\b',
            source_text,
        )
    )
    prop_kws = _property_keywords(hyp.property)
    unit_filter = _unit_filter(hyp.property)
    values = []
    for block in blocks:
        lower = block.lower()
        for kw in prop_kws:
            for m in re.finditer(re.escape(kw), lower):
                window = lower[max(0, m.start() - 120): m.end() + 160]
                for vm in _VALUE_UNIT_RE.finditer(window):
                    unit = (vm.group(2) or "").lower()
                    if unit_filter is not None and unit not in unit_filter:
                        continue
                    v = float(vm.group(1))
                    if 0 < v < 1e6:
                        values.append(v)
    values = sorted(set(round(v, 4) for v in values))[:500]
    return {
        "blocks": blocks, "material_tokens": sorted(material_tokens),
        "prop_keywords": prop_kws, "values": values,
    }

def _search_space(evid):
    values = sorted(evid.get("values") or [])
    if values:
        n = len(values)
        q1 = values[max(0, n // 4)]
        q3 = values[min(n - 1, 3 * n // 4)]
        median = values[n // 2]
        iqr = max(q3 - q1, 1e-9)
        lo = max(0.001, q1 - 1.5 * iqr)
        hi = q3 + 1.5 * iqr
        lo = min(lo, median * 0.5)
        hi = max(hi, median * 2.0)
    else:
        lo, hi = 0.1, 100.0
    return {
        "property_value": (float(lo), float(hi)),
        "composition_x": (0.0, 1.0),
        "temperature": (300.0, 1500.0),
    }

def _evidence_score(params, hyp, evid):
    blocks = evid["blocks"]
    total = len(blocks)
    if total == 0:
        return 0.3
    cand_mats = params.get("materials") or params.get("material") or (hyp.materials or [])
    if isinstance(cand_mats, str):
        cand_mats = [cand_mats]
    cand_mats = [str(m).lower() for m in cand_mats]
    mats = evid["material_tokens"]
    kws = evid["prop_keywords"]
    values = evid["values"]
    if cand_mats:
        mat_blocks = [b for b in blocks if any(m in b.lower() for m in cand_mats)]
        if not mat_blocks:
            mat_blocks = [b for b in blocks if any(t in b.lower() for t in mats)]
    else:
        mat_blocks = [b for b in blocks if any(t in b.lower() for t in mats)]
    score = 0.3
    if mat_blocks:
        score += 0.20 * len(mat_blocks) / total
        co = sum(1 for b in mat_blocks if any(k in b.lower() for k in kws))
        score += 0.20 * co / max(len(mat_blocks), 1)
        cv = params.get("property_value") or params.get("value") or 0
        if values and cv:
            sims = sorted(1.0 / (1.0 + abs(cv - v) / max(v, 1e-6)) for v in values)
            best = sum(sims[-3:]) / max(len(sims[-3:]), 1)
            score += 0.30 * best
    return min(score, 1.0)

# ── 4. 对每个假设执行搜索 ──
engine = DiscoveryEngine()
n_iter = int(sys.argv[1]) if len(sys.argv) > 1 else 30
method = sys.argv[2] if len(sys.argv) > 2 else "bayesian"
only_idx = int(sys.argv[3]) if len(sys.argv) > 3 else None

for idx, hdata in enumerate(hypotheses_data):
    if only_idx is not None and idx != only_idx:
        continue
    hyp = DiscoveryHypothesis(**{k: v for k, v in hdata.items()
                                 if k in DiscoveryHypothesis.__dataclass_fields__})
    evid = _build_evidence_index(source_text, hyp)
    param_space = _search_space(evid)
    best_params, best_score, log = engine.bayes_opt.optimize(
        hyp, param_space,
        objective_fn=lambda p, h=hyp, e=evid: _evidence_score(p, h, e),
        n_iterations=n_iter,
    )
    search_results = {
        "hypothesis_index": idx, "search_method": method, "iterations": n_iter,
        "evidence": {
            "source": "knowledge_graph.md + paper_summaries.md + papers/*.md",
            "blocks": len(evid["blocks"]),
            "material_tokens": len(evid["material_tokens"]),
            "property_keywords": evid["prop_keywords"][:10],
            "literature_values": evid["values"][:20],
        },
        "best_params": best_params, "best_score": best_score,
        "iteration_log": log[-10:],
    }
    (OUT / f"search_h{idx}.json").write_text(
        json.dumps(search_results, ensure_ascii=False, indent=2), encoding="utf-8")
    # 更新假设
    hyp.confidence = max(hyp.confidence, best_score)
    hyp.candidates_explored = len(log) + 10
    hyp.search_iterations = n_iter
    hyp.search_method = method
    hypotheses_data[idx] = asdict(hyp)
    print(f"hyp[{idx}] {hyp.title[:40]} | score={best_score:.3f} | "
          f"conf={hyp.confidence:.2f} | mats={len(evid['material_tokens'])} | "
          f"vals={len(evid['values'])} | blocks={len(evid['blocks'])}")

with open(OUT / "hypotheses.json", "w", encoding="utf-8") as f:
    json.dump(hypotheses_data, f, ensure_ascii=False, indent=2)
print("全部完成，已更新 hypotheses.json")
