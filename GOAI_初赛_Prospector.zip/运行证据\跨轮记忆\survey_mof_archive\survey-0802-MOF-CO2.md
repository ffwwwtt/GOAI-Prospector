## 调研：MOF 材料用于 CO2 捕获
- 日期：2026-08-02
- 状态：首次完整调研（阶段一 + 阶段二均完成）

### 检索策略
- 检索词（6 轮）："MOF materials CO2 capture adsorption"、"MOF-74 CO2 adsorption capacity isosteric heat open metal sites"、"amine-functionalized metal-organic framework CO2 capture selectivity"、"ZIF-8 UiO-66 CO2/N2 selectivity water stability"、"SIFSIX metal-organic framework CO2 capture"、"machine learning high-throughput screening MOF CO2 adsorption"、"MOF CO2 capture humidity water vapor flue gas working capacity"
- 数据源：arXiv + Sciverse（sciverse 为主）
- 唯一论文：120 篇（p1–p120），捕获效率 93%

### 知识图谱摘要（workspace/outputs/literature_survey/knowledge_graph.md）
- 材料数：32（6 大体系：MOF-74、ZIF、UiO-66、SIFSIX/阴离子超微孔、胺功能化、其他）
- 性质记录：66（容量、选择性、Qst、水稳定性、循环稳定性）
- 关键关系数：8（R1–R8）
- 审计：7 个数值冲突（2 个真实科学冲突：MOF-74 容量 3.0 vs 8.3 mmol/g；Qst 23–52 kJ/mol）

### Top 研究空白（gap_report.md）
1. MOF-74(Ni) 合成条件-微观结构-容量映射缺失 — 高 — 0.85（p17）
2. 双金属 Ni/Co-MOF-74 比例-容量非对称协同机制 — 高 — 0.8（p29）
3. OMS 密度-湿度耐受性权衡曲线未量化 — 高 — 0.8（p30, p49, p115, p104）
4. 胺功能化最优负载量预测框架缺失 — 中 — 0.75（p38, p40, p41）
5. 孔径-压力-容量统一描述缺失 — 中 — 0.7（p78, p82, p17）
6. 稳定性指标与 CO2 性能联合筛选稀缺 — 中 — 0.7（p96）

### 发现结果（路线 A，discovery/discovery_report.md，全部 5 个假设已完成贝叶斯搜索）
1. Ni/Co-MOF-74 双金属比例-容量非对称协同 — 置信度 0.97，外部验证 inconclusive（框架材料不入无机库）→ 文献证据链 p29/p7/p17
2. 孔径-压力窗口统一描述（d* 与 log10P 负相关）— 置信度 0.82，证据链 p78/p82/p17/p10
3. OMS 密度-湿度权衡曲线 — 置信度 0.83，文献证据链 p30/p49/p115/p104
4. MOF-74(Ni) 合成条件火山形关系 — 置信度 0.97，证据链 p17/p7/p1
5. 胺负载量 = f(孔径, 孔容, 胺分子体积) — 置信度 0.99（21 条文献值，证据最丰富），证据链 p38/p40/p41/p1

### 反思
- 最令人惊讶的发现：Ni6Co1-MOF-74（3.62 mmol/g）容量反而低于纯 Ni-MOF-74（3.99），双金属协同是非对称的，1:1 为最优——这挑战了"双金属总优于单金属"的朴素预期。
- 最高效搜索方向：MOF-74 体系（OMS + 双金属）证据最丰富，支撑了最高置信度的构效关系假设。
- 下一轮迭代聚焦：①对假设 2/4/5 执行 run_discovery_search；②利用 CRAFTED 数据库（p10）定量验证"孔径-压力窗口"；③补充检索"MOF-74 defect engineering"与"DAC MOF amine"以强化假设 3/5 证据链。
