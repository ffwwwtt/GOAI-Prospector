# 生成发现报告（复制 h_generate_discovery_report 逻辑）
import json, os, sys
from pathlib import Path
sys.path.insert(0, os.getcwd())
sys.path.insert(0, "D:/@GOAI")
from literature_agent.discovery import DiscoveryReport, DiscoveryHypothesis

OUT = Path("workspace/outputs/literature_survey/discovery")
with open(OUT / "hypotheses.json", encoding="utf-8") as f:
    hypotheses_data = json.load(f)

hypotheses = [DiscoveryHypothesis(**{k: v for k, v in h.items()
                                     if k in DiscoveryHypothesis.__dataclass_fields__})
              for h in hypotheses_data]

report = DiscoveryReport(
    title="Structure-Property Relationship Discovery",
    hypotheses=hypotheses,
    total_candidates=len(hypotheses),
    total_explored=sum(h.candidates_explored for h in hypotheses),
    validated_count=sum(1 for h in hypotheses if h.validation_status == "validated"),
    refuted_count=sum(1 for h in hypotheses if h.validation_status == "refuted"),
    materials_project_hits=sum(1 for h in hypotheses
                              if h.external_validation.get("overall_match")),
    search_summary=(
        f"Explored {len(hypotheses)} hypotheses via Bayesian optimization (30 iterations each) "
        f"and literature evidence-chain validation (>=2 independent papers)."
    ),
)

md_path, json_path = report.save(str(OUT))
print("报告已生成：")
print("  ", md_path)
print("  ", json_path)
print(f"假设数: {len(hypotheses)}, 已验证: {report.validated_count}, 已推翻: {report.refuted_count}")
for h in hypotheses:
    print(f"  [{h.validation_status}] conf={h.confidence:.2f} {h.title[:50]}")
