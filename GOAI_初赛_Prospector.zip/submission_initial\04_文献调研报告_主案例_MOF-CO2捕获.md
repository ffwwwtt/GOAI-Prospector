# 文献调研报告：MOF 材料用于 CO2 捕获（v2.0）

**调研日期**：2026-08-02（第二轮迭代，基于 v1.0 扩展）
**论文库**：180 篇唯一论文（p1–p180；arXiv 11 + Sciverse 169）
**检索轮次**：24 轮 | **捕获效率**：86%
**知识图谱**：40 材料、87 性质记录、14 条跨体系构效关系（R1–R14）

---

## 1. 执行摘要

本报告系统梳理了金属有机框架（MOF）材料在 CO2 捕获领域的文献，覆盖 **180 篇论文**（2016–2025），构建了包含 **40 种材料、87 条性质记录、14 条构效关系**的知识图谱。

**六大材料体系**：MOF-74 系列（含双金属与缺陷工程）、二胺接枝 M2(dobpdc)、胺功能化/浸渍体系、ZIF 系列、UiO-66 系列、SIFSIX/阴离子超微孔体系，以及新兴的湿烟气稳定 MOF（CALF-20、MIL-120、TYUT-ATZ-β 等）。

**三大核心发现**：
1. **缺陷类型二象性**（新发现）：缺陷对 CO2 容量的影响方向取决于缺陷的化学角色——甲酸盐缺陷（占位 OMS）抑制吸附（p121，Nat Commun 2023），配体缺失缺陷（造孔）提升容量 +50%（p122，CEJ 2023）。
2. **水效应二象性**（新发现）：物理吸附 MOF 中水竞争 OMS（负效应），胺化化学吸附 MOF 中水促进碳酸氢盐路径/作为结合位点（正效应，p135/p136/p158/p164/p168）。
3. **循环级性能维度**（新维度）：阶梯等温线（相变）MOF 在 TSA/VSA 中工作容量与能耗显著优于 Langmuir 型（p137/p145/p154），但该维度在文献中被系统性忽视。

**10 个研究空白**中，3 个为高优先级矛盾型 Gap（缺陷方向性、水效应方向性、合成-容量映射缺失）。阶段二对 8 个构效关系假设完成贝叶斯搜索（30 迭代×8）与文献证据链验证，**全部 8 个假设获 literature_supported**（≥2 篇独立论文），置信度 0.75–0.99。

---

## 2. 文献综述（按材料体系组织）

### 2.1 MOF-74 系列（M-DOBDC，开放金属位点 OMS）

MOF-74 是研究最深入的 CO2 吸附体系之一，其高密度 OMS 提供强 CO2 结合位点（Qst 27–52 kJ/mol，p17）。

- **合成条件敏感性**：p17 报道冷凝回流法（140°C/24h）合成 MOF-74(Ni) 达 8.29 mmol/g（273K），为常规溶剂热法的 2 倍——合成路线对性能影响巨大（Gap 1）。
- **双金属协同**：p29 微波法合成 Ni1Co1-MOF-74 达 8.30 mmol/g（0°C），但比例-容量呈**非对称非单调**关系（Ni6Co1 < 纯 Ni < Co < Ni1Co6 < Ni1Co1），挑战"双金属总优于单金属"的朴素预期（Gap 2）。
- **缺陷工程**（本轮新增）：p121（Nat Commun）揭示 DMF 分解产生的甲酸盐缺陷**屏蔽 OMS**、吸附随缺陷浓度定量下降；p122（CEJ）显示 Cl⁻ 竞争产生的配体缺失缺陷**制造介孔**（占比 36.9%）、Qst 36→46 kJ/mol、饱和容量 +50%——**缺陷类型决定效应方向**（Gap 7，新）。

### 2.2 二胺接枝 M2(dobpdc) 体系（相变吸附剂）

- p167（Nature 2015）确立**协同插入机制**：CO2 插入金属-胺键形成氨基甲酸铵链，产生阶梯形等温线（相变吸附）。
- p170（JACS 2017）证明 9 种二胺变体中，小结构修饰可将阶梯压力移动 **>4 个数量级**——胺结构-工作压力窗口强构效关系（Gap 10，新）。
- p173（ACS AMI）计算 11 种金属的 dmen-M2(dobpdc) CO2 结合能 53–89 kJ/mol（Sc 89 > Mg 84），金属依赖强。
- p131（Chem Sci）mmen-Mg2(dobpdc) 在 50% RH 内稳定，120°C 真空再生最优；p176 揭示 O2 氧化降解机制（胺结构决定降解速率）。
- **水增强**：p168（CEJ 2023）发现最优 RH 增强 CO2 摄取——与"水竞争"传统认知相反。

### 2.3 胺功能化/浸渍体系

- 经典工作：PEI/MIL-101（100 wt%）0.15 bar 达 4.2 mmol/g、选择性 770（p38）；MOF-177+TEPA（20%）提升 4.8×（p40）。
- **DAC 前沿**（本轮新增）：HP-PMOF-DETA 在 400 ppm 达 1.40 mmol/g、10 循环保持 84%（p135）；PEI@MIL-100(Cr) 1.21 mmol/g、20 循环 >90%（p136）；MIL-100(Fe)-AEEA 接枝在 -25°C 达 1.91 mmol/g（p130）；3D 打印单体化 PEI/MIL-101 在 -20°C/70%RH 达 1.43 mmol/g（p132）。
- 湿态增强机制：水促进氨基甲酸铵→碳酸氢盐（p135, p158，JACS 2021 用 13C/15N NMR 证实）。

### 2.4 ZIF 与 UiO-66

- ZIF-94 无 OMS，99.2% RH 下仍可分离（p115）；ZIF-NO3/-CHO 在水/SO2 下选择性反而增强（p108）。
- UiO-66 官能化 MMM 选择性排序 -(OH)2 > -NH2 > -Br（p64）；缺陷+离子液体双策略提升（p57）。

### 2.5 SIFSIX/阴离子超微孔体系

- ZU-16-Co（3.62 Å）在 0.01 bar 达 2.63 mmol/g（p78）；SIFSIX-2-Cu-i 低压高容量（p82）——F⋯C=O 强相互作用实现 ppm 级捕获（R5）。

### 2.6 湿烟气稳定 MOF（本轮重点扩展）

- **数据驱动设计**：p155（Nature 2019）从 30 万 MOF 数据挖掘出"吸附团"（adsorbaphore），合成 2 种疏水吸附团 MOF，湿烟气性能不受水影响；p156 集成模拟+ML+实验筛选 11 万实验 MOF。
- **水固定策略**：p164（Adv Mater）TYUT-ATZ-β 将 H2O 固定为 CO2 结合位点，CO2/N2 选择性 **2031**、75% RH 100 循环稳定。
- 实用材料：MIL-120 水合成、湿/干容量 1.118/1.215 mmol/g（p160）；CALF-20 工业验证（p9, p85）；F4_MIL-140A(Ce) 相变 MOF PVSA 性能最优（p154）。

### 2.7 机器学习与高通量筛选

- XGBoost 预测 19 种 MOF 的 CO2 容量（1191 数据点，RMSE 0.568；压力+比表面积主导，温度唯一负影响）（p144）；LSSVM（506 点，压力+孔容主导）（p148）。
- ALIGNN 图神经网络预筛 hMOF（p5）；MLFF 机器学习力场实现 DFT 精度柔性 MOF 模拟（p125）。

---

## 3. 关键材料与性质对比

### 3.1 CO2 吸附容量（按捕获场景分类）

| 场景 | 材料 | 容量 | 条件 | 来源 |
|---|---|---|---|---|
| DAC（400 ppm） | HP-PMOF-DETA | 1.40 mmol/g | 400 ppm | p135 |
| DAC（400 ppm） | PEI@MIL-100(Cr) | 1.21 mmol/g | 400 ppm | p136 |
| DAC（400 ppm） | MFC-AEEA | 2.42 mmol/g | 0°C, 400 ppm | p130 |
| 烟气（0.15 bar） | Ni1Co1-MOF-74 | 8.30 mmol/g | 0°C, 1 bar | p29 |
| 烟气（0.15 bar） | PEI/MIL-101 | 4.2 mmol/g | 25°C, 0.15 bar | p38 |
| 烟气（0.15 bar） | TYUT-ATZ-β | 62.7 cm³/cm³ | 0.15 bar | p164 |
| 低压痕量（0.01 bar） | ZU-16-Co (TIFSIX-3-Co) | 2.63 mmol/g | 0.01 bar | p78 |
| 高压（20 bar） | agw 型 Cu MOF | 21.2 mmol/g | 298 K, 20 bar | p151 |
| 高压（15 bar） | MOF-303 | 12.35 mol/kg | 298 K, 15 bar | p138 |
| 湿烟气 | MIL-120 | 1.118 mmol/g | 湿烟气 | p160 |

### 3.2 关键构效关系汇总（R1–R14 精选）

| 关系 | 描述 | 证据 |
|---|---|---|
| R1 | 双金属比例-容量非单调（1:1 最优 8.30 mmol/g） | p29 |
| R9 | 缺陷类型二象性：占位型抑制 vs 造孔型提升 | p121, p122 |
| R10 | 水效应二象性：物理吸附负、化学吸附正 | p30 vs p135/p158/p164 |
| R11 | 胺结构-阶梯压力：>4 数量级可调 | p167, p170 |
| R13 | 阶梯等温线→循环级性能优势 | p137, p154 |
| R14 | ML 特征重要性：压力+比表面积/孔容主导 | p144, p148 |

---

## 4. 研究空白与未来方向（10 个 Gap 摘要）

| Gap | 类型 | 严重度 | 核心问题 |
|---|---|---|---|
| G1 | 矛盾 | 高 | MOF-74(Ni) 容量跨文献差 2.8 倍，合成-缺陷-容量映射缺失 |
| G2 | 矛盾 | 高 | 双金属非对称非单调协同机制未解释 |
| G7 | **矛盾（新）** | 高 | 缺陷效应方向依赖类型（占位 vs 造孔），无统一框架 |
| G8 | **矛盾（新）** | 高 | 水效应方向依赖吸附机制（物理 vs 化学），缺统一相图 |
| G9 | **未探索（新）** | 高 | 循环级性能（TSA/VSA 工作容量、再生能耗）与描述符关系缺失 |
| G4 | 缺失 | 高 | OMS 密度-湿度耐受权衡曲线未量化 |
| G3 | 缺失 | 中 | 胺最优负载量-孔道结构定量关系缺失 |
| G5 | 未探索 | 中 | 孔径-压力-容量三维统一描述缺失 |
| G6 | 未探索 | 中 | 稳定性指标与 CO2 性能联合筛选稀缺 |
| G10 | 缺失（新） | 中 | 胺结构-阶梯压力-工作容量定量映射 |

**建议未来方向**：① 缺陷类型标注化的合成-容量数据库（区分甲酸/配体缺失缺陷）；② 水效应符号翻转临界线的元分析（以 Qst/胺负载为轴）；③ 循环级性能（Δ载量、再生能耗）纳入高通量筛选标准；④ 将阶梯等温线 MOF 与 PSA 过程耦合建模。

---

## 5. 参考文献（核心证据链，含 DOI）

| ID | 论文 | DOI/来源 |
|---|---|---|
| p17 | MOF-74(Ni) 冷凝回流合成高容量 | 见 evidence/mof/papers.json |
| p29 | NiCo-MOF-74 双金属微波合成 | 10.1016/j.efmat.2023.01.002 |
| p121 | Solvent-derived defects suppress adsorption in MOF-74 | 10.1038/s41467-023-38155-8 |
| p122 | Defect-rich hierarchical porous Mg-MOF-74 | 10.1016/j.cej.2023.144052 |
| p155 | Data-driven design of MOFs for wet flue gas CO2 capture | 10.1038/s41586-019-1798-7 |
| p164 | Immobilization of H2O in MOFs (TYUT-ATZ) | 10.1002/adma.202410500 |
| p167 | Cooperative insertion of CO2 in diamine-appended MOFs | 10.1038/nature14327 |
| p170 | Controlling Cooperative CO2 Adsorption in Mg2(dobpdc) | 10.1021/jacs.7b05858 |
| p135 | HP-PMOF-amine for DAC | 10.1021/acsami.5c11754 |
| p136 | Amine-functionalized MIL-100(Cr) for DAC | 10.1016/j.efmat.2025.02.003 |
| p137 | Evaluating MOFs for post-combustion TSA | 10.1039/c1ee01720a |
| p154 | Phase-change MOF F4_MIL-140A(Ce) in PVSA | chemrxiv-2023-zx95t |
| p144 | Decision tree models for CO2 capacity | 10.1038/s41598-021-04168-w |
| p158 | Amino acid functionalized MOF-808 in humid flue gas | 10.1021/jacs.1c13368 |
| p168 | Optimum RH enhances CO2 uptake in M2(dobpdc) | 10.1016/j.cej.2023.147119 |

> 完整 180 篇论文元数据见本包 `evidence/mof/papers.json`；知识图谱 v2.0 见 `evidence/mof/knowledge_graph.md`；Gap 分析见 `evidence/mof/gap_report.md`；阶段二发现见 `evidence/mof/discovery_report.md`。
