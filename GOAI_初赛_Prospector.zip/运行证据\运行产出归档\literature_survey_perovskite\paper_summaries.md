# Literature Survey — Paper Summaries

**Total papers:** 96
**Generated:** 2026-08-02T13:24:20.044820

---

**Sources:** unknown(96)
**Common keywords:** perovskite, solar, halide, perovskites, stability, phase, band, cells, gap, cspbi3, abstract, title, authors, segregation, films

---

### 1. Title: Organometal halide perovskite solar cells: degradation and stability
**ID:** `p1`

Abstract: <p>What are the bottlenecks for organometal halide perovskite solar cells to achieve the stability required for commercialization?</p>

### 2. Title: Stability of Metal Halide Perovskite Solar Cells
**ID:** `p2`

Abstract: In recent years, there has been an unprecedented rise in the performance of metal halide perovskite solar cells. They are now in a position to compete on performance with traditional crystalline solar cells, and as such the most pressing questions concern the long term operational stability of this class of solar cell. Here, recent developments in understanding and overcoming stability concerns of metal halide perovskite solar cells are highlighted. An overview of possible instability issues due to electrical, atmospheric, heat, and light stresses is provided and the different implications to the most commonly used device architectures are discussed.

### 3. Title: DFT exploration of novel direct band gap semiconducting halide double perovskites, A2AgIrCl6 (A = Cs, Rb, K), for solar cells application
**Authors:** M. A. Rayhan, M. M. Hossain, M. M. Uddin, S. H. Naqib, M. A Ali
**ID:** `p3`

Abstract: Double perovskite halides are promising materials for renewable energy production, meeting the criteria to address energy scarcity issues. As a result, studying these halides could be useful for optoelectronic and solar cell applications. In this study, we investigated the structural, mechanical, thermodynamic, electronic, and optical properties of A2AgIrCl6 (A = Cs, Rb, K) double perovskite halides using density functional theory calculations with the full-potential linearized augmented plane-wave (FP-LAPW) approach, aiming to evaluate their suitability for renewable energy devices. The Goldsmith tolerance factor, octahedral factor, and new tolerance factor have confirmed the cubic stability of the predicted compounds. We have also verified the thermodynamic stability of these c

### 4. Title: First-Principles Study on Material Properties and Stability of Inorganic Halide Perovskite Solid Solutions CsPb(I$_{1-x}$Br$_x$)$_3$ towards Hi
**Authors:** Chol-Jun Yu, Un-Hyok Ko, Suk-Gyong Hwang, Yun-Sim Kim, Un-Gi Jong, Yun-Hyok Kye, Chol-Hyok Ri
**ID:** `p4`

Abstract: All-inorganic halide perovskites have attracted a great interest as a promising light harvester of perovskite solar cells due to their enhanced chemical stability. In this work we investigate the material properties of solid solutions CsPb(I$_{1-x}$Br$_x$)$_3$ in cubic phase by applying the virtual crystal approximation approach within a density functional theory framework. First we check the validity of constructed pseudopotentials of the virtual atoms (X = I$_{1-x}$Br$_x$) by verifying that the lattice constants follow the linear function of mixing ratio. We then suggest an idea of using the hybrid HSE functional with linear increasing value of exact exchange term as increasing the Br content x, which produces the band gaps of CsPbX3 in good agreement with the available experim

### 5. Title: Stability of Tin-Lead Halide Perovskite Solar Cells
**ID:** `p5`

Abstract: Tin-lead perovskites have low band gaps (1.2 eV – 1.4 eV) that offer complementary absorption spectra to mixed halide perovskites with band gaps in the range of 1.6 eV – 1.85 eV. In combination, tin-lead and mixed halide perovskites can be used to make efficient all-perovskite tandem solar cells. While these can achieve high efficiency, they are hampered by the unproven longterm stability of tin-containing perovskites. We make the first demonstration of tin-lead perovskite solar cells that pass benchmark 1000-hour tests of stability under stressors of heat, light, and atmospheric exposure. We identify that mixed tin-lead perovskites oxidise by a different chemical pathway, one that is much less favourable, than the oxidation pathway followed by pure tin perovskites, making them s

### 6. Title: Interfaces and Stability in Halide Perovskite Solar Cells
**ID:** `p6`

Abstract: In this paper, I give a brief summary over the current development of interface engineering in perovskite solar cells (PSCs) and the corresponding impact on device performance and stability. Principal loss mechanisms in the PSC can be attributed to imperfect interfaces. Aside from the key electronic properties at these interfaces, such as energy level alignment and band offsets, the device functionality is governed by the complex chemistry between the halide perovskite absorber and the adjacent functional layers.

### 7. Title: Multifunctional Surface Treatment against Imperfections and Halide Segregation in Wide-Band Gap Perovskite Solar Cells
**ID:** `p7`

Abstract: Mixed-halide wide-band gap perovskites (WBPs) still suffer from losses due to imperfections within the absorber and the segregation of halide ions under external stimuli. Herein, we design a multifunctional passivator (MFP) by mixing bromide salt, formamidinium bromide (FABr) with a p-type self-assembled monolayer (SAM) to target the nonradiative recombination pathways. Photoluminescence measurement shows considerable suppression of nonradiative recombination rates after treatment with FABr. However, WBPs still remained susceptible to halide segregation for which the addition of 25% p-type SAM was effective to decelerate segregation. It is observed that FABr can act as a passivating agent of the donor impurities, shifting the Fermi-level (Ef) toward the mid-band gap, while p-type

### 8. Title: Thermal stability of lead-halide perovskites in perovskite solar cells
**ID:** `p8`

Abstract: Of the various third-generation solar cell technologies, lead-halide perovskite-based solar cells have achieved power efficiencies rivalling that of traditional silicon-based solar cells. This has spurred attempts to commercialise this new technology. However, thermal stability remains an unresolved issue for lead-halide perovskites, which impede their use in commercial applications. Elevated temperatures cause the perovskite structure to break down, and the material loses the property to absorb light efficiently. Thus, methods to stabilise the perovskite structure are necessary for eventual commercialisation. Compositional variation offers one pathway to attaining thermally stable perovskite films, although the current literature is shrouded in contradictions. One example is the

### 9. Title: Examining stability in organo-halide perovskite solar cells
**ID:** `p9`

Abstract: Stability in perovskite solar cells (PSCs) is a topic heavily studied by the research community in recent years, despite the impressive efficiencies achieved with these remarkable optically-active materials for photovoltaics (PV) applications. Specifically, moisture ingress and ion-transport need to be reduced to attain a lifetime sufficient for a commercially viable PV technology. The stability issues arise from a number of factors, including the susceptibility of the absorber to environmental conditions. In this work, we will discuss our efforts to examine the stability in PSCs from multiple angles, which include examining the role of interface layers, collector electrode material used, and the chemistry and crystalline structural of the absorber itself.

### 10. Title: High current, high efficiency graded band gap perovskite solar cells
**ID:** `p10`

Abstract: Organic-inorganic halide perovskite materials have emerged as attractive alternatives to conventional solar cell building blocks. Their high light absorption coefficients and long diffusion lengths suggest high power conversion efficiencies (PCE),1-5 and indeed perovskite-based single band gap and tandem solar cell designs have yielded impressive performances.1-16 One approach to further enhance solar spectrum utilization is the graded band gap, but this has not been previously achieved for perovskites. In this study, we demonstrate graded band gap perovskite solar cells with steady-state conversion efficiencies averaging 18.4%, with a best of 21.7%, all without reflective coatings. An analysis of the experimental data yields high fill factors of ~75% and high short circuit curre

### 11. Title: Study on phase transformation and band gap of organo-halide perovskite for solar cell application
**ID:** `p11`

Abstract:

### 12. Title: First-principles studies of oxygen interstitial dopants in RbPbI$_3$ halide for perovskite solar cells
**Authors:** Chongyao Yang, Wei Wu, Kwang-Leong Choy
**ID:** `p12`

Abstract: Recent research on perovskite solar cells has caught much attention for the application in renewable energy materials. However, the effect of external dopants on the performance of perovskite solar cell is yet to be understood properly. Oxygen atom or molecule is important dopant to influence the stability of structural, electronic and optical properties as well as the performance of perovskite solar cells. RbPbX3-type perovskites have fantastic chemical stability and good power conversion efficiency. Here for the first time, we have studied the effect of interstitial oxygen atom (O1) and molecule (O2) on the structural properties, and hence the electronic structure of RbPbI3 from first principles. A significant reduction of the band gap from ~2.6 eV to ~ 1.0 eV, which is close t

### 13. Title: Design of Lead-Free Inorganic Halide Perovskites for Solar Cells via Cation-Transmutation
**Authors:** Xin-Gang Zhao, Ji-Hui Yang, Yuhao Fu, Dongwen Yang, Qiaoling Xu, Liping Yu, Su-Huai Wei, Lijun Zhang
**ID:** `p13`

Abstract: Hybrid organic-inorganic halide perovskites with the prototype material of CH$_{3}$NH$_{3}$PbI$_{3}$ have recently attracted intense interest as low-cost and high-performance photovoltaic absorbers. Despite the high power conversion efficiency exceeding 20% achieved by their solar cells, two key issues -- the poor device stabilities associated with their intrinsic material instability and the toxicity due to water soluble Pb$^{2+}$ -- need to be resolved before large-scale commercialization. Here, we address these issues by exploiting the strategy of cation-transmutation to design stable inorganic Pb-free halide perovskites for solar cells. The idea is to convert two divalent Pb$^{2+}$ ions into one monovalent M$^{+}$ and one trivalent M$^{3+}$ ions, forming a rich class of quate

### 14. Title: Enhancing Intrinsic Stability of Hybrid Perovskite Solar Cell by Strong, yet Balanced, Electronic Coupling
**Authors:** Fedwa El-Mellouhi, El Tayeb Bentria, Sergey N Rashkeev, Sabre Kais, Fahhad H Alharbi
**ID:** `p14`

Abstract: In the past few years, the meteoric development of hybrid organic--inorganic perovskite solar cells (PSC) astonished the community. The efficiency has already reached the level needed for commercialization; however, the instability hinders its deployment on the market. Here, we report a mechanism to chemically stabilize PSC absorbers. We propose to replace the widely used methylammonium cation (\ce{CH3NH3+}) by alternative molecular cations allowing an enhanced electronic coupling between the cation and the \ce{PbI6} octahedra while maintaining the band gap energy within the suitable range for solar cells. The mechanism exploits establishing a balance between the electronegativity of the materials' constituents and the resulting ionic electrostatic interactions. The calculations 

### 15. Title: Improved evaluation of deep-level transient spectroscopy on perovskite solar cells reveals ionic defect distribution
**Authors:** Sebastian Reichert, Jens Flemming, Qingzhi An, Yana Vaynzof, Jan-Frederik Pietschmann, Carsten Deibel
**ID:** `p15`

Abstract: One of the key challenges for future development of efficient and stable metal halide perovskite solar cells is related to the migration of ions in these materials. Mobile ions have been linked to the observation of hysteresis in the current--voltage characteristics, shown to reduce device stability against degradation and act as recombination centers within the band gap of the active layer. In the literature one finds a broad spread of reported ionic defect parameters (e.g. activation energies) for seemingly similar perovskite materials, rendering the identification of the nature of these species difficult. In this work, we performed temperature dependent deep-level transient spectroscopy (DLTS) measurements on methylammonium lead iodide perovskite solar cells and developed a ex

### 16. Title: Enhanced stability of 2D organic-inorganic halide perovskites by doping and heterostructure engineering
**Authors:** Rahul Singh, Prashant Singh, Ganesh Balasubramanian
**ID:** `p16`

Abstract: Organic-inorganic halide perovskite solar cells have recently attracted much attention due to their low-cost fabrication, flexibility, and high-power conversion efficiency. The reduction from three- to two-dimension (2D) promises an exciting opportunity to tune the electronic properties of organic-inorganic halide perovskites. Here, we propose first-principles density-functional theory based route to study the effect of reduced dimensionality, impurity doping, and heterostructure engineering on energy stability, band-gap and transport properties of 2D hybrid organic-inorganic halide perovskites. We show that the energetic stability of two-dimensional organic-inorganic halide perovskites can be significantly enhanced by chemically depositing MoS2 monolayer as a precursor in the sy

### 17. Title: First-principles study on the electronic and optical properties of inorganic perovskite Rb1-xCsxPbI3 for solar cell applications
**Authors:** Un-Gi Jong, Chol-Jun Yu, Yun-Sim Kim, Yun-Hyok Kye, Chol-Ho Kim
**ID:** `p17`

Abstract: Recently, replacing or mixing organic molecules in the hybrid halide perovskites with the inorganic Cs or Rb cations has been reported to increase the material stability with the comparable solar cell performance. In this work, we systematically investigate the electronic and optical properties of all-inorganic alkali iodide perovskites Rb1-xCsxPbI3 using the first-principles virtual crystal approximation calculations. Our calculations show that as increasing the Cs content x, lattice constants, band gaps, exciton binding energies, and effective masses of charge carriers decrease following the quadratic (linear for effective masses) functions, while static dielectric constants increase following the quadratic function, indicating an enhancement of solar cell performance upon the 

### 18. Title: Crystal structure, stability and optoelectronic properties of the organic-inorganic wide bandgap perovskite CH3NH3BaI3: Candidate for transpare
**Authors:** Akash Kumar, K. R. Balasubramaniam, Jiban Kangsabanik,  Vikram, Aftab Alam
**ID:** `p18`

Abstract: Structural stability, electronic structure and optical properties of CH3NH3BaI3 hybrid perovskite is examined both from theory as well as experiment. Solution-processed thin films of CH3NH3BaI3 exhibited a high band gap of approximately 3.87 eV, which is in excellent agreement with the theoretical estimate of 4 eV. Also, the XRD patterns of the thin films match well with the l-peaks of the simulated pattern obtained from the relaxed unit cell of CH3NH3BaI3, crystallizing in the I4/mcm space group, with lattice parameters, a = 9.30 A, c = 13.94 A. Atom projected density of state and band structure calculations reveal the conduction and valence band edges to be comprised primarily of Barium d-orbitals and Iodine p-orbitals, respectively. The larger band gap of CH3NH3BaI3 compared t

### 19. Title: High-Throughput Screening for Band gap Engineering by Sublattice Mixing of Cs$_2$AgBiCl$_6$ from First-Principles
**Authors:** Deepika Gill, Preeti Bhumla, Manish Kumar, Saswata Bhattacharya
**ID:** `p19`

Abstract: The lead-free double perovskite material (viz. Cs$_2$AgBiCl$_6$) has emerged as an efficient and environmentally friendly alternative to lead halide perovskites. To make Cs$_2$AgBiCl$_6$ optically active in the visible region of solar spectrum, band gap engineering approach has been undertaken. Using Cs$_2$AgBiCl$_6$ as a host, band gap and optical properties of Cs$_2$AgBiCl$_6$ have been modulated by alloying with M(I), M(II), and M(III) cations at Ag-/Bi-sites. Here, we have employed density functional theory (DFT) with suitable exchange-correlation functionals in light of spin-orbit coupling (SOC) to determine the stability, band gap and optical properties of different compositions, that are obtained on Ag-Cl and Bi-Cl sublattices mixing. On analyzing the 64 combinations withi

### 20. Title: Revealing the stability and efficiency enhancement in mixed halide perovskites MAPb(I$_{1-x}$Cl$_x$)$_3$ with ab initio calculations
**Authors:** Un-Gi Jong, Chol-Jun Yu, Yong-Man Jang, Gum-Chol Ri, Song-Nam Hong, Yong-Hyon Pae
**ID:** `p20`

Abstract: A little addition of Cl to \ce{MAPbI3} has been reported to improve the material stability as well as light harvesting and carrier conducting properties of organometal trihalide perovskites, the key component of perovskite solar cell (PSC). However, the mechanism of performance enhancement of PSC by Cl addition is still unclear. Here, we apply the efficient virtual crystal approximation method to revealing the effects of Cl addition on the structural, electronic, optical properties and material stability of \ce{MAPb(I_{1-x}Cl_x)3}. Our {\it ab initio} calculations present that as the increase of Cl content cubic lattice constants and static dielectric constants decrease linearly, while band gaps and exciton binding energies increase quadratically. Moreover, we find the minimum of

### 21. Title: Protective Coating Interfaces for perovskite Solar Cell Materials: A first Principles Study
**Authors:** Azimatu Fangnon, Marc Dvorak, Ville Havu, Milica Todorovic, Jingrui Li, Patrick Rinke
**ID:** `p21`

Abstract: The protection of halide perovskites is important for the performance and stability of emergent perovskite-based optoelectronic technologies. In this work, we investigate the potential inorganic protective coating materials ZnO, SrZrO3, and ZrO2 for the CsPbI3perovskite. The optimal interface registries are identified with Bayesian optimization. We then use semi-local density-functional theory (DFT) to determine the atomic structure at the interfaces of each coating material with the clean CsI-terminated surface and three reconstructed surface models with added PbI2and CsI complexes. For the final structures, we explore the level alignment at the interface with hybrid DFT calculations. Our analysis of the level alignment at the coating-substrate interfaces reveals no detrimental 

### 22. Title: Lead-Free Halide Double Perovskites via Heterovalent Substitution of Noble Metals
**Authors:** George Volonakis, Marina R. Filip, Amir Abbas Haghighirad, Nobuya Sakai, Bernard Wenger, Henry J. Snaith, Feliciano Giustino
**ID:** `p22`

Abstract: Lead-based halide perovskites are emerging as the most promising class of materials for next generation optoelectronics. However, despite the enormous success of lead-halide perovskite solar cells, the issues of stability and toxicity are yet to be resolved. Here we report on the computational design and the experimental synthesis of a new family of Pb-free inorganic halide double-perovskites based on bismuth or antimony and noble metals. Using first-principles calculations we show that this hitherto unknown family of perovskites exhibits very promising optoelectronic properties, such as tunable band gaps in the visible range and low carrier effective masses. Furthermore, we successfully synthesize the double perovskite Cs2BiAgCl6, we perform structural refinement using single-cr

### 23. Title: Efficient Modelling of Ion Structure and Dynamics in Inorganic Metal Halide Perovskites
**Authors:** Salvador Rodriguez-Gomez Balestra, Jose Manuel Vicent-Luna, Sofia Calero, Shuxia Tao, Juan A. Anta
**ID:** `p23`

Abstract: Metal halide perovskites (MHPs) are nowadays one of the most studied semiconductors due to their exceptional performance as active layers in solar cells. Although MHPs are excellent solid-state semiconductors, they are also ionic compounds, where ion migration plays a decisive role in their formation, their photovoltaic performance and their long-term stability. Given the above-mentioned complexity, molecular dynamics simulations based on classical force fields are especially suited to study MHP properties, such as lattice dynamics and ion migration. In particular, the possibility to model mixed compositions is important since they are the most relevant to optimize the optical band gap and the stability. With this intention, we employ DFT calculations and a genetic algorithm to d

### 24. Title: Influence of halide composition on the structural, electronic, and optical properties of mixed CH$_3$NH$_3$Pb(I$_{1-x}$Br$_x$)$_3$ perovskites 
**Authors:** Un-Gi Jong, Chol-Jun Yu, Nam-Hyok Kim, Guk-Chol Ri
**ID:** `p24`

Abstract: We investigate the structural, electronic and optical properties of mixed bromide-iodide lead perovskite solar cell CH$_3$NH$_3$Pb(I$_{1-x}$Br$_x$)$_3$ by means of the virtual crystal approximation (VCA) within density functional theory (DFT). Optimizing the atomic positions and lattice parameters increasing the bromide content $x$ from 0.0 to 1.0, we fit the calculated lattice parameter and energy band gap to the linear and quadratic function of Br content, respectively, which are in good agreement with the experiment, respecting the Vegard's law. With the calculated exciton binding energy and light absorption coefficient, we make sure that VCA gives consistent results with the experiment, and the mixed halide perovskites are suitable for generating the charge carriers by light 

### 25. Title: Force-Matching Based Polarizable and Non-Polarizable Force Fields for Perovskite and Non-Perovskite Phases of CsPbI$_3$
**Authors:** C. Vona, M. Dankl, A. Boziki, M. P. Bircher, U. Rothlisberger
**ID:** `p25`

Abstract: Lead halide perovskites have emerged as highly efficient solar cell materials. However, to date, the most promising members of this class are polymorphs, in which a wide-band gap $δ$ phase competes with the photoactive perovskite $α$ form, and the intrinsic physical interactions that stabilize one phase over the other are currently not well understood. Classical molecular dynamics simulations based on suitably parameterized force fields (FF) enable computational studies over broad temperature (and pressure) ranges and can help to identify the underlying factors that govern relative phase stability at the atomic level. In this article, we present a polarizable (pol) as well as a non-polarizable (npol) FF for the all-inorganic lead halide material CsPbI$_3$ as a prototype system ex

### 26. Title: Thermodynamic Band Gap Model for Photoinduced Phase Segregation in Mixed-Halide Perovskites
**ID:** `p26`

Abstract: Provided is a comprehensive description of a band gap thermodynamic model, which predicts and explains key features of photosegregation in lead-based, mixed-halide perovskites. The model gives a prescription for illustrating halide migration driven by photocarrier energies. Where possible, model predictions are compared with experimental results. Free energy derivations are provided for three assumptions: (1) halide mixing in the dark, (2) a fixed number of photogenerated carriers funneling to and localizing in low band gap inclusions of the alloy, and (3) the statistical occupancy of said inclusions from a bath of thermalized photocarriers in the parent material. Model predictions include excitation intensity ( I exc )-dependent terminal halide stoichiometries ( x terminal ), te

### 27. Title: Formation\nof Dual Bands in Mixed-Halide Perovskites\nDuring Photoinduced Halide Segregation
**ID:** `p27`

Abstract: In mixed-halide perovskites, photoinduced halide segregation\nis\nknown to occur, leading to the formation of segregated domains and,\nthereby, an additional low-energy photoluminescence emission. Here,\nwe probe an archetypical mixed-halide perovskite from the perspective\nof band energies on the microscopic scale. Through optically coupled\nscanning tunneling spectroscopy, we determine the band energies of\nhalide-segregated domains, namely, iodide-rich and bromide-rich ones.\nWe estimate the composition of the phases and identify energy-levels\nassociated with them as would be “seen” by charge carriers\nin devices. The appearance of dual bands due to the segregation process\nis explained in light of the molecular orbitals involved in forming\nthe bands. Kelvin probe force micr

### 28. Title: How Chloride Suppresses Photoinduced Phase Segregation in Mixed Halide Perovskites
**ID:** `p28`

Abstract: Halide\nion mobility in metal halide perovskites plays an important\nrole in dictating the overall device performance and long-term stability\nof perovskite solar cells. Alloying with chloride (Cl), which is known\nto stabilize the perovskite solar cells, has now been found to suppress\nthe photoinduced halide ion segregation in mixed halide (Br/I) perovskites.\nBy varying the chloride concentration of 1–10% (as part of\nthe halide composition), we have probed both photoinduced segregation\nand dark recovery kinetics at different temperatures. When we increased\nthe concentration of Cl from 0 to 5%, we observed a decrease in the\nrate constant of segregation by a factor of ∼5 and a decrease\nin the fraction of halide segregation from 45 to 20%. The activation\nenergy for photoind

### 29. Title: Wide-Band-Gap Mixed-Halide 3D Perovskites: Electronic Structure and Halide Segregation Investigation
**ID:** `p29`

Abstract: Mixed-halide organolead perovskites (  MAPbX 3   ) are of great interest for both single-junction and tandem solar cells because of their wide band gap. In this study, we investigate the family of mixed iodide/bromide (I/Br) and bromide/chloride (Br/Cl) perovskites, revealing the strong influence of halide substitution on electronic properties, morphology, film composition, and phase segregation. A qualitative blue shift with the I → Br → Cl series was observed, with the resulting optical absorption ranging from 420 to 800 nm covering nearly the entire visible region. The ionization potential increases from ≈6.0 to ≈7.0 eV as the halide composition changes from I to Br. However, with Cl components, the valence band position shows little variation, while the conduction band minimu

### 30. Title: EXPLORING PHOTOINDUCED PHASE SEGREGATION IN MIXED HALIDE PEROVSKITE POWDERS
**ID:** `p30`

Abstract:

### 31. Title: Spacer Cations Dictate Photoinduced Phase Segregation\nin 2D Mixed Halide Perovskites
**ID:** `p31`

Abstract: The\nspacer cation in two-dimensional (2D) Ruddlesden–Popper\nlead halide perovskites dictates photoinduced phase segregation. Halide\nion segregation under steady-state irradiation of single-layer (&lt;i&gt;n&lt;/i&gt; = 1) 2D perovskites is seen when butylammonium (BA) is\nused as the spacer cation, whereas it is essentially absent when BA\nis replaced with phenethylammonium (PEA).

### 32. Title: In\nSitu Observation\nof Photoinduced Halide Segregation\nin Mixed Halide Perovskite
**ID:** `p32`

Abstract: Mixed–halide perovskites have\nemerged as a promising\ncandidate\nfor optoelectronics, due to their tunable optical properties. However,\nphotoinduced phase segregation remains an obstacle for stable performance\nin solar cells. Here, we have conducted both bulk and nanoscale measurements\nto elucidate the mechanism of halide ion migration that leads to phase\nsegregation. By utilizing Kelvin probe force microscopy (KPFM) under\nillumination, we have observed the time-evolution of ion migration\nto and from grain boundaries that agreed with bulk photoluminescence\nspectra of perovskites with a wide range of band gaps (1.67–1.88\neV), Cs&lt;sub&gt;0.15&lt;/sub&gt;FA&lt;sub&gt;0.65&lt;/sub&gt;MA&lt;sub&gt;0.20&lt;/sub&gt;Pb(I&lt;sub&gt;&lt;i&gt;x&lt;/i&gt;&lt;/sub&gt;Br&lt;sub&gt;1

### 33. Title: Impact of Surfaces on Photoinduced Halide Segregation in Mixed-Halide Perovskites
**ID:** `p33`

Abstract: Photoinduced halide segregation currently limits the perovskite chemistries available for use in high-bandgap semiconductors needed for tandem solar cells. Here, we study the impact of post-deposition surface modifications on photoinduced halide segregation in methylammonium lead mixed-halide perovskites. By coating a perovskite surface with the electron-donating ligand trioctylphosphine oxide (TOPO), we are able to both reduce nonradiative recombination and dramatically slow the onset of halide segregation in CH3NH3PbI2Br films. This result, coupled with the observation that the rate of halide segregation can be tuned by varying the selective contact, provides a direct link between surface modifications and photoinduced trap formation. On the basis of these observations, we disc

### 34. Title: Photoinduced Anion Segregation in Mixed Halide Perovskites
**ID:** `p34`

Abstract: Alloyed lead halide perovskites have taken a dominant role in the quest for third-generation solar cells. This is due to optimal light-harvesting properties, which can be tuned across the visible spectrum by mixing halide (X = Cl, Br, and I) anions and A+ cations (A+ = FA+, MA+, and Cs+). Durability issues related to ion transport are also addressed by the use of different types of perovskite materials. The combination, uniformly mixed halide perovskites [e.g., APb1-xBrx3] reversibly segregate into narrow bandgap I-rich and wide bandgap Br-rich domains during continuous visible illumination. Subsequent I-rich domains reduce local open circuit voltages and decrease mixed halide perovskite solar cell power conversion efficiencies. In this review, we assess the known effects of hali

### 35. Title: Ba-induced phase segregation and band gap reduction in mixed-halide inorganic perovskite solar cells
**ID:** `p35`

Abstract: All-inorganic metal halide perovskites are showing promising development towards efficient long-term stable materials and solar cells. Element doping, especially on the lead site, has been proved to be a useful strategy to obtain the desired film quality and material phase for high efficient and stable inorganic perovskite solar cells. Here we demonstrate a function by adding barium in CsPbI2Br. We find that barium is not incorporated into the perovskite lattice but induces phase segregation, resulting in a change in the iodide/bromide ratio compared with the precursor stoichiometry and consequently a reduction in the band gap energy of the perovskite phase. The device with 20 mol% barium shows a high power conversion efficiency of 14.0% and a great suppression of non-radiative r

### 36. Title: Photoinduced Halide Segregation in Ruddlesden–Popper 2D Mixed Halide Perovskite Films
**ID:** `p36`

Abstract: 2D lead halide perovskites, which exhibit bandgap tunability and increased chemical stability, have been found to be useful for designing optoelectronic devices. Reducing dimensionality with decreasing number of layers (n = 10-1) also imparts resistance to light-induced ion migration as seen from the halide ion segregation and dark recovery in mixed halide (Br:I = 50:50) perovskite films. The light-induced halide ion segregation efficiency, as determined from difference absorbance spectra, decreases from 20% to <1% as the dimensionality is decreased for 2D perovskite film from n = 10 to 1. The segregation rate constant (ksegregation ), which decreases from 5.9 × 10-3 s-1 (n = 10) to 3.6 × 10-4 s-1 (n = 1), correlates well with nearly an order of magnitude decrease observed in cha

### 37. Title: Photoinduced Self-healing of Halide Segregation in Mixed-halide Perovskites
**ID:** `p37`

Abstract: Photoinduced halide segregation (PIHS) is an inevitable issue in the deterioration of the phase stability of band-gap-tunable mixed-halide perovskites (MHPs). Herein, under continuous irradiation of sunlight, we first discover that the polycrystalline CsPbI3–xBrx films always experience a phase transformation from halide mixing to demixing and then to halide remixing (namely photoinduced self-healing of PIHS). Particularly, the obtained film will no longer demix after the mixing–demixing–remixing cycle. We then demonstrate that the specific positions for halide ions migration gradually approach their demixing terminal (here a strain-tolerance threshold of the perovskite lattice) driven by photoexcited carriers. However, once the threshold is exceeded, the intolerable strain break

### 38. Title: In Situ Observation of Photoinduced Halide Segregation in Mixed Halide Perovskite
**ID:** `p38`

Abstract: Mixed–halide perovskites have emerged as a promising candidate for optoelectronics, due to their tunable optical properties. However, photoinduced phase segregation remains an obstacle for stable performance in solar cells. Here, we have conducted both bulk and nanoscale measurements to elucidate the mechanism of halide ion migration that leads to phase segregation. By utilizing Kelvin probe force microscopy (KPFM) under illumination, we have observed the time-evolution of ion migration to and from grain boundaries that agreed with bulk photoluminescence spectra of perovskites with a wide range of band gaps (1.67–1.88 eV), Cs 0.15 FA 0.65 MA 0.20 Pb(I x Br 1– x ) 3 where x = 0.47–0.80. By visualizing the changes of band bending at grain boundaries, we deduce that halide segregati

### 39. Title: Photoinduced phase segregation in wide-bandgap mixed-halide perovskite solar cells
**ID:** `p39`

Abstract: Wide-bandgap (WB) mixed-halide perovskite solar cells (PSCs) play a crucial role in perovskite-based tandem solar cells (TSCs), enabling them to exceed the Shockley-Queisser limits of single-junction solar cells. Nonetheless, the lack of stability in WB perovskite films due to photoinduced phase segregation undermines the stability of WB PSCs and their TSCs, thus impeding the commercialization of perovskite-based TSCs. Many efforts have been made to suppress photoinduced phase segregation in WB perovskite films and significant progresses have been obtained. In this review, we elaborate the mechanisms behind photoinduced phase segregation and its impact on the photovoltaic performance and stability of devices. The importance role of advanced characterization techniques in confirmi

### 40. Title: Sterically Suppressed Phase Segregation in 3D Hollow Mixed-Halide Wide Band Gap Perovskites
**ID:** `p40`

Abstract: Band gap tuning in mixed-halide perovskites enables efficient multijunction solar cells and LEDs. However, these wide band gap perovskites, which contain a mixture of iodide and bromide ions, are known to phase segregate under illumination, introducing voltage losses that limit stability. Previous studies have employed inorganic perovskites, halide alloys, and grain/interface passivation to minimize halide segregation, yet photostability can be further advanced. By focusing on the role of halide vacancies in anion migration, one expects to be able to erect local barriers to ion migration. To achieve this, we employ a 3D "hollow" perovskite structure, wherein a molecule that is otherwise too large for the perovskite lattice is incorporated. The amount of hollowing agent, ethane-1,

### 41. Title: Suppressing Halide Segregation in Wide-Band-Gap Mixed-Halide Perovskite Layers through Post-Hot Pressing
**ID:** `p41`

Abstract: Mixed-halide perovskites (MHPs) have attracted attention as suitable wide-band-gap candidate materials for tandem applications owing to their facile band-gap tuning. However, when smaller bromide ions are incorporated into iodides to tune the band gap, photoinduced halide segregation occurs, which leads to voltage deficit and photoinstability. Here, we propose an original post-hot pressing (PHP) treatment that suppresses halide segregation in MHPs with a band gap of 2.0 eV. The PHP treatment reconstructs open-structured grain boundaries (GBs) as compact GBs through constrained grain growth in the in-plane direction, resulting in the inhibition of defect-mediated ion migration in GBs. The PHP-treated wide-band-gap (2.0 eV) MHP solar cells showed a high efficiency of over 11%, achi

### 42. Title: Temperature Dependence of Photoinduced Phase Segregation in Bromide-Rich Mixed Halide Perovskites
**ID:** `p42`

Abstract: Mixed halide perovskites undergo phase segregation, manifested as spectral red-shifting of photoluminescence spectra under illumination. In the iodine-bromide mixed perovskites, the origin of the low-energy luminescence is related to iodine-enriched domains formation. Such domains create favorable bands for the induced carrier funneling into them. Despite the phase segregation process is crucial for mixed halide perovskite-based optoelectronics, numerous gaps exist within the understanding of this phenomenon. One such gap pertains to the emergence of temporary and intermediate photoluminescence peaks during the initial stages of phase segregation. However, these peaks appear only within the first few seconds of illumination. Nevertheless, the decreasing temperature may prolong th

### 43. Title: Suppressing photoinduced phase segregation in mixed halide perovskites
**ID:** `p43`

Abstract: Mixed halide perovskites (MHPs) have attracted attention due to their tunability of optoelectronic properties and especially the bandgap, which is useful for tandem solar cells. Unfortunately, MHPs undergo phase separation under illumination. It can form low-bandgap iodide-rich phases as charge recombination centers, causing the reduction of open-circuit voltage (Voc) and device photoinstability. To address this issue, many approaches have been used[1]. In ABX3 MHPs, A-site can be CH3NH3 (MA+), CH(NH2)2 (FA+) or Cs+, B-site can be Pb2+ or Sn2+, and X-site is dominated by halide anion (Cl–, Br– or I–). The composition engineering on A/B/X sites can effectively alleviate the photoinduced phase separation. Photoinduced phase separation is common in MHPs with single cation at A-site,

### 44. Title: Manipulation of Photoinduced Phase Segregation Kinetics by Mixed Halide Composition in Inorganic Halide Perovskite
**ID:** `p44`

Abstract: High Resolution Image Download MS PowerPoint Slide Understanding and controlling photoinduced phase segregation (PIPS) is essential for improving the performance and stability of mixed-halide perovskite optoelectronic devices. In this work, we investigated the composition-dependent kinetics of PIPS in all-inorganic mixed-halide perovskite thin films. By tuning the halide ratio in CsPbI X Br 3– X, we demonstrate that the PIPS rate constant can be effectively manipulated, as higher iodide content leads to reduced crystallinity and increased defect density, which accelerates the PIPS process. Furthermore, time-resolved photoluminescence measurements reveal that the excited-state dynamics during PIPS differ significantly between iodide-rich and bromide-rich systems, underscoring the 

### 45. Title: Photoinduced Phase Segregation in Mixed Halide Perovskites: Mechanisms, Suppression Strategies, and Device Performance Optimization
**ID:** `p45`

Abstract: For mixed-halide perovskite solar cells, the phenomenon of photoinduced phase segregation (PIPS) and its derivative effect of uneven spatial ion distribution within the material have induced a series of adverse consequences. Since the discovery of this phenomenon, although substantial research progress has yielded significant achievements in this field, a systematic logical organization among different research methodologies or models of PIPS remains scarce. To address this gap, this review systematically traces the evolution of PIPS research─from fundamental thin-film properties to its impact on the operational performance of complete solar cells. Through synthesizing prevalent models and corresponding solutions, it endeavors not only to summarize the intrinsic logic within each

### 46. Title: Tweaking the band gap and photoluminescence of CsPbI3 perovskite by Mn alloying
**ID:** `p46`

Abstract: Alloying semiconductor nanocrystals with impurity can stabilize their phase with modulation of their morphology, lattice structure, photophysical and electronic properties which enhance their suitability towards solar cells and light-emitting diodes (LEDs). Herein we sought to substitute Mn2+ in CsPbI3 nanoparticles (NPs) to overcome the phase transformation issue as well as to tune the electronic and optical properties of this perovskite material. The phase of the alloyed CsPbI3 NPs was stabilized endowing high crystalline quality which can be clearly seen in X-ray diffraction (XRD). XRD plot depicts that impurity peaks arise in the case of CsPbI3 NPs while the phase of Mn2+ alloyed NPs was stabilized upto 1 month. The decrease in lattice parameter values from 6.019 Å to 5.987 Å

### 47. Title: Solid-State Growth of Cspbi3 Perovskites: Phases Formation and Stability
**ID:** `p47`

Abstract: Totally inorganic perovskites are playing an increasingly important role for their potential applications in optoelectronics devices. However, a big problem to be solved is the role of the different phases, the presence of which is closely linked to the growth method and to the role of impurities. In this article, we propose a solvent-free, solid-state growth method, which allows to obtain samples free of any organic residues. The analysis of structural (XRD and Raman measurements), optical (absorption, steady-time and time-resolved luminescence) and morphological (HRTEM imaging), permitted to understand the phase evolution during the synthesis as a function of the temporal duration. The dynamic equilibrium process at high temperature between the CsPbI3 and the starting precursor

### 48. Title: Predictive Determination of Band Gaps of Inorganic Halide Perovskites
**ID:** `p48`

Abstract: We carry out first-principles calculations of band gaps of cubic inorganic perovskites belonging to the class CsBX3, with B = Pb, Sn and X = Cl, Br, I. We use the quasi-particle self-consistent GW method with efficient vertex corrections to calculate the electronic structure of the studied materials. We demonstrate the importance of including the higher-lying core and semicore shells among the valence states. For a meaningful comparison with experimental values, we account for thermal vibrations and disorder through ab initio molecular dynamics. Additionally, we calculate the spin-orbit coupling at levels of theory of increasing accuracy and show that semilocal density functionals significantly underestimate these corrections. We show that all of these effects need to be properly

### 49. Title: Organic vs. inorganic lead halide perovskites: Navigating synthesis pathways and stability landscapes of CH3NH3PbI3 and CsPbI3
**ID:** `p49`

Abstract: Perovskite solar cells have rapidly surfaced as leading prospects for future generation solar conversion technologies due to their high efficiency power conversion, economical fabrication methods, and tailorable optoelectronic behaviour. Among them, organic lead halide perovskites such as methyl ammonium lead iodide CH<sub>3</sub>NH<sub>3</sub>PbI<sub>3</sub> (MAPbI<sub>3</sub>) and all-inorganic cesium lead iodide (CsPbI<sub>3</sub>) have gained particular prominence. This review provides a specialized summary of the crystal structures, synthesis routes and thin-film fabrication techniques, and major stability challenges of both the perovskite structure. While MAPbI<sub>3</sub> exhibits superior photon-to-energy conversion and easy to fabricate but it suffers from high vulnerabi

### 50. Title: Stabilizing the alpha-Phase of CsPbI3 Perovskite by Sulfobetaine Zwitterions in One-Step Spin-Coating Films
**ID:** `p50`

Abstract: Inorganic cesium lead halide perovskites (CsPbI3) are promising materials for efficient wide-bandgap perovskite solar cells, but they suffer from a phase transition from black α phase to yellow δ phase at room temperature. Here, we report a facile method to stabilize the α-phase CsPbI3 films via a single-step film deposition process. A small amount (∼1.5 wt %) of sulfobetaine zwitterion mixed in CsPbI3 precursor solution could facilitate the formation of black-phase CsPbI3 films that show significantly improved phase stability in air. The black-phase stabilization can be explained by the formation of small CsPbI3 grains with average size of ∼30 nm, which increased the grain surface area to stabilizes the α phase. The zwitterions were found to impede the crystallization of CsPbI3 

### 51. Title: Enhancing CsPbI3 Perovskite Stability via Crystallization Kinetics Modulation
**ID:** `p51`

Abstract: Enhancing CsPbI3 Perovskite Stability via Crystallization Kinetics ModulationFrancesca Russo a, b, Elisabetta Fanizza a, Gennaro Ventruti c, Sofia Masi d, Ivan Mora Serò d, Francesco Fracassi a, Silvia Colella e, Andrea Listorti aa Dipartimento di Chimica, Università degli Studi di Bari "Aldo Moro", Via Orabona 4, 70126 Bari, Italyb Dipartimento di Ingegneria Elettrica e dell'Informazione, Politecnico di Bari, Via Orabona 4, 70126 Bari, Italyc Dipartimento di Scienze della Terra e Geoambientali, Università degli Studi di Bari Aldo Moro, Via Orabona 4, 70126 Bari, Italyd Institute of Advanced Materials (INAM), Universitat Jaume I, Av. De Vicent Sos Baynat, s/n 12071 Castellò, Spaine CNR NANOTEC - c/o Dipartimento di Chimica, Università degli Studi di Bari "Aldo Moro", Via Orabona 

### 52. Title: Effect of Sodium Doping on the Phase Stability and Band Gap Energy of Tin-Based Perovskite Films
**ID:** `p52`

Abstract: Abstract This study examines the effect of sodium (Na) doping on the phase stability and band gap energy of tin-based perovskite materials, specifically (MA 1-x Na x )SnI 3 and (MA 1-x Na x )SnICl 2 (x = 0, 0.1, and 0.15). The perovskite films were synthesized via solution casting at room temperature using dimethylformamide as the solvent and ascorbic acid as the reductant agent. Visual observations reveal that the 10% Na-doped perovskite films maintained their black color for up to 3 days, indicating enhanced phase stability. X-ray diffraction (XRD) analysis shows an improved crystallinity at 10 mol% Na doping, with sharper diffraction peaks, but also with a double perovskite structure due to Sn 2+ oxidation to Sn 4+ . These changes are reflected in band gap energy values (E g )

### 53. Title: Compositional Engineering for Efficient Wide Band Gap Perovskites with Improved Stability to Photoinduced Phase Segregation
**ID:** `p53`

Abstract: Metal halide perovskites are attractive candidates for the wide band gap absorber in tandem solar cells. While their band gap can be tuned by partial halide substitution, mixed halide perovskites often have lower open-circuit voltage than would be expected and experience photoinduced trap formation caused by halide segregation. We investigate solar cell performance and photostability across a compositional space of formamidinium (FA) and cesium (Cs) at the A-site at various halide compositions and show that using more Cs at the A-site rather than more Br at the X-site to raise band gap is more ideal as it improves both V OC and photostability. We develop band gap maps and design criteria for the selection of perovskite compositions within the Cs x FA 1– x Pb(Br y I 1– y ) 3, spac

### 54. Title: First-principles investigation on the stability and material properties of all-inorganic cesium lead iodide perovskites CsPbI3 polymorphs
**ID:** `p54`

Abstract: Cesium metal halide perovskites are very promising light absorbing materials for solar cells, due to their good thermal stability compared to other organometallic perovskites. Cesium lead iodide perovskite \\mathrm{CsPbI}_3\\ is one the most promising compound from this family because of its band gap of \\1.7\\mathrm{eV}\\ suitable for a top cell in silicon tandem solar cell. Herein, we systematically investigate the structural, electronic, elastic, optical properties and some carrier transport properties of \\mathrm{CsPbI}_3\\ perovskites polymorphs using pseudo-potential plane wave method implemented in CASTEP and ABINIT codes. We use hybrid functional within the GW approximation (GW-HSE06) and the spin-orbit coupling (GGA-PBE +SOC) to estimate the band gaps. The elastic proper

### 55. Title: Understanding size dependence of phase stability and band gap in CsPbI3 perovskite nanocrystals
**ID:** `p55`

Abstract: Inorganic halide perovskites CsPbX3 (X = Cl, Br, I) have been widely studied as colloidal quantum dots for their excellent optoelectronic properties. Not only is the long-term stability of these materials improved via nanostructuring, their optical bandgaps are also tunable by the nanocrystal (NC) size. However, theoretical understanding of the impact of the NC size on the phase stability and bandgap is still lacking. In this work, the relative phase stability of CsPbI3 as a function of the crystal size and the chemical potential is investigated by density functional theory. The optically active phases (α- and γ-phase) are found to be thermodynamically stabilized against the yellow δ-phase by reducing the size of the NC below 5.6 nm in a CsI-rich environment. We developed a more 

### 56. Title: Reversible Band Gap Narrowing of Sn‐Based Hybrid Perovskite Single Crystal with Excellent Phase Stability
**ID:** `p56`

Abstract: An intriguing reversible band gap narrowing behavior of the lead-free hybrid perovskite single crystal DMASnI3 (DMA=CH3 NH2 CH3 + ) from yellow to black is observed without phase transformation. We discuss the transformation mechanism in detail. More interestingly, the transformed samples in black can rapidly self-heal into yellow ones when exposed to deionized water (DI water). Contrary to other hybrid perovskites, DMASnI3 crystals exhibit excellent water phase stability. For example, DMASnI3 was immersed in DI water for 16 h and no decomposition was observed. Inspired by its excellent water phase stability, we demonstrate a potential eco-friendly application of DMASnI3 in photo-catalysis for H2 evolution in DI water. We present the first H2 evolution rate of 0.64 μmol h-1 with 

### 57. Title: Dimethyl sulfoxide: a promising solvent for inorganic CsPbI3 perovskite
**ID:** `p57`

Abstract: Inorganic CsPbI3 perovskite is an important photovoltaic material due to its suitable band gap and high chemical stability. However, it is a challenge to grow high-quality CsPbI3 perovskite because the stability of perovskite phase is low and is sensitive to solvent. So far, most of CsPbI3 perovskites in high-performance perovskite solar cells (PSCs) were prepared from N,N-dimethylformamide, a highly toxic solvent, and no successful case has been reported for dimethyl sulfoxide (DMSO), which is environmentally-friendly with considerably higher complexation capability. Herein, we reveal that forming DMSO-based adduct is the main cause for limiting the quality of CsPbI3 perovskite from DMSO-based solutions, which would inhibit the formation of DMAPbI3 (DMA = dimethylammonium, (CH3)

### 58. Title: An embedded interfacial network stabilizes inorganic CsPbI3 perovskite thin films
**ID:** `p58`

Abstract: The black perovskite phase of CsPbI3 is promising for optoelectronic applications; however, it is unstable under ambient conditions, transforming within minutes into an optically inactive yellow phase, a fact that has so far prevented its widespread adoption. Here we use coarse photolithography to embed a PbI2-based interfacial microstructure into otherwise-unstable CsPbI3 perovskite thin films and devices. Films fitted with a tessellating microgrid are rendered resistant to moisture-triggered decay and exhibit enhanced long-term stability of the black phase (beyond 2.5 years in a dry environment), due to increasing the phase transition energy barrier and limiting the spread of potential yellow phase formation to structurally isolated domains of the grid. This stabilizing effect 

### 59. Title: Functional organic cation induced 3D-to-0D phase transformation and surface reconstruction of CsPbI3 inorganic perovskite
**ID:** `p59`

Abstract: Efficiency and stability are the main research focuses for perovskite solar cells. Inorganic perovskites like CsPbI3 possess higher chemical stability than those with organic A-site cations, while they also exhibit higher defect density. Nonetheless, it is highly challenging to induce orderly secondary arrangement or reconstruction of inorganic perovskites with reduced defects because of their unique chemical properties. In this work, in-situ three-dimension-to-zero-dimension (3D-to-0D) phase transformation and surface reconstruction on CsPbI3 film is achieved as induced by a functional organic cation, benzyldodecyldimethylammonium (BDA), a process of which that is similar to phase-transfer catalysis. With the help of BDABr salt treatment, 0D Cs4PbI6 perovskites are secondarily f

### 60. Title: Phase transformation barrier modulation of CsPbI3 films via PbI3− complex for efficient all-inorganic perovskite photovoltaics
**ID:** `p60`

Abstract: Cesium lead iodide (CsPbI3) has gained great attention due to its thermal stability and appropriate bandgap structure. The \\mathrm{CsPbI3} film exhibits a high level of crystallization, which is comparable to that of \\mathrm{CsPbI3_2} films with desired black phase. Herein, we fabricate kinetically favorably \\mathrm{CsPbI3_2} thin films by stoichiometry modulation, where in situ 2D GWAS measurements was innovatively performed to illustrate the phase transition. In this work, we have demonstrated that the \\mathrm{CsPbI3_2} film can be grown in a single-step process. Conceptually different from introducing other extrinsic species, the cocrystalline doping by excessive cesium iodide leads to an increase in the crystallization temperature. This phenomenon is also observed in the 

### 61. Title: Formation Mechanisms and Phase Stability of Solid-State Grown CsPbI3 Perovskites
**ID:** `p61`

Abstract: CsPbI3 inorganic perovskite is synthesized by a solvent-free, solid-state reaction, and its structural and optical properties can be deeply investigated using a multi-technique approach. X-ray Diffraction (XRD) and Raman measurements, optical absorption, steady-time and time-resolved luminescence, as well as High-Resolution Transmission Electron Microscopy (HRTEM) imaging, were exploited to understand phase evolution as a function of synthesis time length. Nanoparticles with multiple, well-defined crystalline domains of different crystalline phases were observed, usually surrounded by a thin, amorphous/out-of-axis shell. By increasing the synthesis time length, in addition to the pure α phase, which was rapidly converted into the δ phase at room temperature, a secondary phase, Cs

### 62. Title: Prospects for inorganic CsPbI3 perovskite solar cells with commercially viable lifetimes
**ID:** `p62`

Abstract: Perovskite CsPbI3 is a promising photovoltaic absorber material, thanks to its ideal bandgap for Si-tandem solar cell applications and its excellent thermochemical stability compared with hybrid organic–inorganic perovskites. However, CsPbI3 has its own stability challenges as its photoactive β- and γ-polymorphs are thermodynamically unstable at room temperature compared with the yellow non-perovskite δ-phase. Stabilizing CsPbI3 has, thus, been the subject of considerable research in recent years. While some approaches, such as alloying with halides and reducing crystalline domain size, have proven effective in improving phase stability, these benefits have, thus far, come at the expense of photovoltaic efficiency compared with the state-of-the-art CsPbI3 solar cells. In this per

### 63. Title: Optimizing Band Gap of Inorganic Halide Perovskites by Donor–Acceptor Pair Codoping
**ID:** `p63`

Abstract: Inorganic halide perovskites (IHPs) are promising candidates for applications in solar cell devices. However, the band gaps of most IHPs are too large, so that the energy conversion efficiency is limited. In this work, we proposed a donor-acceptor pair codoping scheme to reduce the band gaps Sn- and Pb-based IHPs, based on first-principles calculations. Interestingly, the donor-acceptor pair codoping in CsSnBr3 and CsPbI3 can produce band gaps of 1.2 and 1.1 eV, respectively, both of which are close to the optimal band gap for solar cell materials. The absorption coefficient of donor-acceptor pair codoped CsSnBr3 and CsPbI3 in the visible light region are large, which indicates that they are good light absorbers for applications in solar cell devices.

### 64. Title: Polymer Poly (Ethylene Oxide) Additive for High-Stability All-Inorganic CsPbI3−xBrx Perovskite Solar Cells
**ID:** `p64`

Abstract: All-inorganic CsPbI3−xBrx perovskite solar cells (PSCs) are becoming increasingly mature due to their excellent optoelectronic properties. However, because of the poor environmental stability of the perovskite material, the device is susceptibly decomposed when exposed to moisture, high temperature, and high illumination. Therefore, a critical task is to address the problem of poor long-term stability in the environment, which serves as a significant obstacle impeding the commercialization of perovskite solar cells. This article introduces the incorporation of PEO into all-inorganic CsPbI3−xBrx perovskites with an advantageous thermal stability. PEO acts as a passivating agent near the grain boundary, and its high viscosity characteristics effectively improve the film-forming pro

### 65. Title: Enhanced Phase Stability and Reduced Bandgap for CsPbI3 Perovskite through Bi3+ and Cl– Co-Doping
**ID:** `p65`

Abstract: All-inorganic perovskite CsPbI3 is emerging as a thermally more stable alternative to organic-inorganic hybrid perovskites. However, CsPbI3 perovskite suffers from poor phase stability at ambient temperature, and its bandgap is a bit too large as light-harvesting materials in both single-junction and perovskite-on-silicon tandem solar cells. In this study, we propose an electrically neutral co-doping strategy that equimolar Bi3+ (occupying the Pb site) and Cl– (occupying the interstitial site) are incorporated into CsPbI3. Unlike the individual Bi3+ or Cl– doping, the neutral co-doping can avoid stimulating the formation of the detrimental native defects. Our first-principles calculations suggest that the co-doped systems are stable at ambient temperature and possess narrower ban

### 66. Title: Phase stability investigation of CsPbI3 perovskite for solar cell application
**ID:** `p66`

Abstract: CsPbI3 perovskite is the most suitable and desired bandgap among all-inorganic perovskite for solar cell applications. However, Poor phase stability is one of the biggest barriers in the further development of CsPbI3 perovskite solar cell. The direct room temperature synthesis is challenging because at room temperature it shows undesired orthorhombic (δ-CsPbI3) structure. Here, we have reported a low-temperature approach to synthesize CsPbI3. We did X-Ray diffraction (XRD) which confirms the formation of CsPbI3 material and also, we found the presence of both cubic and yellow phases. We have studied optical properties of CsPbI3 by measuring Photoluminescence (PL) and UV-visible absorption which shows both cubic (α-CsPbI3) and orthorhombic phase contributes in absorption spectra a

### 67. Title: Anharmonicity and Disorder in the Black Phases of CsPbI3 used for Stable Inorganic Perovskite Solar Cells
**ID:** `p67`

Abstract: Hybrid perovskite materials have emerged over the past five years as absorber layers for new high-efficiency yet low-cost solar cells (PSCs) that combine the advantages of organic and inorganic semiconductors. Here, employing the linear response (DFPT) approach of Density Functional Theory (DFT) and frozen phonon calculations, we reveal strong anharmonic effects in the inorganic CsPbI3 perovskite. We also show through high resolution in-situ synchrotron XRD measurements that CsPbI3 can be undercooled below its transition temperature and temporarily maintained in its perovskite structure down to room temperature, stabilizing a metastable perovskite polytype (black γ-phase) crucial for photovoltaic applications. Among the four phases of CsPbI3, we found that this phase is the only 

### 68. Title: Perovskite-perovskite tandem photovoltaics with optimized band gaps
**ID:** `p68`

Abstract: We demonstrate four- and two-terminal perovskite-perovskite tandem solar cells with ideally matched band gaps. We develop an infrared-absorbing 1.2-electron volt band-gap perovskite, FA0.75Cs0.25Sn0.5Pb0.5I3, that can deliver 14.8% efficiency. By combining this material with a wider-band gap FA0.83Cs0.17Pb(I0.5Br0.5)3 material, we achieve monolithic two-terminal tandem efficiencies of 17.0% with >1.65-volt open-circuit voltage. We also make mechanically stacked four-terminal tandem cells and obtain 20.3% efficiency. Notably, we find that our infrared-absorbing perovskite cells exhibit excellent thermal and atmospheric stability, not previously achieved for Sn-based perovskites. This device architecture and materials set will enable all-perovskite thin-film solar cells to reach th

### 69. Title: Band-tail trapping in FAPbI3 perovskite
**ID:** `p69`

Abstract:

### 70. Title: Machine learning-driven prediction of energy and band gap in FAPbI3 perovskite using diverse structural descriptors
**ID:** `p70`

Abstract:

### 71. Title: Octahedral dynamics and local symmetry in hybrid perovskite FAPbI3 under thermal excitation
**ID:** `p71`

Abstract: Density Functional Theory (DFT) and ab initio molecular dynamics (AIMD) simulations have been employed to investigate the evolution of local motifs within the tetragonal phase of FAPbI3 under thermal excitation. Our results reveal a distinct broadening in the distribution of PbI6 octahedral volumes with increasing temperature, indicating a gradual breakdown of symmetry and emergence of diverse local environments. These octahedral volume distortions are primarily driven by the dynamic behaviour of the FA cation leading to softening of PbI6 octahedra, evident from calculated mean octahedral volume and Pb-I-Pb bond angles. The examination of electronic structure confirmed that this dynamic structural phenomenon is directly responsible for the change in fundamental band gap value, hi

### 72. Title: New Ultrawide-Band-Gap Perovskite Materials
**ID:** `p72`

Abstract: Perovskite\nmaterials offer a promising pathway for advancing future\noptoelectronic devices including light-emitting diodes (LEDs), lasers,\nand solar cells. While considerable research has focused on the visible\nlight range, yielding excellent device properties, the discovery of\nperovskite materials suitable for UV LED applications remains challenging.\nTo address this issue, theoretical calculations have been employed\nto identify potential perovskite compositions with ultrawide band\ngap properties. In this study, we were fortunate to discover new inorganic/organic\nhalide perovskite materials, such as EAPbCl&lt;sub&gt;3&lt;/sub&gt;, CsMgBr&lt;sub&gt;3&lt;/sub&gt;, CsMgCl&lt;sub&gt;3&lt;/sub&gt;, and FASrCl&lt;sub&gt;3&lt;/sub&gt;, which exhibit\nultrawide band gaps of 3.53

### 73. Title: Thermal engineering of FAPbI3 perovskite material via radiative thermal annealing and in situ XRD
**ID:** `p73`

Abstract: Lead halide perovskites have emerged as successful optoelectronic materials with high photovoltaic power conversion efficiencies and low material cost. However, substantial challenges remain in the scalability, stability and fundamental understanding of the materials. Here we present the application of radiative thermal annealing, an easily scalable processing method for synthesizing formamidinium lead iodide (FAPbI3) perovskite solar absorbers. Devices fabricated from films formed via radiative thermal annealing have equivalent efficiencies to those annealed using a conventional hotplate. By coupling results from in situ X-ray diffraction using a radiative thermal annealing system with device performances, we mapped the processing phase space of FAPbI3 and corresponding device e

### 74. Title: Small‐Band‐Gap Halide Double Perovskites
**ID:** `p74`

Abstract: Despite their compositional versatility, most halide double perovskites feature large band gaps. Herein, we describe a strategy for achieving small band gaps in this family of materials. The new double perovskites Cs2 AgTlX6 (X=Cl (1) and Br (2)) have direct band gaps of 2.0 and 0.95 eV, respectively, which are approximately 1 eV lower than those of analogous perovskites. To our knowledge, compound 2 displays the lowest band gap for any known halide perovskite. Unlike in AI BII X3 perovskites, the band-gap transition in AI2 BB'X6 double perovskites can show substantial metal-to-metal charge-transfer character. This band-edge orbital composition is used to achieve small band gaps through the selection of energetically aligned B- and B'-site metal frontier orbitals. Calculations re

### 75. Title: Recent developments in perovskite materials, fabrication techniques, band gap engineering, and the stability of perovskite solar cells
**ID:** `p75`

Abstract: Organic-inorganic hybrid metal halide perovskite solar cells (PSC) represent a novel class of optoelectronic semiconductors that have garnered significant attention from photovoltaic researchers globally. This is due to their continually improving efficiency, straightforward solution processing methods, use of lightweight and cost-effective materials, and other notable features. The advantageous properties of perovskite materials, such as superior charge transport, tunable band gap, and distinctive electronic structure, contribute to their appeal. Over the past 6 to 7 years, diverse device architectures and fabrication techniques for PSC have emerged, achieving an impressive power conversion efficiency (PCE) of 25.7%. This review article primarily focuses on recent advancements i

### 76. Title: Machine learning stability and band gap of lead-free halide double perovskite materials for perovskite solar cells
**ID:** `p76`

Abstract: Perovskite solar cells have risen since 2013, which are urgently longing for lead-free perovskite materials during the 2015-2020 period. The market for lead-free perovskite solar cells is increasing rapidly, and lead-free halide double perovskites at high speed and high precision, analyze the importance of selected features and provide directions for discovering potential lead-free perovskites. Four different machinose-learning algorithms have been proposed to achieve this goal. The Machinose-1 (M1) algorithm provides the highest predictive performance (R2:0.9935 and MAE:0.0126) for thermodynamic stability. Random forest provides the highest prediction performance (R2:0.9410 and MAE:1.492) for band gap. Key features are that it can efficiently predict the predicted energy levels 

### 77. Title: Intrinsic Phase Stability and Inherent Bandgap of Formamidinium Lead Triiodide Perovskite Single Crystals
**ID:** `p77`

Abstract: Understanding the intrinsic phase stability and inherent band gap of formamidinium lead triiodide (FAPbI3 ) perovskites is crucial to further improve the performance of perovskite solar cells (PSCs). Herein, we explored the α- to δ-phase transition and band gap of FAPbI3 single crystals grown by an inverse temperature solubility method. We found that the residual γ-butyrolactone solvents in the inner empty space of the FAPbI3 single crystal accelerate the phase transition at kinetics. By adopting 2-methoxyethanol as the solvent, over 2000 h of stable α-FAPbI3 crystals could be acquired. This proves that although FAPbI3 is regarded as unstable at thermodynamics, it could own excellent kinetic stability without any doping or additives because of the slow solid to solid phase transi

### 78. Title: High Thermal Stability Solution-Processable Narrow-Band Gap Molecular Semiconductors
**ID:** `p78`

Abstract: A series of narrow-band gap conjugated molecules with specific fluorine substitution patterns has been synthesized in order to study the effect of fluorination on bulk thermal stability. As the number of fluorine substituents on the backbone increase, one finds more thermally robust bulk structures both under inert and ambient conditions as well as an increase in phase transition temperatures in the solid state. When integrated into field-effect transistor devices, the molecule with the highest degree of fluorination shows a hole mobility of 0.15 cm(2)/V·s and a device thermal stability of >300 °C. Generally, the enhancement in thermal robustness of bulk organization and device performance correlates with the level of C-H for C-F substitution. These findings are relevant for the 

### 79. Title: Thermal stability, morphology and electronic band gap of Zn(NCN)
**ID:** `p79`

Abstract: The thermal behavior of zinc carbinidoide (Zn(NCN)) was examined in the temperature range between 200 and 1100°C at Ar atmosphere. The material starts to partially decompose at about 800°C. Heat treatment was applied to the material, which resulted in a decrease in the crystallization temperature of Zn(NCN) from 1100 to 1300 K. The carbon-like nanoshell-like bamboo-like multiwall carbon-nanotubes of 20 - 50nm in diameter due to a partial decomposition of Zn(NCN) into tin diacyl (CN2), nitrogen and zinc gas followed by the polymerization of the former product to paranyancon (CN4). At 1100°C, the yield of the residual carbodiimide depends on the dwelling time of the reaction. The amount of Zn(NCN) is determined by the amount of Zn(NCN) dissolved in water. The amount of Zn(NCN) sepa

### 80. Title: Thermal stability and decomposition kinetics of mixed-cation halide perovskites
**ID:** `p80`

Abstract: Organic-inorganic halide perovskites (OIHPs) have emerged as one of the most efficient photovoltaic materials due to their superior properties. However, improving their stability remains a key challenge. Herein, we investigate the thermal decomposition properties of OIHP FAxMA1-xPbI3 with mixed cations of formamidinium (FA) and methylammonium (MA). Using thermogravimetric analysis together with Fourier transform infrared spectroscopy, we identify and monitor the gaseous decomposition products as a function of temperature and cation composition. Thermal decomposition products of both MA and FA cations were observed at all stages of the thermal decomposition process, contrary to previous expectations. The yield, release sequence and kinetics of the organic gaseous products were fou

### 81. Title: Influence of Formamidine Formate Doping on Performance and Stability of FAPbI3-Based Perovskite Solar Cells
**ID:** `p81`

Abstract: Formamidine lead iodide (FAPbI3) perovskite material is very suitable for solar photovoltaic devices because of its ideal low band gap, theoretically high efficiency, and wide range of solar spectral absorption, coupled with its good thermal stability. A two-step spin coating method could control the crystallization process of formamidine lead iodide perovskite films better, resulting in more easily repeatable high-quality films. However, it is still difficult to avoid the formation of halide I-vacancy during the preparation of films, which will affect device performance and stability. In this paper, we added small molecular formamidine formate (FAHCOO) into the PbI2 precursor solution. Due to the high binding energy between HCOO− and I-vacancy, film defects caused by I-vacancies

### 82. Title: Ineffectiveness of formamidine in suppressing ultralow thermal conductivity in cubic hybrid perovskite FAPbI3
**ID:** `p82`

Abstract: Fundamentally understanding the lattice dynamics and microscopic mechanisms of thermal transport in cubic hybrid organic-inorganic perovskites remains elusive, primarily due to their strong anharmonicity and frequent phase transitions. In this work, we comprehensively investigate the thermal transport behavior in cubic hybrid perovskite FAPbI3, integrating first principles-based anharmonic lattice dynamics with a linearized Wigner transport formula. The Temperature Dependent Effective Potential (TDEP) technique allows us to stabilize the negative soft modes, primarily dominated by organic cations, at finite temperatures in cubic FAPbI3. We then predict an ultra-low thermal conductivity of ~0.63 Wm^(-1) K^(-1) in cubic FAPbI3 at 300 K, with a temperature dependence of T^(-0.740), 

### 83. Title: Novel design strategies for perovskite materials with improved stability and suitable band gaps
**ID:** `p83`

Abstract: The instability of organometallic halide perovskites is deemed a key hindrance hampering their commercial utilization in solar cell research. In the current work, we investigate and compare the dynamics properties of both free NH4+ and that immobilized in a NH4+-H2O-H2O-H2O-H2O-NH4+ network in a one-dimensional (1D) Pb-I skeleton. The simulations show that both the space occupancy and the hydrogen bonding formation ability of the A-site groups significantly influence the transition of the 1D NH4PbI3 perovskite materials to two-dimensional/three-dimensional (2D/3D) hybrid structures. Based on these observations, two possible pathways enhancing the structural stability of the perovskite materials are proposed. To narrow the big band gap introduced by the quantum confinement effect 

### 84. Title: Tuning\nthe Light Emission Properties by Band Gap Engineering\nin Hybrid Lead Halide Perovskite
**ID:** `p84`

Abstract: We report about the\nrelationship between the morphology and luminescence\nproperties of methylammonium lead trihalide perovskite thin films.\nBy tuning the average crystallite dimension in the film from tens\nof nanometers to a few micrometers, we are able to tune the optical\nband gap of the material along with its photoluminescence lifetime.\nWe demonstrate that larger crystallites present smaller band gap and\nlonger lifetime, which correlates to a smaller radiative bimolecular\nrecombination coefficient. We also show that they present a higher\noptical gain, becoming preferred candidates for the realization of\nCW lasing devices.

### 85. Title: Band Gap Tuning and Defect Tolerance of Atomically\nThin Two-Dimensional Organic–Inorganic Halide Perovskites
**ID:** `p85`

Abstract: Organic–inorganic\nhalide perovskites have proven highly\nsuccessful for photovoltaics but suffer from low stability, which\ndeteriorates their performance over time. Recent experiments have\ndemonstrated that low dimensional phases of the hybrid perovskites\nmay exhibit improved stability. Here we report first-principles calculations\nfor isolated monolayers of the organometallic halide perovskites (C&lt;sub&gt;4&lt;/sub&gt;H&lt;sub&gt;9&lt;/sub&gt;NH&lt;sub&gt;3&lt;/sub&gt;)&lt;sub&gt;2&lt;/sub&gt;MX&lt;sub&gt;2&lt;/sub&gt;Y&lt;sub&gt;2&lt;/sub&gt;, where M = Pb, Ge, Sn and X,Y = Cl, Br, I. The band gaps\ncomputed using the GLLB-SC functional are found to be in excellent\nagreement with experimental photoluminescence data for the already\nsynthesized perovskites. Finally, we st

### 86. Title: Crystal‐Size‐Induced Band Gap Tuning in Perovskite Films
**ID:** `p86`

Abstract: A comprehensive picture explaining the effect of the crystal size in metal halide perovskite films on their opto-electronic characteristics is currently lacking. We report that perovskite nanocrystallites exhibit a wider band gap due to concurrent quantum confinement and size dependent structural effects, with the latter being remarkably distinct and attributed to the perturbation from the surface of the nanocrystallites affecting the structure of their core. This phenomenon might assist in the photo-induced charge separation within the perovskite in devices employing mesoporous layers as they restrict the size of nanocrystallites present in them. We demonstrate that the crystal size effect is widely applicable as it is ubiquitous in different compositions and deposition methods 

### 87. Title: Influence of Composition on Material Stability of Low Band Gap Pb-Sn Perovskites
**ID:** `p87`

Abstract:

### 88. Title: Optical and Compositional Engineering of Wide Band Gap Perovskites with Improved Stability to Photoinduced Phase Segregation for Efficient Mono
**ID:** `p88`

Abstract: Metal halide perovskites are promising candidates for the wide band gap top cell in tandem solar cells. By introducing a tin oxide buffer layer via atomic layer deposition, we have improved the efficiency of monolithic, two-terminal, perovskite/silicon tandems to 23.6% by combining an infraredtuned silicon heterojunction bottom cell with the more stable cesium formamidinium lead halide perovskite. We show that further improvements to current and voltage can be made by introducing a PDMS scattering layer to reduce front surface reflection and using compositional engineering to simultaneously increase bandgap and Voc, while mitigating voltage losses arising from photo-induced halide segregation.

### 89. Title: Halogen engineering tuned band gap and structural phase transition in lead iodide hybrid perovskite semiconductors
**ID:** `p89`

Abstract: Organic-inorganic hybrid materials possess unique advantages, including structural adjustability and tunable functional properties, making them promising candidates for applications in sensors, intelligent switches, and optoelectronic devices. In this study, we...

### 90. Title: Band gap tuning of perovskite solar cells for enhancing the efficiency and stability: issues and prospects
**ID:** `p90`

Abstract: The intriguing optoelectronic properties, diverse applications, and facile fabrication techniques of perovskite materials have garnered substantial research interest worldwide. Their outstanding performance in solar cell applications and excellent efficiency at the lab scale have already been proven. However, owing to their low stability, the widespread manufacturing of perovskite solar cells (PSCs) for commercialization is still far off. Several instability factors of PSCs, including the intrinsic and extrinsic instability of perovskite materials, have already been identified, and a variety of approaches have been adopted to improve the material quality, stability, and efficiency of PSCs. In this review, we have comprehensively presented the significance of band gap tuning in ac

### 91. Title: A Review on Energy Band‐Gap Engineering for Perovskite Photovoltaics
**ID:** `p91`

Abstract: Metal halide perovskites are attractive for highly efficient solar cells. As most perovskites suffer large or indirect bandgap compared with the ideal bandgap range for single‐junction solar cells, bandgap engineering has received tremendous attention in terms of tailoring perovskite band structure, which plays a key role in light harvesting and conversion. In this Review, various reported bandgap engineering strategies are summarized. The recently widely used two main strategies including impurity and pressure as well as their underlying mechanisms are reviewed comprehensively. In addition, intermediate band and external electric field for bandgap engineering are also investigated. Moreover, future research directions are outlined to guide the further investigation.

### 92. Title: Composition‐Tuned Wide Bandgap Perovskites: From Grain Engineering to Stability and Performance Improvement
**ID:** `p92`

Abstract: Wide bandgap (WB) organic–inorganic hybrid perovskites (OIHPs) with a bandgap ranging between 1.7 and 2.0 eV have shown great potential to improve the efficiency of single‐junction silicon or thin‐film solar cells by forming a tandem structure with one of these cells or with a narrow bandgap perovskite cell. However, WB‐OIHPs suffer from a large open‐circuit voltage (Voc) deficit in photovoltaic devices, which is associated with the phase segregation of the materials under light illumination. In this work the photoinstability is demonstrated and Voc loss can be addressed by combining grain crystallization and grain boundary passivation, achieved simultaneously through tuning of perovskite precursor composition. Using FA0.17Cs0.83PbI3–xBrx (x = 0.8, 1.2 1.5, and 1.8), with a varie

### 93. Title: Advances in lead-free double perovskite nanocrystals, engineering band-gaps and enhancing stability through composition tunability
**ID:** `p93`

Abstract: In this topical review, we have focused on the recent advances made in the studies of lead-free perovskites in the bulk form and as nanocrystals. Substitution of lead in halide perovskites is essential to overcome the toxicity concerns and improve the relatively low stability of these materials. In lead-free double perovskites the unit cell is doubled and two divalent lead cations are replaced by mono and trivalent cations. The current main challenge with the double perovskite metal halides lies in overcoming their inherently indirect and disallowed optical transitions. In this review, we have discussed the recent discoveries made in the synthesis of these materials and highlighted how nanocrystals can serve as model systems to explore the schemes of cationic exchange, doping and

### 94. Title: Band gap engineering and photoluminescence tuning in halide double perovskites
**ID:** `p94`

Abstract: Halide double perovskites (HDPs) present a convenient alternative to the unstable and toxic lead halide perovskites for various optoelectronic applications. Because of their compositional and structural tunability, many HDP phases have been synthesized in the past decades. While efficient photovoltaic applications remain largely out of reach for the HDP phases due to their wide band gaps and structures with pseudoisolated metal centers, their electronic structures favor light conversion applications. Since the field of HDP witnesses rapid growth and development, this article is aimed at providing a brief snapshot of the recent advances on all-inorganic HDPs, primarily focusing on the relationship between their compositions and optical properties, and some aspects of their applica

### 95. Title: Compositional engineering of tin-lead halide perovskites for efficient and stable low band gap solar cells
**ID:** `p95`

Abstract: Tin-lead halide perovskites show promise as low- band gap absorbers to enable efficient all-perovskite tandem solar cells. While they have reached high efficiencies in single junction and in tandem solar cells, tin-containing perovskites face unique challenges- such as a tendency to degrade by oxidation of tin and sometimes very short carrier lifetimes that limit diffusion lengths. We map oxidation stability and important optoelectronic properties- band gap, carrier lifetime, and solar cell performance - across a wide range of compositions varying the A-site cation and the tin:lead ratio at the B-site. We identify mechanisms by which composition tunes the band gap in ways distinct from what has been reported for pure lead-based perovskites. We show that alloying tin with lead cha

### 96. Title: Band Gap Engineering Based on X-Site Ion Tuning in Copper Organic–Inorganic Hybrid Perovskite
**ID:** `p96`

Abstract: This paper reports two copper-based organic–inorganic hybrid perovskite single crystals, (2A5MP) 2 CuX 4 ( X = Cl, Br), synthesized by a halogen-regulated method. Through comprehensive characterization (single-crystal XRD, powder XRD, FTIR, Raman spectroscopy, TGA, and UV–vis DRS), we elucidated crystal structures, intermolecular forces, functional groups, bond configurations, optical properties, and thermal stability. Both compounds crystallized in the monoclinic space group C2/c . (2A5MP) 2 CuCl 4 has an optical band gap of 2.47 eV and is stable up to 172 °C, while (2A5MP) 2 CuBr 4 has a band gap of 1.66 eV with a stability of up to 185 °C. When Br – occupies the X site, (2A5MP) 2 CuBr 4 exhibits an optical band gap (1.66 eV) close to the optimal value for solar cell absorbers.
