# 反思日志（2026-08-02 第二轮，最终）

## 水效应二象性元分析（假设 6 验证）
- 11 个体系：物理吸附平均湿/干比 0.87（负效应），化学胺体系 1.25（正效应），**符号翻转显著**。
- **关键机制修正**：判别变量是【化学胺位点存在与否】而非 Qst——MIL-120（Qst=44 物理）负、TYUT-ATZ-β（Qst=44 水固定）正。负效应强度与 OMS 密度/亲水性相关。
- 这比原假设 6 的表述（以 Qst 或胺负载为轴）更精确：**应以化学位点密度为轴**。

## 两项元分析汇总（本轮增量贡献）
1. **孔径-压力窗口（假设 4）**：r=0.690 定性支持 d* 随压力降低减小；定量需 CRAFTED 数据库。
2. **水效应二象性（假设 6）**：物理 0.87 vs 化学 1.25 符号翻转；机制修正为化学位点判别。

## 最终交付物清单
- survey_report.md（180 篇 v2.0）+ knowledge_graph.md v2.0（40/87/14）+ gap_report.md v2.0（10 Gap）
- discovery/discovery_report.md（8 假设全 literature_supported + 2 项元分析）+ scientific_explanation.md
- paper_summaries.md（180 篇重建）+ 记忆文件（survey-0802b + MEMORY.md + reflection）
- 代码：workspace/code/survey/（convert/merge/extract/rebuild/run_discovery_all/run_validate_lit/gen_discovery_report/meta_*）

## 下一轮迭代建议
1. CRAFTED 数据库回归 d* = f(log10P)（假设 4 定量化）
2. 按化学位点密度轴拟合水效应符号翻转临界线（假设 6 定量化）
3. 补充 TSA/VSA 循环级文献强化假设 7（vals=11 最少）
4. 缺陷类型标注化数据库（区分甲酸/配体缺失缺陷）
