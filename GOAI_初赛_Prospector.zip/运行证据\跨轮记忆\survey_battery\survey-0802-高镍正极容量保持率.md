# 调研记忆：锂离子电池高镍正极容量保持率

> 日期：2026-08-02 | 状态：阶段一完成 + 阶段二初步完成

## 检索策略
- 检索词：high-nickel cathode capacity retention；NMC811 capacity fading mechanism；single crystal Ni-rich cycling stability；doping LiNiO2；microcrack；high voltage electrolyte；Zr/W/Ti doping；Co-free；concentration gradient；coating review
- 数据源：sciverse（174 篇唯一论文，18 轮检索，捕获效率 96%）
- 检索日志：workspace/data/literature_cache/search_results.json → papers.json（174 篇，含摘要）

## 知识图谱摘要（workspace/outputs/literature_survey/knowledge_graph.md）
- 材料数：17（NMC/NCA/LNO/Co-free/单晶/浓度梯度）
- 性质数：17（保持率/初始容量/循环圈数/电压/H2-H3/微裂纹/阳离子混排/氧损失/TM溶解/CEI/热稳定性）
- 关键关系数：9（R1-R9）
- 审计：0 冲突，0 重复，0 溯源缺失

## Top 研究空白
1. **单晶 vs 多晶保持率矛盾**（高，conf 0.55）——p1/p2（SC 更差）vs p62/p67/p121（SC 更优）；验证：粒径×电压×倍率对比矩阵
2. **Co 含量由益转害的电压阈值**（高，conf 0.60）——p4/p20（Co 高电位有害）vs p71/p158（Co 稳定结构）；验证：Co 0-10%×4.2-4.6V 矩阵
3. **掺杂元素描述符→保持率定量构效关系**（高，conf 0.75）——多元素数据无统一模型；验证：描述符回归/ML
4. Ni 含量-保持率量化标度（中，conf 0.65）
5. 单晶粒径非单调影响（中，conf 0.50）

## 发现结果（路线 A）
1. hyp[0] 单晶/多晶翻转条件 — literature_supported — novelty 0.47(partial)
2. hyp[1] Co 阈值 — literature_supported — novelty 0.72(new)
3. hyp[2] 掺杂描述符构效关系 — literature_supported — novelty 0.90(new)，贝叶斯搜索 best score 0.310，LLM 引导 2 次
4. hyp[3] Ni 含量标度 — literature_supported — novelty 0.70(new)；模型对比样本不足（<5）
5. hyp[4] 单晶粒径非单调 — literature_supported — novelty 0.85(new)
- 验证记录：workspace/outputs/literature_survey/discovery/hypotheses.json（全部 literature_supported，MP hits: 5）
- 发现报告：workspace/outputs/literature_survey/discovery/discovery_report.md

## 反思
- **最令人惊讶的发现**：单晶正极在相同 Ni 含量下循环稳定性可劣于多晶（p1/p2）——"消除微裂纹"不等于"高保持率"，Li 浓度空间不均成为新的衰减主导因素；这解释了为何业界单晶路线存在争议
- **最高效搜索方向**：以"机理关键词（microcrack/phase transition/oxygen loss）× 改性策略（doping/coating/electrolyte）"组合检索，命中率高
- **关键数值锚点**：LiNbO3 包覆 19%→70%（p5）；Al1% NMC76 79.2%@500cyc/4.5V（p41）；HCBE 电解液 ~95%@150cyc（p32）
- **下一轮迭代聚焦**：① 扩充知识图谱数值样本（get_full_text 提取精确容量-循环数据）以支持 run_model_comparison；② 针对 hyp[1] Co 阈值做专门检索（Co doping 梯度实验数据）；③ 对 hyp[2] 用 MCTS 扩大搜索空间（掺杂元素库）
