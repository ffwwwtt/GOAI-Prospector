# Agent 调研记忆 — 卤化物钙钛矿带隙稳定性
- [halide perovskite solar cells band gap stability](survey-0807-perovskite-bandgap.md) — 96 篇论文；核心发现：光致卤化物分离阈值 0.03–0.2 mW/cm²、CsPbI₃ NC<5.6nm 稳定 α 相、A 位 Cs vs X 位 Br 权衡矛盾；Top Gap：Cs/Br 权衡矛盾（p53 vs p26）；发现：hyp[0]/hyp[2] 已搜索验证（literature_supported / inconclusive），hyp[4] 为 new
