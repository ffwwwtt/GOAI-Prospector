# Literature Survey — Paper Summaries

**Total papers:** 140
**Generated:** 2026-08-02T13:31:59.342917

---

**Sources:** sciverse(96), arxiv(44)
**Common keywords:** thermoelectric, sub, thermal, conductivity, title, source, abstract, performance, lattice, temperature, sciverse, merit, phonon, transport, figure

---

### 1. Title: Beyond Predicted ZT: Machine Learning Strategies for the Experimental Discovery of Thermoelectric Materials
**DOI:** 10.48550/arxiv.2601.06571
**ID:** `p1`

Source: sciverse Abstract: The discovery of high-performance thermoelectric (TE) materials for advancing green energy harvesting from waste heat is an urgent need in the context of looming energy crisis and climate change. The rapid advancement of machine learning (ML) has accelerated the design of thermoelectric (TE) materials, yet a persistent "gap" remains between high-accuracy computational predictions and their successful experimental validation. While ML models frequently report impressive test scores (R^2 values of 0.90-0.98) for complex TE properties (zT, power factor, and electrical/thermal conductivity), only a handful of these predictions have culminated in the experimental discovery of new high-zT materials. In this review, we identify and discuss that the primary obstacles are

### 2. Title: Giant ZT enhancement in rhombohedral GeTe-based thermoelectric materials
**DOI:** 10.1038/s41467-026-70793-6
**ID:** `p2`

Source: sciverse Abstract: The peak figure of merit (ZT) of GeTe-based thermoelectric (TE) materials is typically attained in the high-temperature cubic phase, where the inevitable phase transition raises concerns over interfacial instability during operation. Therefore, developing high-performance rhombohedral GeTe below the phase transition temperature represents a more viable path toward practical applications. Herein, we propose a facile nanocomposite strategy to enhance the TE performance of rhombohedral GeTe by incorporating high-modulus TiB2 nanoparticles into Ge0.94Bi0.05Te matrix. We demonstrate that the nanoparticle-induced interfacial constraint effect contributes to increasing longitudinal elastic modulus and decreasing equivalent deformation potential, accounting for improved 

### 3. Title: [6/6] Introduction to Thermoelectricity: Approaches for improving zT of thermoelectric materials
**DOI:** 10.13140/rg.2.2.28940.59522
**ID:** `p3`

Source: sciverse

### 4. Title: Optimization direction and selection strategy for thin film thermoelectric cooler materials
**DOI:** 10.1016/j.csite.2026.107692
**ID:** `p4`

Source: sciverse Abstract: While thin-film thermoelectric coolers (TECs) are promising for chip thermal management, their material optimization strategy remains controversial. Conventional approaches focus on improving the material's figure of merit (ZT) by enhancing the power factor or reducing thermal conductivity, yet their relative effectiveness is unclear. Moreover, materials with identical ZT values can exhibit significantly different performance in practical devices, making selection criteria ambiguous. This study establishes a simulation model for thin-film TECs that incorporates contact and size effects, achieving a computational error of 3.33%. Through sensitivity analysis, we demonstrate that the optimal priority of thermophysical parameters (Seebeck coefficient, electrical resi

### 5. Title: Enhancing zT in Organic Thermoelectric Materials through Nanoscale Local Control Crystallization
**DOI:** 10.1021/acsnano.4c10801
**ID:** `p5`

Source: sciverse Abstract: Organic thermoelectric materials are promising for wearable heating and cooling devices, as well as near-room-temperature energy generation, due to their nontoxicity, abundance, low cost, and flexibility. However, their primary challenge preventing widespread use is their reduced figure of merit (zT) caused by low electrical conductivity. This study presents a method to enhance the thermoelectric performance of solution-processable organic materials through confined crystallization using the lithographically controlled wetting (LCW) technique. Using PEDOT as a benchmark, we demonstrate that controlled crystallization at the nanoscale improves electrical conductivity by optimizing chain packing and grain morphology. Structural characterizations reveal the formatio

### 6. Title: Review of current high-ZT thermoelectric materials
**DOI:** 10.1007/s10853-020-04949-0
**ID:** `p6`

Source: sciverse Abstract: Thermoelectric materials are capable of converting heat and electricity to each other. Thermoelectric devices can be miniaturized and highly integrated with existing semiconductor chip systems with microgenerators or microrefrigerators. After years of research and accumulation, BiTe series, SnSe series, CuSe series, half-Heusler series, multicomponent oxides series, organic–inorganic composites series, and GeTe/PbTe series have been found to have excellent thermoelectric properties. According to theoretical calculation, when the diameter of Bi2Te3 nanowires is 5 Å, the ZT value reaches 14, and graphdiyne has a ZT value of 4.8 at 300 K. Experimental measurements revealed that the ZT value of n-type SnSe reached 2.8. This review would focus on the updated experimen

### 7. Title: Machine Learning-Assisted 3D Printing of Thermoelectric Materials of Ultrahigh Performances at Room Temperature
**Authors:** Kaidong Song, Guoyue Xu, A. N. M. Tanvir, Ke Wang, Md Omarsany Bappy, Haijian Yang, Wenjie Shang, Le Zhou, Alexander Dowling, Tengei Luo, Yanliang Zhang
**Year:** 2024
**ID:** `p7`

Source: arxiv Abstract: Thermoelectric energy conversion is an attractive technology for generating electricity from waste heat and using electricity for solid-state cooling. However, conventional manufacturing processes for thermoelectric devices are costly and limited to simple device geometries. This work reports an extrusion printing method to fabricate high-performance thermoelectric materials with complex 3D architectures. By integrating high-throughput experimentation and Bayesian optimization (BO), our approach significantly accelerates the simultaneous search for the optimal ink formulation and printing parameters that deliver high thermoelectric performances while maintaining desired shape fidelity. A Gaussian process regression (GPR)-based machine learning model is employed to e

### 8. Title: Bidirectional Optimization onto Thermoelectric Performance via Hydrostatic-Pressure in Chalcopyrite AgXTe2 (X=In, Ga)
**Authors:** Siqi Guo, Jincheng Yue, Jiongzhi Zheng, Hui Zhang, Ning Wang, Junda Li, Yanhui Liu, Tian Cui
**Year:** 2024
**DOI:** 10.1103/PhysRevB.111.184312
**ID:** `p8`

Source: arxiv Abstract: Pressure tuning has emerged as a powerful strategy for manipulating the thermoelectric properties of materials by inducing structural and electronic modifications. Herein, we systematically investigate the transport properties and thermoelectric performance concerning lattice distortions induced by hydrostatic pressure in Ag-based chalcopyrite AgXTe2 (X=In, Ga). The findings reveal that the lattice distortion in AgXTe2 exhibits distinct behaviors under lattice compression, diverging from trends observed at ambient pressure. Importantly, the hydrostatic pressure breaks the phenomenally negative correlation between thermal conductivity and lattice distortion. Pressure-induced softening of low-frequency acoustic phonons broadens the low-energy phonon spectrum, enhancin

### 9. Title: Effect of crystal field engineering and Fermi level optimization on thermoelectric properties of Ge$_{1.01}$Te: Experimental investigation and 
**Authors:** Ashutosh Kumar, Preeti Bhumla, D. Sivaprahasam, Saswata Bhattacharya, Nita Dragoe
**Year:** 2023
**ID:** `p9`

Source: arxiv Abstract: This study shows a method of enhancing the thermoelectric properties of GeTe-based materials by Ti and Bi co-doping on cation sites along with self-doping with Ge via simultaneous optimization of electronic (via crystal field engineering, and precise Fermi level optimization) and thermal (via point-defect scattering) transport properties. The pristine GeTe possesses high carrier concentration ($n$) due to intrinsic Ge vacancies, low Seebeck coefficient ($α$), and high thermal conductivity ($κ$). The Ge vacancy optimization and crystal field engineering results in an enhanced $α$ via excess Ge and Ti doping, which is further improved by band structure engineering through Bi doping. As a result of improved $α$ and optimized Fermi level (carrier concentration), an enha

### 10. Title: Thermoelectric films and periodic structures and spin Seebeck effect systems: Facets of performance optimization
**Authors:** Nagaraj Nandihalli
**Year:** 2021
**ID:** `p10`

Source: arxiv Abstract: The growing market for sensors, internet of things, and wearable devices is fueling the development of low-cost energy-harvesting materials and systems. Film based thermoelectric (TE) devices offer the ability to address the energy requirements by using ubiquitously available waste-heat. This review narrates recent advancements in fabricating high-performance TE films and superlattice structures, from the aspects of microstructure control, doping, defects, composition, surface roughness, substrate effect, interface control, nanocompositing, and crystal preferred orientation realized by regulating various deposition parameters and subsequent heat treatment. The review begins with a brief account of heat conduction mechanism, quantum confinement effect in periodic lay

### 11. Title: Cost-Performance Trade-off in Thermoelectric Air Conditioning System with Graded and Constant Material Properties
**Authors:** Abhishek Saini, Sarah J. Watzman, Je-Hyeong Bahk
**Year:** 2020
**ID:** `p11`

Source: arxiv Abstract: Thermoelectric (TE) air cooling is a solid-state technology that has the potential to replace conventional vapor compression-based air conditioning. In this paper, we present a detailed system-level modeling for thermoelectric air conditioning system with position-dependent (graded) and constant material properties. Strategies for design optimization of the system are provided in terms of cost-performance trade-off. Realistic convection heat transfer at both sides of the system are taken into account in our modeling. Effects of convection heat transfer coefficients, air flowrate, and thermoelectric material properties are investigated with varying key parameters such as TE leg thickness, module fill factor, and input current. Both constant material properties and gr

### 12. Title: Weyl and Dirac Semimetals for Thermoelectric Applications
**Authors:** Saurabh Singh, Sarmistha Das, Shiv Kumar
**Year:** 2025
**ID:** `p12`

Source: arxiv Abstract: Weyl and Dirac semimetals, characterized by their unique band structures with linear energy dispersion (E vs k) near the Fermi level (EF), have emerged as promising candidates for next-generation technology based on thermoelectric materials. Their exceptional electronic properties, notably high carrier mobility and substantial Berry curvature, offer the potential to surmount the limitations inherent in conventional thermoelectric materials. A comprehensive understanding of the fundamental physics underlying these materials is essential. This chapter mainly focused into the topological properties and distinctive electronic band structures of Weyl and Dirac semimetals, providing a theoretical framework for comprehending their thermoelectric transport properties such a

### 13. Title: Mitigating the Effect of Nanoscale Porosity on Thermoelectric Power Factor of Si
**Authors:** S. Aria Hosseini, Giuseppe Romano, P. Alex Greaney
**Year:** 2020
**DOI:** 10.1021/acsaem.0c02640
**ID:** `p13`

Source: arxiv Abstract: The addition of porosity to thermoelectric materials can significantly increase the figure of merit, ZT, by reducing the thermal conductivity. Unfortunately, porosity is also detrimental to the thermoelectric power factor in the numerator of the figure of merit ZT. In this manuscript we derive strategies to recoup electrical performance in nanoporous Si by fine tuning the carrier concentration and through judicious design of the pore size and shape so as to provide energy selective electron filtering. In this study, we considered phosphorus doped silicon containing discrete pores that are either spheres, cylinders, cubes, or triangular prisms. The effects from these pores are compared with those from extended pores with circular, square and triangular cross sectiona

### 14. Title: The Limits of Thermoelectric Performance with a Bounded Transport Distribution
**Authors:** Jesse Maassen
**Year:** 2022
**DOI:** 10.1103/PhysRevB.104.184301
**ID:** `p14`

Source: arxiv Abstract: With the goal of maximizing the thermoelectric (TE) figure of merit $ZT$, Mahan and Sofo [Proc. Natl. Acad. Sci. U.S.A. 93, 7436 (1996)] found that the optimal transport distribution (TD) is a delta function. Materials, however, have TDs that appear to always be finite and non-diverging. Motivated by this observation, this study focuses on deriving what is the optimal bounded TD, which is determined to be a boxcar function for $ZT$ and a Heaviside function for power factor. From these optimal TDs upper limits on $ZT$ and power factor are obtained; the maximum $ZT$ scales with $Σ_{\rm max} T /κ_l$, where $Σ_{\rm max}$ is the TD magnitude and $κ_l$ is the lattice thermal conductivity. These results help establish practical upper limits on the performance of TE materia

### 15. Title: Thermoelectric transport trends in group 4 half-Heusler alloys
**Authors:** Kristian Berland, Nina Shulumba, Olle Hellman, Clas Persson, Ole Martin Løvvik
**Year:** 2019
**DOI:** 10.1063/1.5117288
**ID:** `p15`

Source: arxiv Abstract: The thermoelectric properties of 54 different group 4 half-Heusler (HH) alloys have been studied from first principles. Electronic transport was studied with density functional theory using hybrid functionals facilitated by the $\mathbf{k} \cdot \mathbf{p}$ method, while the temperature dependent effective potential method was used for the phonon contributions to the figure of merit $ZT$. The phonon thermal conductivity was calculated including anharmonic phonon-phonon, isotope, alloy and grain-boundary scattering. HH alloys have an ${\it XYZ}$ composition and those studied here are in the group 4-9-15 (Ti,Zr,Hf)(Co,Rh,Ir)(As,Sb,Bi) and group 4-10-14 (Ti,Zr,Hf)(Ni,Pd,Pt)(Ge,Sn,Pb). The electronic part of the thermal conductivity was found to significantly impact $ZT

### 16. Title: Enhanced Thermoelectric Performance of Polycrystalline Si0.8Ge0.2 Alloys through the Addition of Nanoscale Porosity
**Authors:** Hosseini, S. Aria,  Romano,  Giuseppe,  Greaney, P. Alex
**Year:** 2021
**DOI:** 10.3390/nano11102591
**ID:** `p16`

Source: arxiv Abstract: Engineering materials to include nanoscale porosity or other nanoscale structures has become a well-established strategy for enhancing the thermoelectric performance of dielectrics. However, the approach is only considered beneficial for materials where the intrinsic phonon mean-free path is much longer than that of the charge carriers. As such, the approach would not be expected to provide significant performance gains in polycrystalline semiconducting alloys, such as SixGe1-x, where mass disorder and grains provide strong phonon scattering. In this manuscript, we demonstrate that the addition of nanoscale porosity to even ultrafine-grained Si0.8Ge0.2 may be worthwhile. The semiclassical Boltzmann transport equation was used to model electrical and phonon transport

### 17. Title: Thermoelectric phonon glass electron crystal via ion beam patterning of silicon
**Authors:** Taishan Zhu, Krishnan Swaminathan-Gopalan, Kelly Stephani, Elif Ertekin
**Year:** 2017
**DOI:** 10.1103/PhysRevB.97.174201
**ID:** `p17`

Source: arxiv Abstract: Ion beam irradiation has recently emerged as a versatile approach to functional materials design. We show in this work that patterned defective regions generated by ion beam irradiation of silicon can create a phonon glass electron crystal (PGEC), a longstanding goal of thermoelectrics. By controlling the effective diameter of and spacing between the defective regions, molecular dynamics simulations suggest a reduction of the thermal conductivity by a factor of $\approx$20 is achievable. Boltzmann theory shows that the thermoelectric power factor remains largely intact in the damaged material. To facilitate the Boltzmann theory, we derive an analytical model for electron scattering with cylindrical defective regions based on partial wave analysis. Together we predic

### 18. Title: Thermoelectric properties of Sm-doped BiCuSeO oxyselenides fabricated by two-step reactive sintering
**Authors:** Andrei Novitskii, Illia Serhiienko, Sergey Novikov, Kirill Kuskov, Daria Pankratova, Tatyana Sviridova, Andrei Voronin, Aleksei Bogach, Elena Skryleva, Yuriy Parkhomenko, Alexander Burkov, Takao Mori,
**Year:** 2021
**DOI:** 10.1016/j.jallcom.2022.165208
**ID:** `p18`

Source: arxiv Abstract: Among layered oxygen-containing compounds, BiCuSeO is one of the most promising candidates for thermoelectric applications due to its intrinsically low thermal conductivity and good thermal stability. However, the rather poor electrical conductivity of pristine BiCuSeO hinders its potential. Further enhancement of the thermoelectric performance by single doping at Bi site is limited mainly due to dramatic decrease of carrier mobility. Thus, new strategies, such as dual doping or doping with variable-valence elements seem to be promising. Along with that, the development of a fast and scalable synthesis route is essential for the industrial-scale fabrication of thermoelectric materials. Hence, in this paper, Bi$_{1-x}$Sm$_{x}$CuSeO samples (0 $\leq$ $x$ $\leq$ 0.08) 

### 19. Title: Lattice-to-Total Thermal Conductivity Ratio: A Phonon-Glass Electron-Crystal Descriptor for Data-Driven Thermoelectric Design
**Authors:** Yifan Sun, Zhi Li, Tetsuya Imamura, Yuji Ohishi, Chris Wolverton, Ken Kurosaki
**Year:** 2025
**ID:** `p19`

Source: arxiv Abstract: Thermoelectrics (TEs) are promising candidates for energy harvesting with performance quantified by figure of merit, $ZT$. To accelerate the discovery of high-$ZT$ materials, efforts have focused on identifying compounds with low thermal conductivity $κ$. Using a curated dataset of 71,913 entries, we show that high-$ZT$ materials reside not only in the low-$κ$ regime but also cluster near a lattice-to-total thermal conductivity ratio ($κ_\mathrm{L}/κ$) of approximately 0.5. This optimal ratio provides a quantitative descriptor for the well-known phonon-glass electron-crystal (PGEC) design concept. Building on this insight, we construct a framework consisting of two machine learning models for the lattice and electronic components of thermal conductivity that jointly

### 20. Title: Origins of minimized lattice thermal conductivity and enhanced thermoelectric performance in WS2/WSe2 lateral superlattice
**Authors:** Yonglan Hu, Tie Yang, Dengfeng Li, Guangqian Ding, Chaochao Dun, Dandan Wu, Xiaotian Wang
**Year:** 2021
**DOI:** 10.1021/acsomega.1c00457
**ID:** `p20`

Source: arxiv Abstract: We report a configuration strategy for improving the thermoelectric (TE) performance of two-dimensional (2D) transition metal dichalcogenide (TMDC) WS2 based on the experimentally prepared WS2/WSe2 lateral superlattice (LS) crystal. On the basis of density function theory combined with Boltzmann transport equation, we show that the TE figure of merit zT of monolayer WS2 is remarkably enhanced when forming into a WS2/WSe2 LS crystal. This is primarily ascribed to the almost halved lattice thermal conductivity due to the enhanced anharmonic processes. Electronic transport properties parallel (xx) and perpendicular (yy) to the superlattice period are highly symmetric for both p- and n-doped LS owing to the nearly isotropic lifetime of charger carriers. The spin-orbital

### 21. Title: Lattice Dislocations Enhancing Thermoelectric PbTe in Addition to Band Convergence
**DOI:** 10.1002/adma.201606768
**ID:** `p21`

Source: sciverse Abstract: Phonon scattering by nanostructures and point defects has become the primary strategy for minimizing the lattice thermal conductivity (κL ) in thermoelectric materials. However, these scatterers are only effective at the extremes of the phonon spectrum. Recently, it has been demonstrated that dislocations are effective at scattering the remaining mid-frequency phonons as well. In this work, by varying the concentration of Na in Pb0.97 Eu0.03 Te, it has been determined that the dominant microstructural features are point defects, lattice dislocations, and nanostructure interfaces. This study reveals that dense lattice dislocations (≈4 × 1012 cm-2 ) are particularly effective at reducing κL . When the dislocation concentration is maximized, one of the lowest κL val

### 22. Title: Temperature\nInduced Band Convergence, Intervalley\nScattering, and Thermoelectric Transport in p‑Type PbTe
**DOI:** 10.1021/acsaem.2c00800.s001
**ID:** `p22`

Source: sciverse Abstract: Achieving\nhigh valley degeneracy (i.e., “band convergence”)\nin a material usually results in considerably enhanced thermoelectric\nproperties. However, it is still unclear why this strategy of designing\nefficient thermoelectric materials is so successful, because the benefit\nof increased density of states may be severely degraded by intervalley\nscattering. Using first-principles calculations, we investigate these\neffects in p-type PbTe, where temperature induces alignment of the\nL and Σ valleys at ∼620 K. We explicitly show that the\nthermoelectric power factor and figure of merit peak near the band\nconvergence temperature. The figure of merit maximum is larger than\nthose of the individual L and Σ valleys. Surprisingly, intervalley\nscattering does not c

### 23. Title: Na Doping\nin PbTe: Solubility, Band Convergence, Phase\nBoundary Mapping, and Thermoelectric Properties
**DOI:** 10.1021/jacs.0c07067.s001
**ID:** `p23`

Source: sciverse Abstract: Many\nmonumental breakthroughs in &lt;i&gt;p&lt;/i&gt;-type PbTe thermoelectrics\nare driven by optimizing a Pb&lt;sub&gt;0.98&lt;/sub&gt;Na&lt;sub&gt;0.02&lt;/sub&gt;Te matrix.\nHowever, recent works found that &lt;i&gt;x&lt;/i&gt; &gt; 0.02 in Pb&lt;sub&gt;1–&lt;i&gt;x&lt;/i&gt;&lt;/sub&gt;Na&lt;sub&gt;&lt;i&gt;x&lt;/i&gt;&lt;/sub&gt;Te\nfurther improves the thermoelectric figure of merit, &lt;i&gt;zT&lt;/i&gt;, despite being above the expected Na solubility limit. We explain\nthe origins of improved performance from excess Na doping through\ncomputation and experiments on Pb&lt;sub&gt;1–&lt;i&gt;x&lt;/i&gt;&lt;/sub&gt;Na&lt;sub&gt;&lt;i&gt;x&lt;/i&gt;&lt;/sub&gt;Te with 0.01 ≤ &lt;i&gt;x&lt;/i&gt; ≤ 0.04. High temperature X-ray diffraction and Hall carrier\nco

### 24. Title: Synergistic Sn-Induced Band Convergence in Mn-Doped p-Type PbTe Enables High Thermoelectric Performance
**DOI:** 10.3390/ma19101947
**ID:** `p24`

Source: sciverse Abstract: The inherent coupling of electrical and thermal transport parameters poses a significant challenge for enhancing the thermoelectric figure of merit (zT) in PbTe-based materials. Herein, we report a synergistic co-doping strategy employing Mn and Sn in p-type PbTe to simultaneously optimize the band structure and suppress lattice thermal conductivity. Sn incorporation not only induces additional Pb vacancies, thereby increasing hole carrier concentration, but also facilitates the enhanced solubility of Na dopants within the matrix, as confirmed by microscopic and compositional analyses. More importantly, the cooperative effect of Mn and Sn substantially enhances convergence between the L and Σ valence bands, leading to an increased density-of-states effective mass

### 25. Title: Reduced Dimensionality and Thermoelectric Power Factor of PbTe Ballistic Nanostructures
**DOI:** 10.1063/1.3671717
**ID:** `p25`

Source: sciverse Abstract: Views Icon Views Article contents Figures & tables Video Audio Supplementary Data Peer Review Share Icon Share Twitter Facebook Reddit LinkedIn Tools Icon Tools Reprints and Permissions Cite Icon Cite Search Site Citation Vânia Aparecida da Costa, Erasmo A. de Andrada e Silva; Reduced Dimensionality and Thermoelectric Power Factor of PbTe Ballistic Nanostructures. AIP Conference Proceedings 26 December 2011; 1416 (1): 139–141. https://doi.org/10.1063/1.3671717 Download citation file: Ris (Zotero) Reference Manager EasyBib Bookends Mendeley Papers EndNote RefWorks BibTex toolbar search Search Dropdown Menu toolbar search search input Search input auto suggest filter your search All ContentAIP Publishing PortfolioAIP Conference Proceedings Search Advanced Search |C

### 26. Title: Promoting SnTe as an Eco‐Friendly Solution for p‐PbTe Thermoelectric via Band Convergence and Interstitial Defects
**DOI:** 10.1002/adma.201605887
**ID:** `p26`

Source: sciverse Abstract: Compared to commercially available p-type PbTe thermoelectrics, SnTe has a much bigger band offset between its two valence bands and a much higher lattice thermal conductivity, both of which limit its peak thermoelectric figure of merit, zT of only 0.4. Converging its valence bands or introducing resonant states is found to enhance the electronic properties, while nanostructuring or more recently introducing interstitial defects is found to reduce the lattice thermal conductivity. Even with an integration of some of the strategies above, existing efforts do not enable a peak zT exceeding 1.4 and usually involve Cd or Hg. In this work, a combination of band convergence and interstitial defects, each of which enables a ≈150% increase in the peak zT, successfully ac

### 27. Title: Limit of zT enhancement in rock-salt structured chalcogenides by band convergence?
**Authors:** Min Hong, Zhi-Gang Chen, Yanzhong Pei, Lei Yang, Jin Zou
**Year:** 2016
**DOI:** 10.1103/PhysRevB.94.161201
**ID:** `p27`

Source: arxiv Abstract: Rock-salt structured chalcogenides, such as PbTe, PbSe, and SnTe, are the top candidates for mid-temperature thermoelectric applications, and their p-type thermoelectric efficiencies can be enhanced via aligning the valence bands. Here, we provided comprehensive numerical investigations on the effects of band convergence on electronic properties. We found that the extra valance band can indeed significantly enhance the power factor. Nevertheless, the extra valance band can also increase the electronic thermal conductivity, which partially offsets the enhanced power factor for the overall figure-of-merit. Finally, we predicted that the maximum figure-of-merit for PbTe, PbSe, and SnTe can reach to 2.2, 1.8, and 1.6, re-spectively, without relying on the reduction in l

### 28. Title: Thermoelectric Enhancements in PbTe Alloys Due to Dislocation‐Induced Strains and Converged Bands
**DOI:** 10.1002/advs.201902628
**ID:** `p28`

Source: sciverse Abstract: In-grain dislocation-induced lattice strain fluctuations are recently revealed as an effective avenue for minimizing the lattice thermal conductivity. This effect could be integratable with electronic enhancements such as by band convergence, for a great advancement in thermoelectric performance. This motivates the current work to focus on the thermoelectric enhancements of p-type PbTe alloys, where monotelluride-alloying and Na-doping are used for a simultaneous manipulation on both dislocation and band structures. As confirmed by synchrotron X-ray diffractions and Raman measurements, the resultant dense in-grain dislocations induce lattice strain fluctuations for broadening the phonon dispersion, leading to an exceptionally low lattice thermal conductivity of ≈

### 29. Title: Band Convergence and Phonon Scattering Mediated Improved Thermoelectric Performance of SnTe–PbTe Nanocomposites
**DOI:** 10.1021/acsaem.0c01359
**ID:** `p29`

Source: sciverse Abstract: SnTe exhibits poor thermoelectric figure of merit owing to Sn vacancies that give rise to a low p-type Seebeck coefficient and high electrical–thermal conductivities. Here, we reported thermoelectr...

### 30. Title: Dopant induced band convergence leading to high thermoelectric power factor in Mg2Sn
**DOI:** 10.1016/j.mtphys.2023.101293
**ID:** `p30`

Source: sciverse Abstract: Band convergence is a common technique for enhancing the power factor of thermoelectric (TE) materials. This is usually achieved by solid solution formation in compounds having specific electronic band features . In this work, we show that a similar band convergence effect can be achieved in Mg 2 Sn by doping with small amounts of Bi. To identify this effect and the possible reason behind it, a detailed investigation of the electronic band structure (EBS) has been carried out using a recently developed multi-band refinement technique (MBRT). Nominal compositions of Mg 2.2 Sn 1-x Bi x (x = 0,0.005, 0.01, 0.0125, 0.015, 0.02) have been synthesized by induction melting followed by compaction using uniaxial hot-pressing. Measurement of Seebeck coefficient ( S ), elec

### 31. Title: Thermoelectric power of vacuum evaporated PbTe films
**DOI:** 10.1007/bf01604513
**ID:** `p31`

Source: sciverse Abstract: conditions. Attempts have been made to derive a relation which represents the variation of thermoelectric power with thickness of the film. The temperature variation of thermoelectric power has also bsen   |  Variation of thermoelectric power with thickness of the vacuum evaporated PbTe films has been investigated. The films were deposited on mica, glass, quartz and LiF substrates, under identical   |  studied.

### 32. Title: Band convergence coupled with carrier density matching enables high-performance PbTe thermoelectric
**DOI:** 10.1016/j.cej.2025.171293
**ID:** `p32`

Source: sciverse

### 33. Title: Nanostructuring thermoelectric materials using phononic crystals and reduction in lattice thermal conductivity
**DOI:** 10.1016/j.nxener.2026.100550
**ID:** `p33`

Source: sciverse Abstract: Phononic crystals (PnCs) are artificially engineered nanostructures designed to manipulate thermal transport by introducing periodic variations in material properties that scatter phonons. They offer a promising route to boost thermoelectric (TE) performance by tailoring heat flow at the nanoscale. This review analyzes how PnCs enhance the TE figure of merit ( ZT ) through selective phonon scattering, with a particular focus on reducing lattice thermal conductivity while optimizing efficient electronic transport. Particular attention is given to the effects of structural parameters, including periodicity, neck size, and film thickness, on electrical and thermal transport properties. Fabrication and characterization techniques are outlined briefly; however, the di

### 34. Title: Lattice thermal conductivity of graphene nanostructures
**DOI:** 10.48550/arxiv.1711.01561
**ID:** `p34`

Source: sciverse Abstract: Non-equilibrium molecular dynamics is used to investigate the heat current due to the atomic lattice vibrations in graphene nanoribbons and nanorings under a thermal gradient. We consider a wide range of temperature, nanoribbon widths up to 6nm and the effect of moderate edge disorder. We find that narrow graphene nanorings can efficiently suppress the lattice thermal conductivity at low temperatures (~100K), as compared to nanoribbons of the same width. Remarkably, rough edges do not appear to have a large impact on lattice energy transport through graphene nanorings while nanoribbons seem more affected by imperfections. Furthermore, we demonstrate that the effects of hydrogen-saturated edges can be neglected in these graphene nanostructures.

### 35. Title: In Situ Nanostructure Generation and Evolution within a Bulk Thermoelectric Material to Reduce Lattice Thermal Conductivity
**DOI:** 10.1021/nl100743q.s001
**ID:** `p35`

Source: sciverse Abstract: We show experimentally the direct reduction in lattice thermal conductivity as a result of in situ nanostructure generation within a thermoelectric material. Solid solution alloys of the high-performance thermoelectric PbTe−PbS 8% can be synthesized through rapid cooling and subsequent high-temperature activation that induces a spontaneous nucleation and growth of PbS nanocrystals. The emergence of coherent PbS nanostructures reduces the lattice thermal conductivity from ∼1 to ∼0.4 W/mK between 400 and 500 K.

### 36. Title: Giant reduction of thermal conductivity in twinning superlattice InAsSb nanowires
**Authors:** Lorenzo Peri, Domenic Prete, Valeria Demontis, Valentina Zannier, Francesca Rossi, Lucia Sorba, Fabio Beltram, Francesco Rossella
**Year:** 2022
**DOI:** 10.1016/j.nanoen.2022.107700
**ID:** `p36`

Source: arxiv Abstract: Semiconductor nanostructures hold great promise for high-efficiency waste heat recovery exploiting thermoelectric energy conversion, a technological breakthrough that could significantly contribute to providing environmentally friendly energy sources as well as in enabling the realization of self-powered biomedical and wearable devices. A crucial requirement in this field is the reduction of the thermal conductivity of the thermoelectric material without detrimentally affecting its electrical transport properties. In this work we demonstrate a drastic reduction of thermal conductivity in III-V semiconductor nanowires due to the presence of intentionally realized periodic crystal lattice twin planes. The electrical and thermal transport of these nanostructures, known

### 37. Title: Revisiting the Reduction of Thermal Conductivity in Nano- to Micro-Grained Bismuth Telluride: The Importance of Grain-Boundary Thermal Resistan
**Authors:** Sien Wang, Xiaowei Lu, Ankit Negi, Jixiong He, Kyunghoon Kim, Hezhu Shao, Peng Jiang, Jun Liu, Qing Hao
**Year:** 2021
**ID:** `p37`

Source: arxiv Abstract: Nanograined bulk alloys based on bismuth telluride (Bi2Te3) are the dominant materials for room-temperature thermoelectric applications. In numerous studies, existing bulk phonon mean free path (MFP) spectra predicted by atomistic simulations suggest sub-100 nm grain sizes are necessary to reduce the lattice thermal conductivity by decreasing phonon MFPs. This is in contrast with available experimental data, where a remarkable thermal conductivity reduction is observed even for micro-grained Bi2Te3 samples. In this work, first-principles phonon MFPs along both the in-plane and cross-plane directions are re-computed for bulk Bi2Te3. These phonon MFPs can explain new and existing experimental data on flake-like Bi2Te3 nanostructures with various thicknesses. For polyc

### 38. Title: Lattice thermal conductivity of Ti$_x$Zr$_y$Hf$_{1-x-y}$NiSn half-Heusler alloys calculated from first principles: Key role of nature of phonon
**Authors:** Simen N. H. Eliassen, Ankita Katre, Georg K. H. Madsen, Clas Persson, Ole Martin Løvvik, Kristian Berland
**Year:** 2016
**DOI:** 10.1103/PhysRevB.95.045202
**ID:** `p38`

Source: arxiv Abstract: In spite of their relatively high lattice thermal conductivity $κ_{\ell}$, the XNiSn (X=Ti, Zr or Hf) half-Heusler compounds are good thermoelectric materials. Previous studies have shown that $κ_{\ell}$ can be reduced by sublattice-alloying on the X-site. To cast light on how the alloy composition affects $κ_\ell$, we study this system using the phonon Boltzmann-transport equation within the relaxation time approximation in conjunction with density functional theory.The effect of alloying through mass-disorder scattering is explored using the virtual crystal approximation to screen the entire ternary Ti$_x$Zr$_{y}$Hf$_{1-x-y}$NiSn phase diagram. The lowest lattice thermal conductivity is found for the Ti$_x$Hf$_{1-x}$NiSn compositions; in particular, there is a sha

### 39. Title: Thermal Conductivity of Segmented Nanowires
**Authors:** Denis L. Nika, Aleksandr I. Cocemasov, Alexander A. Balandin
**Year:** 2016
**DOI:** 10.1007/978-3-319-30198-3_16
**ID:** `p39`

Source: arxiv Abstract: We present a review of the phonon thermal conductivity of segmented nanowires focusing on theoretical results for Si and Si/Ge structures with the constant and periodically modulated cross-sections. We describe the use of the face-centered cubic cell and Born-von Karman models of the lattice vibrations for calculating the phonon energy spectra in the segmented nanowires. Modification of the phonon spectrum in such nanostructures results in strong reduction of the phonon thermal conductivity and suppression of heat transfer due to a trapping of phonon modes in nanowire segments. Possible practical applications of segmented nanowires in thermoelectric energy generation are also discussed.

### 40. Title: Thermal conductivity of porous polycrystalline PbTe
**Authors:** Javier F. Troncoso, Piotr Chudzinski, Tchavdar N. Todorov, Pablo Aguado-Puente, Myrta Grüning, Jorge J. Kohanoff
**Year:** 2020
**DOI:** 10.1103/PhysRevMaterials.5.014604
**ID:** `p40`

Source: arxiv Abstract: PbTe is a leading thermoelectric material at intermediate temperatures, largely thanks to its low lattice thermal conductivity. However, its efficiency is too low to compete with other forms of power generation. This efficiency can be effectively enhanced by designing nanostructures capable of scattering phonons over a wide range of length scales to reduce the lattice thermal conductivity. The presence of grain boundaries can reduce the thermal conductivity to $\sim 0.5$ Wm$^{-1}$K$^{-1}$ for small vacancy concentrations and grain sizes. However, grains anneal at finite temperature, and equilibrium and metastable grain size distributions determine the extent of the reduction in thermal conductivity. In the present work, we propose a phase-field model informed by mol

### 41. Title: Thermoelectric properties of two-dimensional slabs of Ba8Ga16Ge30 from first principles
**Authors:** Deepa Kasinathan, Vicente Pacheco-Espejel, Helge Rosner
**Year:** 2011
**ID:** `p41`

Source: arxiv Abstract: Thermoelectric effects enable the direct conversion between thermal and electrical energy and provide an alternative route for power generation and refrigeration. The clathrate Ba8Ga16Ge30 has the highest figure of merit (ZT ~ 1) among other members in the family of type-I inorganic clathrates. Enhancement of the thermoelectric properties have been observed in multilayered superlattices, quantum wires and in nanostructured materials, either due to the increase in power-factor (S^{2}σ) or due to the reduction of lattice thermal conductivity (κ). Here, we investigate the thermoelectric properties of two-dimensional slabs with varying thickness of Ba8Ga16Ge30 using semi-classical Boltzmann transport theory with constant scattering approximation. We observe that, there 

### 42. Title: Modelling thermoelectric performance in nanoporous nanocrystalline silicon
**Authors:** Laura de Sousa Oliveira, Vassilios Vargiamidis, Neophytos Neophytou
**Year:** 2019
**DOI:** 10.1109/TNANO.2019.2935876
**ID:** `p42`

Source: arxiv Abstract: Introducing hierarchical disorder from multiple defects into materials through nanostructuring is one of the most promising directions to achieve extremely low thermal conductivities and thus improve thermoelectric performance. The success of nanostructuring relies on charge carriers having shorter mean-free-paths than phonons so that the latter can be selectively scattered. Nevertheless, introducing disorder into a material often comes at the expense of scattering charge carriers as well as phonons. In order to determine the tradeoff between the degradation of the lattice thermal conductivity and of the power factor due to this, we perform a theoretical investigation of both phonon and electron transport in nanocrystalline, nanoporous Si geometries. We use molecula

### 43. Title: Ambipolar Surface State Thermoelectric Power of Topological Insulator Bi2Se3
**Authors:** Dohun Kim, Paul Syers, Nicholas P. Butch, Johnpierre Paglione, Michael S. Fuhrer
**Year:** 2015
**DOI:** 10.1021/nl4032154
**ID:** `p43`

Source: arxiv Abstract: We measure gate-tuned thermoelectric power of mechanically exfoliated Bi2Se3 thin films in the topological insulator regime. The sign of the thermoelectric power changes across the charge neutrality point as the majority carrier type switches from electron to hole, consistent with the ambipolar electric field effect observed in conductivity and Hall effect measurements. Near charge neutrality point and at low temperatures, the gate dependent thermoelectric power follows the semiclassical Mott relation using the expected surface state density of states, but is larger than expected at high electron doping, possibly reflecting a large density of states in the bulk gap. The thermoelectric power factor shows significant enhancement near the electron-hole puddle carrier d

### 44. Title: Two functionals approach in DFT for the prediction of thermoelectric properties of Fe$_{2}$ScX (X = P, As, Sb) full Heusler compounds
**Authors:** Shivprasad S. Shastri, Sudhir K. Pandey
**Year:** 2019
**DOI:** 10.1088/1361-648X/ab2dd5
**ID:** `p44`

Source: arxiv Abstract: In the quest of new thermoelectric (TE) materials with high power factors, full-Heusler compounds having flat band are found to be promising candidates. In this direction, Fe$_{2}$ScX (X=P,As,Sb) compounds are investigated using mBJ for the band gap and SCAN to describe the electronic bands and phonon properties for TE applications. The band gaps obtained from mBJ are 0.81 eV, 0.69 eV and 0.60 eV for Fe$_{2}$ScX compounds, respectively. The phonon dispersion, phonon density of states (DOS) and partial DOS are calculated. The phonon contributions to specific heat are obtained as a function of temperature under harmonic approximation. The electronic band structutre calculated from mBJ and SCAN functionals are qualitatively compared. The TE parameters are calculated fo

### 45. Title: Decouple Electronic and Phononic Transport in Nanotwinned Structure: A New Strategy for Enhancing the Figure-of-merit of Thermoelectrics
**Authors:** Yanguang Zhou, Xiaojing Gong, Ben Xu, Ming Hu
**Year:** 2017
**DOI:** 10.1039/c7nr02557b
**ID:** `p45`

Source: arxiv Abstract: Thermoelectrics (TE) materials manifest themselves in direct conversion of temperature differences to electric power and vice versa. Despite remarkable advances have been achieved in the past decades for various TE systems, the energy conversion efficiencies of TE devices, which is characterized by a dimensionless figure-of-merit (ZT ), remain a generally poor factor that severely limits their competitiveness and range of employment. The bottleneck for substantially boosting ZT coefficient lies in the strong interdependence of the physical parameters involved in electronic and phononic transport. Here, we propose a new strategy of incorporating nanotwinned structures to decouple the electronic and phononic transport. Combining the new concept of nanotwin with the pr

### 46. Title: Development of novel thermoelectric materials by reduction of lattice thermal conductivity
**DOI:** 10.1088/1468-6996/11/4/044306
**ID:** `p46`

Source: sciverse Abstract: Thermal conductivity is one of the key parameters in the figure of merit of thermoelectric materials. Over the past decade, most progress in thermoelectric materials has been made by reducing their thermal conductivity while preserving their electrical properties. The phonon scattering mechanisms involved in these strategies are reviewed here and divided into three groups, including (i) disorder or distortion of unit cells, (ii) resonant scattering by localized rattling atoms and (iii) interface scattering. In addition, we propose construction of a natural superlattice in thermoelectric materials by intercalating an MX layer into the van der Waals gap of a layered TX2 structure which has a general formula of (MX)1+x (TX2) n (M=Pb, Bi, Sn, Sb or a rare earth eleme

### 47. Title: Lattice thermal conductivity of nanostructured thermoelectric materials based on PbTe
**DOI:** 10.1063/1.3117228
**ID:** `p47`

Source: sciverse Abstract: We report the through-thickness lattice thermal conductivity Λl of (PbTe)1−x/(PbSe)x nanodot superlattices (NDSLs) over a wide range of periods 5 nm≤h≤50 nm, compositions 0.15≤x≤0.25, growth temperatures 550 K≤Tg≤620 K, and growth rates 1 μm h−1≤R≤4 μm h−1. All of our measurements approach Λl of bulk homogenous PbTe1−xSex alloys with the same average composition. For 5 nm≤h≤50 nm, Λl is independent of h; a result we attribute to short mean-free paths of phonons in PbTe and small acoustic impedance mismatch between PbTe/PbSe. We alloyed the PbTe layers of four NDSLs with SnTe up to a mole fraction y=18%; Λl is reduced by &amp;lt;25%.

### 48. Title: Ultralow thermal conductivity and high thermoelectric figure of merit in SnSe crystals
**DOI:** 10.1038/nature13184
**ID:** `p48`

Source: sciverse Abstract: The thermoelectric effect enables direct and reversible conversion between thermal and electrical energy, and provides a viable route for power generation from waste heat. The efficiency of thermoelectric materials is dictated by the dimensionless figure of merit, ZT (where Z is the figure of merit and T is absolute temperature), which governs the Carnot efficiency for heat conversion. Enhancements above the generally high threshold value of 2.5 have important implications for commercial deployment, especially for compounds free of Pb and Te. Here we report an unprecedented ZT of 2.6 ± 0.3 at 923 K, realized in SnSe single crystals measured along the b axis of the room-temperature orthorhombic unit cell. This material also shows a high ZT of 2.3 ± 0.3 along the c

### 49. Title: Ultrahigh power factor and thermoelectric performance in hole-doped single-crystal SnSe
**DOI:** 10.1126/science.aad3749
**ID:** `p49`

Source: sciverse Abstract: Thermoelectric technology, harvesting electric power directly from heat, is a promising environmentally friendly means of energy savings and power generation. The thermoelectric efficiency is determined by the device dimensionless figure of merit ZT(dev), and optimizing this efficiency requires maximizing ZT values over a broad temperature range. Here, we report a record high ZT(dev) ∼1.34, with ZT ranging from 0.7 to 2.0 at 300 to 773 kelvin, realized in hole-doped tin selenide (SnSe) crystals. The exceptional performance arises from the ultrahigh power factor, which comes from a high electrical conductivity and a strongly enhanced Seebeck coefficient enabled by the contribution of multiple electronic valence bands present in SnSe. SnSe is a robust thermoelectri

### 50. Title: Polycrystalline SnSe with a thermoelectric figure of merit greater than the single crystal
**DOI:** 10.1038/s41563-021-01064-6
**ID:** `p50`

Source: sciverse Abstract: Thermoelectric materials generate electric energy from waste heat, with conversion efficiency governed by the dimensionless figure of merit, ZT. Single-crystal tin selenide (SnSe) was discovered to exhibit a high ZT of roughly 2.2-2.6 at 913 K, but more practical and deployable polycrystal versions of the same compound suffer from much poorer overall ZT, thereby thwarting prospects for cost-effective lead-free thermoelectrics. The poor polycrystal bulk performance is attributed to traces of tin oxides covering the surface of SnSe powders, which increases thermal conductivity, reduces electrical conductivity and thereby reduces ZT. Here, we report that hole-doped SnSe polycrystalline samples with reagents carefully purified and tin oxides removed exhibit an ZT of 

### 51. Title: 3D Printed SnSe Thermoelectric Generators with Figure of Merit Exceeding Unity
**DOI:** 10.5281/zenodo.2163506
**ID:** `p51`

Source: sciverse Abstract: 3D Printed SnSe Thermoelectric Generators with Figure of Merit Exceeding Unity data

### 52. Title: THERMOELECTRIC FIGURE OF MERIT IN (AGSB)1-ХPBХSE2 SINGLE CRYSTALS
**DOI:** 10.32782/pet-2021-1-7
**ID:** `p52`

Source: sciverse Abstract: This article is devoted to studies the dependence of the thermal conductivity coefficient and thermoelectric figure of merit in (AgSb)1-xPbxSe2 single crystals on their composition. We found that the lattice component provides the main contribution to the thermal conductivity of solid solutions (AgSb)1-xPbxSe2 at x=0-0,4. The electronic thermal conductivity in single crystals with values of x at 0,92-1, becomes close to the lattice component. An increase in the Pb fraction of (AgSb)1-xPbxSe2 in the range from x=0 to x=0,4 leads to a decrease in the thermal conductivity (AgSb)1-xPbxSe2 from 0.56 W / K · m to 0.27 W / K · m, and an increase in x from 0,92 to 1 leads to an increase in the thermal conductivity in the range from 0,45 W / K · m to 1,11 W / K · m. The t

### 53. Title: Charge Transport in Thermoelectric SnSe Single Crystals
**DOI:** 10.1021/acsenergylett.7b01259
**ID:** `p53`

Source: sciverse Abstract: SnSe has attracted increasing attention as a promising thermoelectric material. In this work, a horizontal vapor transfer method was developed to synthesize high-quality, fully dense, and stoichiometric SnSe single crystals, which enables an evaluation of the transport properties inherent to SnSe along the bc-plane. The electronic transport properties can be well-understood by a single parabolic band model with acoustic phonon scattering, enabling insights into the fundamental material parameters determining the electronic properties. The lattice thermal conductivity (kappa(1)) decreases from 2.0 W m(-1) K-1 at 300 K to 0.55 W m(-1) K-1 at 773 K. It is revealed that an increase in hole concentration, an involvement of low-lying bands for transport, and a further 

### 54. Title: Achieving High Thermoelectric Figure of Merit in Polycrystalline SnSe via Introducing Sn Vacancies
**DOI:** 10.1021/jacs.7b11875
**ID:** `p54`

Source: sciverse Abstract: Thermoelectric power generation technology has emerged as a clean "heat engine" that can convert heat to electricity. Recently, the discovery of an ultrahigh thermoelectric figure of merit in SnSe crystals has drawn a great deal of attention. In view of their facile processing and scale-up applications, polycrystalline SnSe materials with ZT values comparable to those of the SnSe crystals are greatly desired. Here we achieve a record high ZT value ∼2.1 at 873 K in polycrystalline Sn1-xSe with Sn vacancies. We demonstrate that the carrier concentration increases by artificially introducing Sn vacancies, contributing significantly to the enhancements of electrical conductivity and thermoelectric power factor. The detailed analysis of the data in the light of first-

### 55. Title: Studies on thermoelectric figure of merit of Na-doped p-type polycrystalline SnSe
**DOI:** 10.1039/c5ta08847j
**ID:** `p55`

Source: sciverse Abstract: <p>Na doping improved both the peak and average ZT of p-type polycrystalline SnSe.</p>

### 56. Title: 3D Printed SnSe Thermoelectric Generators with High Figure of Merit
**DOI:** 10.1002/aenm.201900201
**ID:** `p56`

Source: sciverse Abstract: Since the discovery of the record figure of merit (ZT) of 2.6 ± 0.3 in tin selenide (SnSe), the material has attracted much attention in the field of thermoelectrics. This paper reports a novel pseudo‐3D printing technique to fabricate bulk SnSe thermoelectric elements, allowing for the fabrication of standard configuration thermoelectric generators. In contrast to fabrication examples presented to date, this technique is potentially very low‐cost and allows for facile, scalable, and rapid fabrication. Bulk SnSe thermoelectric elements are produced and characterized over a wide range of temperatures. An element printed from an ink with 4% organic binder produces the highest performance, with a ZT value of 1.7 (±0.25) at 758 K. This is the highest ZT reported of a

### 57. Title: Thermoelectric Figure-of-Merit of Fully Dense Single-Crystalline SnSe
**DOI:** 10.1021/acsomega.8b03323
**ID:** `p57`

Source: sciverse Abstract: Single-crystalline SnSe has attracted much attention because of its record high figure-of-merit ZT ≈ 2.6; however, this high ZT has been associated with the low mass density of samples which leaves the intrinsic ZT of fully dense pristine SnSe in question. To this end, we prepared high-quality fully dense SnSe single crystals and performed detailed structural, electrical, and thermal transport measurements over a wide temperature range along the major crystallographic directions. Our single crystals were fully dense and of high purity as confirmed via high statistics 119Sn Mössbauer spectroscopy that revealed <0.35 at. % Sn(IV) in pristine SnSe. The temperature-dependent heat capacity (C p) provided evidence for the displacive second-order phase transition from P

### 58. Title: Layered Tin Chalcogenides SnS and SnSe: Lattice Thermal Conductivity Benchmarks and Thermoelectric Figure of Merit
**DOI:** 10.1021/acs.jpcc.2c02401
**ID:** `p58`

Source: sciverse Abstract: Tin sulfide (SnS) and tin selenide (SnSe) are attractive materials for thermoelectric conversion applications. Favorable small band gap, high carrier mobility, large Seebeck coefficient, and remarkably low lattice thermal conductivity are a consequence of their anisotropic crystal structure of symmetry Pnma , made of corrugated, black phosphorus-like layers. Their internal lattice dynamics combined with chemical bond softening in going from SnS to SnSe make for subtle effects on lattice thermal conductivity. Reliable prediction of phonon transport for these materials must therefore include many-body effects. Using first principles methods and a transferable tight-binding potential for frozen phonon calculations, here, we investigate the evolution of thermal latti

### 59. Title: Recent Advances in Ultrahigh Thermoelectric Performance Material SnSe
**DOI:** 10.54227/mlab.20220056
**ID:** `p59`

Source: sciverse Abstract: This perspective discusses the surprising discovery and development of SnSe thermoelectrics. Undoped, hole-doped, and electron-doped SnSe single crystals have successively represented an extraordinarily high thermoelectric figure of merit (ZT) ranging from 2.6 to 2.9, revitalizing efforts on finding new high-performance thermoelectric systems. Their unprecedented performance is mainly attributed to ultralow thermal conductivity arising from the uniquely anisotropic and anharmonic crystal chemistry of SnSe. Soon after the publications on SnSe single crystals, substantial debates were raised on their thermoelectric performance, especially on truth in ultralow thermal conductivity. Very recently, polycrystalline SnSe samples were synthesized, exhibiting lower lattic

### 60. Title: Sn Filling Effects on the Thermoelectric Properties of CoSb3 Skutterudites
**DOI:** 10.3740/mrsk.2006.16.9.529
**ID:** `p60`

Source: sciverse Abstract: Sn-filled <TEX>$Co_8Sb_{24}$</TEX> skutterudites were synthesized by the encapsulated induction melting process. Single <TEX>${\delta}-phase$</TEX> was successfully obtained by subsequent annealing and confirmed by X-ray diffraction analysis. Temperature dependences of Seebeck coefficient, electrical resistivity and thermal conductivity were examined from 300 K to 700 K. The positive Seebeck coefficient confirmed the p-type conductivity of the Sn-filled <TEX>$Co_8Sb_{24}$</TEX>. Electrical resistivity increased with increasing temperature, which shows that the Sn-filled <TEX>$Co_8Sb_{24}$</TEX> skutterudite is a highly degenerate semiconductor. Thermal conductivity was reduced by Sn-filling because the filler atoms acted as phonon scattering centers in the skutte

### 61. Title: Characterization of multiple-filled skutterudites with high thermoelectric performance
**DOI:** 10.1016/j.jallcom.2019.152272
**ID:** `p61`

Source: sciverse Abstract: High performance multiple-filled X–CoSb<sub>3</sub> skutterudites (X=Yb、Ca、Ba、Al、Ga、In、La、Eu) was prepared by the long term annealing and hot-pressing approaches. Compared with the one-element filling method, multi-elements filling in CoSb<sub>3</sub> can improve their thermoelectric values. The lattice constant of skutterudite filled with multiple types of atoms was increased to 9.076Å, higher than 9.036Å of the un-filled one. The electrical conductivity, thermal conductivity and Seebeck coefficient were analyzed from 300K to 823K. The filling fraction of Yb increase with the increasing Fe content in both the Fe-rich phase and the Fe-poor phase. For Ca atoms, a significant phase separation occurs in the Fe-rich phase and the Fe-poor phase, and the Ca filling fra

### 62. Title: Enhanced thermoelectric performance in rare-earth filled-skutterudites
**DOI:** 10.1039/c6tc01000h
**ID:** `p62`

Source: sciverse Abstract: <p>Enhanced filler filling fractions and thermoelectric performance in rare-earth filled-skutterudites by using a new non-equilibrium synthesis approach.</p>

### 63. Title: Partial filling of skutterudites: Optimization for thermoelectric applications
**DOI:** 10.1557/jmr.2005.0400
**ID:** `p63`

Source: sciverse Abstract: Over the last ten years there has been substantial experimental and theoretical effort in understanding the transport properties of filled skutterudite compounds to optimize their thermoelectric properties. One such approach involves partially filling the voids in attempting to optimize the electrical properties while minimizing the thermal conductivity. We illustrate the importance of this approach by plotting and comparing the figure of merit of CoSb3 over a large range of carrier concentrations and thermal conductivity values. The thermal conductivity of partially filled skutterudites AxCo4Sb12, where A = La, Eu, and Yb, is analyzed using the Debye model to correlate the data with the type of filler atom in evaluating the role of the filler in affecting the th

### 64. Title: Electrical performance of skutterudites solar thermoelectric generators
**DOI:** 10.1016/s1359-4311(03)00065-6
**ID:** `p64`

Source: sciverse Abstract: The paper focuses on the electrical performance of skutterudites based solar thermoelectric generators (STG). Basics of STG mathematical modeling are reported. Two STG concepts, namely the flat plate model with identical collector and radiator areas and the STG configuration with concentrators have been considered. The main focus is on the characteristics of the two types of STG. The constant and how such systems would perform if they were on board a spacecraft on journey towards the Sun.

### 65. Title: Beneficial Effect of S-Filling on Thermoelectric Properties of S x Co4Sb11.2Te0.8 Skutterudite
**DOI:** 10.1007/s11664-017-5891-0
**ID:** `p65`

Source: sciverse Abstract: In this work, Te-doped and S-filled S x Co4Sb11.2Te0.8 (x=0.1, 0.15, 0.2, 0.25, 0.3, 0.4) skutterudite compounds have been prepared using solid state reaction and spark plasma sintering. Thermoelectric measurements of the consolidated samples were examined in a temperature range of 300–850K, and the influences of S-addition on the thermoelectric properties of S x Co4Sb11.2Te0.8 skutterudites are systematically investigated. The results indicate that the addition of sulfur and tellurium is effective in reducing lattice thermal conductivity due to the point-defect scattering caused by tellurium substitutions and the cluster vibration brought by S-filling. The solubility of tellurium in skutterudites is enhanced with sulfur addition via charge compensation. The ther

### 66. Title: Quenching rattling modes in skutterudites with pressure
**DOI:** 10.1103/physrevb.91.224304
**ID:** `p66`

Source: sciverse Abstract: A high-pressure study of the lattice dynamics in the filled skutterudite ${\mathrm{Eu}}_{0.84}{\mathrm{Fe}}_{4}{\mathrm{Sb}}_{12}$ was carried out by means of x-ray powder diffraction and nuclear inelastic scattering. The anharmonicity of particular phonon modes was characterized by mode and element specific Gr\"uneisen parameters. The large anharmonicity of the rattling optical mode that is hybridized with the acoustical phonons at ambient pressure is reduced at high pressure as the phonon modes decouple. This result suggests that anharmonic coupling between acoustic and optical phonon modes plays a central role in the reduced thermal conductivity.

### 67. Title: Effective role of filling fraction control in p-type CexFe3CoSb12 skutterudite thermoelectric materials
**DOI:** 10.1016/j.intermet.2018.11.010
**ID:** `p67`

Source: sciverse Abstract: p-type Ce-filled Fe<sub>4-x</sub>Co<sub>x</sub>Sb<sub>12</sub> skutterudite is a promising thermoelectric material with high thermal-to-electric conversion efficiency at mid-to-high temperatures. However, fabrication of a complete single phase is required in order to secure performance reliability due to the charge state of Ce. We herein report that optimization of the Ce filling fraction according to the compositions and synthetic processes is a critical factor to develop a manufacturing process that can be applied to massive production of single phase p-type Ce-filled skutterudite. The durable maximum zT (thermoelectric figure of merit) value of Ce-filled skutterudites fabricated here was 0.81at 723K in Ce<sub>0.86</sub>Fe<sub>3</sub>CoSb<sub>12.09</sub>.

### 68. Title: Thermoelectric nanocomposite from the metastable void filling in caged skutterudite
**DOI:** 10.1557/jmr.2011.90
**ID:** `p68`

Source: sciverse Abstract: We report a novel approach to realize the formation of well-distributed nanodispersions in n-type filled skutterudite through the manipulation of metastable void fillers by a designed sophisticated process of materials synthesis. Metastable Ga filling in CoSb3 is proved to happen at high temperature. The subsequent controlled annealing procedure drives Ga out of the crystal voids and finally leads to the homogeneous dispersion of GaSb nanodots with an average size of 11 nm in CoSb3 matrix. The grain size of nanodispersions can be manipulated by the controlled cooling procedure. The well-distributed nanodispersions are observed to enhance Seebeck coefficients and reduce lattice thermal conductivity at low temperature. Therefore, the thermoelectric performance of n

### 69. Title: Thermoelectric Transport Properties of Double-Filling InxLa0.25Co4Sb12 Skutterudite Materials
**DOI:** 10.1007/s11664-022-10083-1
**ID:** `p69`

Source: sciverse Abstract: Filled-skutterudite materials are promising candidates for thermoelectric applications in the intermediate-temperature range to recover waste heat. In this work, mechanical alloying and spark plasma sintering (SPS) techniques were used to consolidate double-filling InxLa0.25Co4Sb12 (x=0, 0.1, 0.3, 0.5) samples. X-ray diffraction, scanning electron microscopy, and energy-dispersive x-ray spectroscopy were used to analyze the microstructure of the InxLa0.25Co4Sb12 SPS-ed samples. The microstructure results revealed the main phase of the CoSb3 skutterudite structure with a small amount of InSb and CoSb2 attributed to secondary phases. Electrical resistivity remarkably decreased to 9.7μΩm at room temperature for the In0.5La0.25Co4Sb12 sample, mainly due to the effect

### 70. Title: Ce Filling Limit and Its Influence on Thermoelectric Performance of Fe3CoSb12-Based Skutterudite Grown by a Temperature Gradient Zone Melting M
**DOI:** 10.3390/ma14226810
**ID:** `p70`

Source: sciverse Abstract: CoSb3-based skutterudite is a promising mid-temperature thermoelectric material. However, the high lattice thermal conductivity limits its further application. Filling is one of the most effective methods to reduce the lattice thermal conductivity. In this study, we investigate the Ce filling limit and its influence on thermoelectric properties of p-type Fe3CoSb12-based skutterudites grown by a temperature gradient zone melting (TGZM) method. Crystal structure and composition characterization suggests that a maximum filling fraction of Ce reaches 0.73 in a composition of Ce0.73Fe2.73Co1.18Sb12 prepared by the TGZM method. The Ce filling reduces the carrier concentration to 1.03 × 1020 cm-3 in the Ce1.25Fe3CoSb12, leading to an increased Seebeck coefficient. Densi

### 71. Title: Multi-filling approach for the improvement of thermoelectric properties of skutterudites
**DOI:** 10.1109/ict.2001.979821
**ID:** `p71`

Source: sciverse Abstract: Several skutterudite antimonides filled with atoms of different kinds, (Ba, M)/sub y/Co/sub 4/Sb/sub 12/ (M=Ce, La, Sr), have been synthesized by the combination of solid state reaction and melting methods. Thermal conductivity of (Ba,Sr)/sub y/Co/sub 4/Sb/sub 12/ samples shows a behavior similar to that of Ba/sub y/Co/sub 4/Sb/sub 12/. Adding a small amount of Ce or La to the Ba/sub y/Co/sub 4/Sb/sub 12/ system is effective in further reducing the lattice thermal conductivity. The difference in the ionic radii of the two co-filler atoms is the most sensitive factor for scattering of phonons. The multi-filled (Ba, M)/sub y/Co/sub 4/Sb/sub 12/ (M=Sr, Ce, La) show lower Seebeck coefficients as compared to the single-filled Ba/sub y/Co/sub 4/Sb/sub 12/ having the sa

### 72. Title: Skutterudites for Thermoelectric Applications
**DOI:** 10.1201/9781315151618-11
**ID:** `p72`

Source: sciverse Abstract: This chapter discusses the characteristics of the materials related to their thermoelectric performances, such as electrical and thermal transports. Some ternary skutterudites can host varying filler amounts due to the presence of extended solid solutions given by the partial or total substitution of the transition metals. The employment of different ions to fill the voids, introducing different vibrational modes into the lattice, is at the origin of the multiple filling approaches to skutterudites lattice conductivity reduction, resulting in an improvement of the ‘rattling’ effects. What was reported up to reflects the high complexity of the scenario related to the class of thermoelectric skutterudites: each attempted strategy for material optimization involves 

### 73. Title: Thermoelectric Skutterudites
**DOI:** 10.1201/9781003105411
**ID:** `p73`

Source: sciverse Abstract: This book informs the reader about a fascinating class of materials referred to as skutterudites, the atomic lattice of which has large structural voids that can be filled by a variety of foreign species, spanning from alkali to alkaline to rare earth ions. The fillers, in their unique way, drastically modify the physical properties of the parent structure, giving rise to outstanding thermoelectric properties. This exciting material is of growing importance and is finding applications in a variety of different fields. This book will be of interest to researchers working in materials science, physics, and chemistry in addition to graduate students in these subjects. Features:•&nbsp;Gives a comprehensive account of all fundamental physical properties of skutterudit

### 74. Title: Study on rattling of filling atom in Sm filled-skutterudite compounds
**DOI:** 10.7498/aps.57.7078
**ID:** `p74`

Source: sciverse Abstract: The single-phase polycrystalline Sm-filled skutterudites SmyFexCo4-xSb12 were investigated by Rietveld refinement and Raman scattering spectral analysis. The results of Rietveld refinement clarify that the SmyFexCo4-xSb12 compound has a filled skutterudite structure. The thermal parameter of Sm is larger than that of Sb, Fe and Co, and the Sb-Sb bond length of SmyFexCo4-xSb12 is longer than that of unfilled skutterudites. The results of Raman scattering study show a shift and broadening of the Sb4 ring breathing modes. These results indicate that Sm atoms fill the Sb-icosahedron voids of the skutterudites and rattle in them.

### 75. Title: Enhanced thermoelectric performance in TiNiSn-based half-Heuslers
**DOI:** 10.48550/arxiv.1301.0419
**ID:** `p75`

Source: sciverse Abstract: Thermoelectric figures of merit, ZT &gt; 0.5, have been obtained in arc-melted TiNiSn-based ingots. This promising conversion efficiency is due to a low lattice thermal conductivity, which is attributed to excess nickel in the half-Heusler structure.

### 76. Title: High-ZT half-Heusler thermoelectrics, Ti0.5Zr0.5NiSn and Ti0.5Zr0.5NiSn0.98Sb0.02: Physical properties at low temperatures
**DOI:** 10.1016/j.actamat.2018.12.042
**ID:** `p76`

Source: sciverse Abstract: With a small gap in the density of states and a substantially semiconducting behavior half Heusler alloys have drawn attention as thermoelectric materials. For this study we have selected Hf-free compounds, Ti<sub>0.5</sub>Zr<sub>0.5</sub>NiSn, Ti<sub>0.5</sub>Zr<sub>0.5</sub>NiSn (with a densification aid (DA)) and Ti<sub>0.5</sub>Zr<sub>0.5</sub>NiSn<sub>0.98</sub>Sb<sub>0.02</sub> as well their parent alloys TiNiSn and ZrNiSn as cheap thermoelectrics. Electrical resistivity, thermal conductivity and specific heat were evaluated below room temperature (4.2–300K) in order to get insight into the mechanism of transport properties. SEM and TEM investigations as well as DFT (density functional theory) calculations accompany this research. The fine-grained epitaxial

### 77. Title: Defect‐Assisted Ultrahigh zT of TaFeSb Based Half‐Heuslers
**DOI:** 10.1002/smll.73765
**ID:** `p77`

Source: sciverse Abstract: ABSTRACT The half‐Heusler compound TaFeSb has been reported to exhibit promising ‐type thermoelectric properties. Here, a high and reproducible thermoelectric figure of merit (zT) of 1.55 with Ti substitution has been reported. It is demonstrated that the zT enhancement is not solely an effect of carrier optimization; the role of antisite disorder is also shown to be pivotal. To demonstrate this, samples are prepared with controlled stoichiometry to tune the disorder. The thermoelectric power factor was found suppressed in samples with only a nominal disorder, which also enhanced the lattice thermal conductivity, leading to a low zT of . However, with Fe deficiency, which is shown to increase the antisite disorder, we observed an increase in the Seebeck effective

### 78. Title: Thermoelectric Half-Heusler Compounds and Fe2Val
**DOI:** 10.1201/9781003640127
**ID:** `p78`

Source: sciverse Abstract: Thermoelectric Half-Heusler Compounds and Fe2Val outlines the key properties that&nbsp;an efficient thermoelectric material should possess, covers the structural aspects of Heusler and half-Heusler compounds, and discusses in detail the thermoelectric properties of various families of half-Heusler compounds, including the fabrication and performance of thermoelectric modules based on these compounds. Because many efficient thermoelectric materials are also topological semiconductors, this aspect is considered and explored to determine whether it applies and would benefit the thermoelectric performance of half-Heusler compounds. This book is of interest to everyone working in&nbsp;or interested in the field of thermoelectricity and in the development of novel ther

### 79. Title: Substantial enhancement in thermoelectric figure-of-merit of half-Heusler ZrNiPb alloys
**DOI:** 10.1007/s12034-024-03217-0
**ID:** `p79`

Source: sciverse Abstract: Ternary half-Heusler (HH) alloys are under intense investigations recently towards achieving high thermoelectric (TE) figure-of-merit (ZT). Of particular interest is the ZrNiPb-based HH alloy, where an optimal value of ZT ~ 0.7 at 773 K has been achieved by co-doping Sn and Bi at Pb site. In this work, we identify an excellent ZT of 1.3 in ZrNi1+xPb0.38Sn0.6Bi0.02 (x = 0.03, at 773 K) composite alloy. This is achieved by synergistic modulation of electronic as well as thermal properties via introduction of minor phase of full-Heusler (FH) in the HH matrix through compositional tuning approach. These Ni-rich ZrNi1+xPb0.38Sn0.6Bi0.02 (0 ≤ x ≤ 0.07) alloys were synthesized via energy efficient and time-curbed techniques that involved Arc melting followed by consolid

### 80. Title: Electronic Structure and Thermoelectric Properties of Half-Heusler Alloys NiTZ
**Authors:** Dhurba R. Jaishi, Nileema Sharma, Bishnu Karki, Bishnu P. Belbase, Rajendra P. Adhikari, Madhav Prasad Ghimire
**Year:** 2020
**DOI:** 10.1063/5.0031512
**ID:** `p80`

Source: arxiv Abstract: We have investigated the electronic and thermoelectric properties of half-Heusler alloys NiTZ (T = Sc, and Ti; Z = P, As, Sn, and Sb) having 18 valence electron. Calculations are performed by means of density functional theory and Boltzmann transport equation with constant relaxation time approximation, validated by NiTiSn. The chosen half-Heuslers are found to be an indirect band gap semiconductor, and the lattice thermal conductivity is comparable with the state-of-the-art thermoelectric materials. The estimated power factor for NiScP, NiScAs, and NiScSb reveals that their thermoelectric performance can be enhanced by appropriate doping rate. The value of ZT found for NiScP, NiScAs, and NiScSb are 0.46, 0.35, and 0.29, respectively at 1200 K.

### 81. Title: Conventional Half-Heusler Alloys Advance State-of-the-Art Thermoelectric Properties
**Authors:** Mousumi Mitra, Allen Benton, Md Sabbir Akhanda, Jie Qi, Mona Zebarjadi, David J. Singh, S. Joseph Poon
**Year:** 2022
**ID:** `p81`

Source: arxiv Abstract: Half-Heusler (HH) phases have garnered much attention as thermally stable and non-toxic thermoelectric materials for power conversion. The most studied alloys to date utilize Hf, Zr, and Ti as the base components. These alloys can achieve a moderate dimensionless figure of merit, ZT, near 1. Recent studies have advanced the thermoelectric performance of HH alloys by employing nanostructures and novel compositions to achieve larger ZT, reaching as high as 1.5. Herein, we report that traditional alloying techniques applied to the conventional HfZr-based half-Heusler alloys can also lead to exceptional ZT. Specifically, we present the well-studied p-type Hf0.3Zr0.7CoSn0.3Sb0.7, previously reported to have a ZT~0.8, resonantly doped with less than 1 at. % metallic Al on

### 82. Title: High Thermoelectric Figure of Merit by Resonant Dopant in Half-Heusler Alloys
**Authors:** Long Chen, Yamei Liu, Jian He, Terry M. Tritt, S. Joseph Poon
**Year:** 2017
**ID:** `p82`

Source: arxiv Abstract: Half-Heusler alloys have been one of the benchmark high temperature thermoelectric materials owing to their thermal stability and promising figure of merit ZT. Simonson et al. early showed that small amounts of vanadium doped in Hf0.75Zr0.25NiSn enhanced the Seebeck coefficient and correlated the change with the increased density of states near the Fermi level. We herein report a systematic study on the role of vanadium (V), niobium (Nb), and tantalum (Ta) as prospective resonant dopants in enhancing the ZT of n-type half-Heusler alloys based on Hf0.6Zr0.4NiSn0.995Sb0.005. The V doping was found to increase the Seebeck coefficient in the temperature range 300-1000 K, consistent with a resonant doping scheme. In contrast, Nb and Ta act as normal n-type dopants, as ev

### 83. Title: Intrinsically high thermoelectric figure of merit of half-Heusler ZrRuTe
**Authors:** Sonu Prasad Keshri, Amal Medhi
**Year:** 2019
**ID:** `p83`

Source: arxiv Abstract: The electronic structure and thermoelectric properties of ZrRuTe-based Half-Heusler compounds are studied using density functional theory (DFT) and Boltzmann transport formalism. Based on rigorous computations of electron relaxation time $τ$ considering electron-phonon interactions and lattice thermal conductivity $κ_l$ considering phonon-phonon interactions, we find ZrRuTe to be an intrinsically good thermoelectric material. It has a high power factor of $\sim 2\times 10^{-3}$ W/m-K$^{2}$ and low $κ_l\sim 10$ W/m-K at 800 K. The thermoelectric figure of merit $ZT \sim 0.13$ at 800 K is higher than similar other compounds. We have also studied the properties of the material as a function of doping and find the thermoelectric properties to be substantially enhanced f

### 84. Title: Entropy Stabilized ZrHfCoNiSnSb Half-Heusler Alloy for Thermoelectric Applications: A Theoretical Prediction
**Authors:** Rajeev Ranjan
**Year:** 2025
**ID:** `p84`

Source: arxiv Abstract: Half-Heusler (HH) alloys are potential thermoelectric materials for use at elevated temperatures due to their high Seebeck coefficient and superior mechanical and thermal stability. However, their enhanced lattice thermal conductivity is detrimental to thermoelectric applications. One way to circumvent this problem is to introduce mass disorder at lattice sites by mixing the components of two or more alloys. Such systems are typically stabilized by the entropy of mixing. In this work, using computational tools, we propose a mixed HH, namely, ZrHfCoNiSnSb, which can be formed by the elemental compositions of the parent half-Heuslers ZrNiSn/HfNiSn and HfCoSb/ZrCoSb. We propose that this new compound can be synthesized at elevated temperatures, as its Gibbs free energy

### 85. Title: Mechanical, optoelectronic and thermoelectric properties of half-Heusler p-type semiconductor BaAgP: A DFT investigation
**Authors:** F. Parvin, M. A. Hossain, M. I. Ahmed, K. Akter, A. K. M. A. Islam
**Year:** 2020
**ID:** `p85`

Source: arxiv Abstract: We have explored the mechanical, electronic, optical and thermoelectric properties of p-type half-Heusler compound BaAgP for the first time using density functional theory based calculations. The mechanical and dynamical stability of this compound is confirmed by studying the Born stability criteria and phonon dispersion curve, respectively. It is soft, ductile and elastically anisotropic. The atomic bonding along a-axis is stronger than that along c-axis. The calculated electronic structure reveals that the studied compound is an indirect band gap semiconductor. The analysis of charge density distribution map and Mulliken population reveals that the bonding in BaAgP is a mixture of covalent and ionic. The optical features confirm that BaAgP is optically anisotropic

### 86. Title: First-principles study of disordered half-Heusler alloys \textit{X}Fe$_{0.5}$Ni$_{0.5}$Sn (\textit{X} = Nb, Ta) as thermoelectric prospects
**Authors:** Mohd Zeeshan, Chandan Kumar Vishwakarma, B. K. Mani
**Year:** 2023
**ID:** `p86`

Source: arxiv Abstract: High lattice thermal conductivity in half-Heusler alloys has been the major bottleneck in thermoelectric applications. Disordered half-Heusler alloys could be a plausible alternative to this predicament. In this paper, utilizing first-principles simulations, we have demonstrated the low lattice thermal conductivity in two such phases, NbFe$_{0.5}$Ni$_{0.5}$Sn and TaFe$_{0.5}$Ni$_{0.5}$Sn, in comparison to well-known half-Heusler alloy TiCoSb. We trace the low thermal conductivity to their short phonon lifetime, originating from the interaction among acoustic and low-lying optical phonons. We recommend nanostructuring as an effective route in further diminishing the lattice thermal conductivity. We further predict that these alloys can be best used in the temperature

### 87. Title: Significant ZT Enhancement in p-type Ti(Co,Fe)Sb-InSb Nanocomposites via a Synergistic High Mobility Electron Injection Energy filtering and Bo
**Authors:** Wenjie Xie, Yonggao Yana, Song Zhuc, Menghan Zhouc, Sascha Populohb, Krzysztof Gałązkab, S. Joseph Poon, Anke Weidenkaff, Jian He, Xinfeng Tanga, Terry M. Tritt
**Year:** 2013
**ID:** `p87`

Source: arxiv Abstract: It has been demonstrated that InSb nanoinclusions, which are formed in situ, can simultaneously improve all three individual thermoelectric properties of the n-type half Heusler compound (Ti,Zr,Hf)(Co,Ni)Sb [Xie et al., Acta Mater. 58, 4795 (2010)]. In the work presented herein, we have adopted the same approach to the p-type half Heusler compound Ti(Co,Fe)Sb. The results of resistivity, Seebeck coefficient, thermal conductivity, and Hall coefficient measurements indicate that the combined high mobility electron injection, low energy electron filtering, and boundary scattering, again, lead to a simultaneous improvement of all three individual thermoelectric properties: enhanced Seebeck coefficient and electrical conductivity as well as reduced lattice thermal conduc

### 88. Title: Enhanced Thermoelectric Figure of Merit of p-Type Half-Heuslers
**DOI:** 10.1021/nl104138t
**ID:** `p88`

Source: sciverse Abstract: Half-Heuslers would be important thermoelectric materials due to their high temperature stability and abundance if their dimensionless thermoelectric figure of merit (ZT) could be made high enough. The highest peak ZT of a p-type half-Heusler has been so far reported about 0.5 due to the high thermal conductivity. Through a nanocomposite approach using ball milling and hot pressing, we have achieved a peak ZT of 0.8 at 700 °C, which is about 60% higher than the best reported 0.5 and might be good enough for consideration for waste heat recovery in car exhaust systems. The improvement comes from a simultaneous increase in Seebeck coefficient and a significant decrease in thermal conductivity due to nanostructures. The samples were made by first forming alloyed ing

### 89. Title: Search for Thermoelectrics with High Figure of Merit in half-Heusler compounds with multinary substitution
**Authors:** Mukesh K. Choudhary, P Ravindran
**Year:** 2017
**DOI:** 10.1063/1.5029029
**ID:** `p89`

Source: arxiv Abstract: In order to improve the thermoelectric performance of TiCoSb we have substituted 50% of Ti equally with Zr and Hf at Ti site and Sb with Sn and Se equally at Sb site. The electronic structure of Ti0.5Zr0.25Hf0.25CoSn0.5Se0.5 is investigated using the full potential linearized augmented plane wave method and the thermoelectric transport properties are calculated on the basis of semi-classical Boltzmann transport theory. Our band structure calculations show that Ti0.5Zr0.25Hf0.25CoSn0.5Se0.5 has semiconducting behavior with indirect band gap value of 0.98 eV which follow the empirical rule of 18 valence-electron content to bring semiconductivity in half Heusler compounds, indicating that one can have semiconducting behavior in multinary phase of half Heusler compounds

### 90. Title: Phase Boundary Mapping to Obtain n-type Mg3Sb2-Based Thermoelectrics
**DOI:** 10.1016/j.joule.2017.11.005
**ID:** `p90`

Source: sciverse Abstract: Zintl compounds make excellent thermoelectrics with many opportunities for chemically tuning their electronic and thermal transport properties. However, the majority of Zintl compounds are persistently n-type even though computationally they can be used as thermoelectrics. The main advantage of based thermoelectrics have been recently found with exceptionally high figure of merit. Excess Mg is required to make the material n-type, prompting the suspicion that interstitial Mg is responsible. Here we explore the defect chemistry of Mg2Sb2 both theoretically and experimentally to explain why there are two different thermodynamic states in the thermoelectronic regime. In addition, we show that only one can become n-type. This work emphasizes the importance of explori

### 91. Title: Growth and transport properties of Mg3X2 (X = Sb, Bi) single crystals
**Authors:** Jiazhan Xin, Guowei Li, Gudrun Auffermann, Horst Borrmann, Walter Schnelle, Johannes Gooth, Xinbing Zhao, Tiejun Zhu, Claudia Felser, Chenguang Fu
**Year:** 2020
**DOI:** 10.1016/j.mtphys.2018.11.004
**ID:** `p91`

Source: arxiv Abstract: The discovery of high thermoelectric performance in n-type polycrystalline Mg3(Sb,Bi)2 based Zintl compounds has ignited intensive research interest. However, some fundamental questions concerning the anisotropic transport properties and the origin of intrinsically low thermal conductivity are still elusive, requiring the investigation of single crystals. In this work, high-quality p-type Mg3Sb2 and Mg3Bi2 single crystals have been grown by using a self-flux method. The electrical resistivity \r{ho} of Mg3Bi2 single crystal displays an anisotropy with \r{ho} in-plane twice larger than out-of-plane. The low-temperature heat capacity and lattice thermal conductivity of Mg3Sb2 and Mg3Bi2 single crystals have been investigated by using the Debye-Callaway model, from whi

### 92. Title: A Map of the Zintl AM2Pn2 Compounds: Influence of Chemistry on Stability and Electronic Structure
**Authors:** Andrew Pike, Zhenkun Yuan, Gideon Kassa, Muhammad R Hasan, Smitakshi Goswami, Sita Dugu, Shaham Quadir, Andriy Zakutayev, Sage Bauers, Kirill Kovnir, Jifeng Liu, Geoffroy Hautier
**Year:** 2025
**DOI:** 10.1021/acs.chemmater.5c00353
**ID:** `p92`

Source: arxiv Abstract: The AM2Pn2 (A= Ca, Sr, Ba, Yb, Mg; M= Mn, Zn, Cd, Mg; and Pn=N, P, As, Sb, Bi) family of Zintl phases has been known as thermoelectric materials and has recently gained much attention for highly promising materials for solar absorbers in single junction and tandem solar cells. In this paper we will, from first-principles, explore the entire family of AM2Pn2 compounds in terms of their ground state structure, thermodynamic stability, and electronic structure. We also perform photoluminescence spectroscopy on bulk powder and thin film samples to verify our results, including the first measurements of the bandgaps of SrCd2P2 and CaCd2P2. The AM2Pn2 compounds exhibit broad stability, are mostly isostructural in the CaAl2Si2-type structure (P3m1), and cover a wide range 

### 93. Title: N-type Mg3Sb2-Bi with improved thermal stability for thermoelectric power generation
**DOI:** 10.1016/j.actamat.2020.10.035
**ID:** `p93`

Source: sciverse Abstract: The recently discovered n-type Mg<sub>3</sub>Sb<sub>2-</sub><sub>x</sub>Bi<sub>x</sub> alloys with high thermoelectric performance hold great potential for applications in waste heat recovery due to their high average zT in the temperature range between 300 and 773 K. However, systematic studies of their thermal stability remain lacking and are significant for these thermoelectric materials since the possible degradation of their thermoelectric performance could greatly limit their practical applications. Here we studied the thermal stability of the Mg<sub>3</sub>Sb<sub>2-</sub><sub>x</sub>Bi<sub>x</sub> alloys via in situ measurements of their thermoelectric properties at different temperatures, along with microstructural and composition characterizations. Our r

### 94. Title: Scalable synthesis of n-type Mg3Sb2-xBix for thermoelectric applications
**DOI:** 10.1016/j.mtphys.2020.100336
**ID:** `p94`

Source: sciverse Abstract: The highly efficient n-type Mg3Sb2-xBix thermoelectric materials hold great promise for application in power generation as well as refrigeration. Currently, n-type Mg3Sb2-xBix compounds with high zTs can be easily reproduced on a laboratory scale with ∼10 g per batch. However, scaling up the synthesis of Mg3Sb2-xBix with uniform high thermoelectric performance, which is critical for promoting this compound for practical applications, has yet to be achieved. Here we report a scalable preparation method based on Simoloyer ball-milling, which allows us to obtain over 1 kg Mg3.1Sb1.5Bi0.49Te0.01 powder in a single batch. Subsequently, samples with different diameters (ranging from a half inch to two inches) were successfully prepared and their thermoelectric performa

### 95. Title: Thermoelectric performance improvement of p-type Mg3Sb2-based materials by Zn and Ag co-doping
**DOI:** 10.1016/j.mtphys.2021.100564
**ID:** `p95`

Source: sciverse Abstract: Mg3Sb2-based Zintl compounds have attracted extensive attention as potential thermoelectric materials due to their earth-abundant elements. However, pure and intrinsic p-type Mg3Sb2 manifests a poor thermoelectric performance because of its high electrical resistivity. It is reported that Ag doping in Mg sites can increase the mobility and carrier concentration of p-type Mg3Sb2; however, high thermal conductivity still limits the improvement of the ZT value. In the present work, Zn and Ag co-doping in Mg sites was carried out to optimize the thermoelectric performance of p-type Mg3Sb2. Experimental results revealed that the carrier concentration and mobility of Mg3Ag0.01Sb2 significantly increased after Zn doping, leading to an improvement of the power factor. Si

### 96. Title: Optimizing the thermoelectric performance of p-type Mg3Sb2 by Sn doping
**DOI:** 10.1016/j.vacuum.2020.109388
**ID:** `p96`

Source: sciverse Abstract: The effects of Sn doping on thermoelectric performance of Mg<sub>3</sub>Sb<sub>2</sub>-based materials were investigated. First principle calculation results show an increased density of state near the Fermi level and flattened band structure after Sn doping, predicting that the introduction of Sn will enhance the electric transport properties as an effective acceptor dopant. The maximum ZT of Mg<sub>3</sub>Sb<sub>2-x</sub>Sn<sub>x</sub> (0 ≤ x ≤ 0.04) samples is 0.42 at 773 K with x = 0.02. Experiments demonstrate that Sn doping can promote the thermoelectric performance of p-type Mg<sub>3</sub>Sb<sub>2</sub> alloys, however the doping effect is limited by the appearance of n-type Mg<sub>2</sub>Sn during the preparation processes. Consequently, for further enhan

### 97. Title: Realizing Cd and Ag codoping in p-type Mg3Sb2 toward high thermoelectric performance
**DOI:** 10.1016/j.jma.2021.09.012
**ID:** `p97`

Source: sciverse Abstract: Mg3Sb2 has attracted intensive attention as a typical Zintl-type thermoelectric material. Despite the exceptional thermoelectric performance in n-type Mg3Sb2, the dimensionless figure of merit (zT) of p-type Mg3Sb2 remains lower than 1, which is mainly attributed to its inferior electrical properties. Herein, we synergistically optimize the thermoelectric properties of p-type Mg3Sb2 materials via codoping of Cd and Ag, which were synthesized by high-energy ball milling combined with hot pressing. It is found that Cd doping not only increases the carrier mobility of p-type Mg3Sb2, but also diminishes its thermal conductivity (κtot), with Mg2.85Cd0.5Sb2 achieving a low κtot value of ∼0.67 W m−1 K−1 at room temperature. Further Ag doping elevates the carrier concent

### 98. Title: Study on anisotropy of n-type Mg3Sb2-based thermoelectric materials
**DOI:** 10.1063/1.5000053
**ID:** `p98`

Source: sciverse Abstract: The recent discovery of a high thermoelectric figure of merit (ZT) in an n-type Mg3Sb2-based Zintl phase triggered an intense research effort to pursue even higher ZT. Based on our previous report on Mg3.1Nb0.1Sb1.5Bi0.49Te0.01, we report here that partial texturing in the (001) plane is achieved by double hot pressing, which is further confirmed by the rocking curves of the (002) plane. The textured samples of Mg3.1Nb0.1Sb1.5Bi0.49Te0.01 show a much better average performance in the (00l) plane. Hall mobility is significantly improved to ∼105 cm2 V−1 s−1 at room temperature in the (00l) plane due to texturing, resulting in higher electrical conductivity, a higher power factor of ∼18 μW cm−1 K−2 at room temperature, and also higher average ZT. This work shows tha

### 99. Title: Intrinsic thermal stability enhancement in n-type Mg3Sb2 thermoelectrics toward practical applications
**DOI:** 10.1016/j.actamat.2023.118752
**ID:** `p99`

Source: sciverse Abstract: Mg<sub>3</sub>Sb<sub>2</sub>-based Zintl compounds show great promise for thermoelectric power generation due to their favorable properties, such as high thermoelectric performance over a wide range of temperatures, low cost, and mechanical robustness. However, their practical application is severely impeded by the low thermal stability induced by significant Mg loss at elevated temperatures. Here, with the goal to intrinsically enhance the thermal stability of Mg<sub>3</sub>Sb<sub>2</sub>-based materials, a strategy of Mn doping at the Mg site is investigated and is found to be effective. In addition to having a high average zT, Mn-doped Mg<sub>3</sub>Sb<sub>1.5</sub>Bi<sub>0.5</sub> exhibits negligible variation in electrical performance throughout a 40-hour co

### 100. Title: Enhanced average thermoelectric properties of n‑type Mg3Sb2 based materials by mixed-valence Ni doping
**DOI:** 10.1016/j.jallcom.2022.166598
**ID:** `p100`

Source: sciverse Abstract: Due to their high band degeneracy and intrinsic low lattice thermal conductivity, n-type Mg<sub>3</sub>Sb<sub>2</sub>-based thermoelectric materials have drawn a lot of attention in thermoelectric applications in recent years. By using simple and efficient fast induction melting and hot pressing, the n-type Mg<sub>3.5−x</sub>Ni<sub>x</sub>SbBi<sub>0.96</sub>Te<sub>0.04</sub> (x = 0, 0.015, 0.02, 0.03, 0.04, 0.05, and 0.06) samples have been successfully synthesized. The structure of Mg<sub>3.5−x</sub>Ni<sub>x</sub>SbBi<sub>0.96</sub>Te<sub>0.04</sub> samples is examined, as well as their thermoelectric properties. The findings demonstrate that the mixed valence of Ni<sup>2+</sup> and Ni<sup>3+</sup> that occupied distinct Mg sites occurred as the Ni doping level 

### 101. Title: Enhanced Thermoelectric Performance of Indium-Doped n-type Mg3Sb2-Based Materials Synthesized by Rapid Induction Melting
**DOI:** 10.1007/s11664-021-09400-x
**ID:** `p101`

Source: sciverse Abstract: n-type Mg3Sb2-based material is a promising thermoelectric material with less toxicity and more abundance. Herein, we successfully synthesized n-type polycrystalline Mg3.5-xInxSb1.7Bi0.26Te0.04(x = 0, 0.01, 0.02, 0.03, 0.04) samples by rapid induction melting and hot pressing. The effect of indium doping on the thermoelectric properties of Mg3Sb2-based materials was investigated. Indium doping manipulates the grain boundary scattering, resulting in increased electrical conductivity and carrier mobility. Additionally, the lattice disorder induced by In strengthens the phonon scattering and suppresses lattice thermal conductivity. A peak ZT value of 1.27 is obtained at 773 K in the Mg3.47In0.03Sb1.7Bi0.26Te0.04 sample, which is 26% higher than that of the In-free s

### 102. Title: Revealing the temperature-driven Lifshitz transition in <i>p</i>-type Mg3Sb2-based thermoelectric materials
**DOI:** 10.1063/5.0199093
**ID:** `p102`

Source: sciverse Abstract: The manipulation of native atomic defects and their thermal excitations plays vital roles in the thermoelectric performance of Mg3Sb2-based materials. While native defects manipulation has been intensively studied in p-type Mg3Sb2, there exists interesting unsolved issue regarding the abnormal semiconducting electrical behavior in most of samples. In this work, high quality Mg3Sb2 and Mg3Bi2 (00l) films are fabricated by molecular beam epitaxy technique, while variable temperature angle-resolved photoemission spectroscopy and scanning tunneling spectroscopy measurements are utilized for resolving the aforementioned issue. The thermal excitation of Mg interstitials (the electron donor) results in an obvious downshift of valence bands with rising temperature in bot

### 103. Title: Introduction to (p × n)-Type Transverse Thermoelectrics
**DOI:** 10.5772/intechopen.78718
**ID:** `p103`

Source: sciverse Abstract: This chapter will review ( p (cid:1) n )-type transverse thermoelectrics (TTE). Starting with the device advantages of single-leg ( p (cid:1) n )-type TTE ’ s over other thermoelectric paradigms, the theory of ( p (cid:1) n )-type TTE materials is given. Then, the figure of merit, transport equations, and thermoelectric tensors are derived for an anisotropic effective-mass model in bulk three-dimensional materials (3D), quasi-two-dimensional (2D), and quasi-one-dimensional (1D) materials. This chapter concludes with a discussion of the cooling power for transverse thermoelectrics in terms of universal heat flux and electric field scales. The importance of anisotropic ambipolar conductivity for ( p (cid:1) n )-type TTEs highlights the need to explore noncubic, nar

### 104. Title: N-Type Mg3Sb2 (Bi, Te) Alloy Preparation and its Thermoelectric Performance Enhancement
**DOI:** 10.1007/s11665-025-11753-x
**ID:** `p104`

Source: sciverse

### 105. Title: Machine Learning Predictions of Thermopower for Thermoelectric Material Screening
**DOI:** 10.1021/acsaem.5c02609
**ID:** `p105`

Source: sciverse Abstract: Machine or deep learning studies to predict the electronic properties, particularly the Seebeck coefficient, of thermoelectric (TE) materials remain relatively few. Considering the benefits and limitations of these studies, we developed a data-driven, structure-independent machine learning script. The script can produce Seebeck coefficient predictions by using a terminal-executed batch file. Our model within the script was trained with the latest version of the Starry data set, with experimentally derived thermoelectric data. The model was then tested across multiple sets of test sets. Postprediction, we use SHapley Additive exPlanations to analyze the interpretability of our model with chemical insights into features influencing our models’ decisions.

### 106. Title: Machine learning for predicting ultralow thermal conductivity and high ZT in complex thermoelectric materials
**DOI:** 10.48550/arxiv.2405.12143
**ID:** `p106`

Source: sciverse Abstract: Efficient and precise calculations of thermal transport properties and figure of merit, alongside a deep comprehension of thermal transport mechanisms, are essential for the practical utilization of advanced thermoelectric materials. In this study, we explore the microscopic processes governing thermal transport in the distinguished crystalline material Tl$_9$SbTe$_6$ by integrating a unified thermal transport theory with machine learning-assisted self-consistent phonon calculations. Leveraging machine learning potentials, we expedite the analysis of phonon energy shifts, higher-order scattering mechanisms, and thermal conductivity arising from various contributing factors like population and coherence channels. Our finding unveils an exceptionally low thermal co

### 107. Title: Thermoelectric Phase Classification via Machine Learning: Methods, Models, and Materials Discovery Thermoelectric Phase Classification via Mach
**DOI:** 10.13140/rg.2.2.32009.20325
**ID:** `p107`

Source: sciverse

### 108. Title: Robust Machine Learning Framework for Reliable Discovery of High-Performance Half-Heusler Thermoelectrics
**Authors:** Shoeb Athar, Adrien Mecibah, Philippe Jund
**Year:** 2026
**ID:** `p108`

Source: arxiv Abstract: Machine learning (ML) can facilitate efficient thermoelectric (TE) material discovery essential to address the environmental crisis. However, ML models often suffer from poor experimental generalizability despite high metrics. This study presents a robust workflow, applied to the half-Heusler (hH) structural prototype, for figure of merit (zT) prediction, to improve the generalizability of ML models. To resolve challenges in dataset handling and feature filtering, we first introduce a rigorous PCA-based splitting method that ensures training and test sets are unbiased and representative of the full chemical space. We then integrate Bayesian hyperparameter optimization with k-best feature filtering across three architectures-Random Forest, XGBoost, and Neural Network

### 109. Title: Effects of Four-Phonon Scattering and Wave-like Phonon Tunneling Effects on Thermoelectric Properties of Mg2GeSe4 using Machine Learning
**Authors:** Hao-Jen You, Yi-Ting Chiang, Arun Bansil, Hsin Lin
**Year:** 2024
**ID:** `p109`

Source: arxiv Abstract: We present a machine-learning interatomic potential (MLIP) framework, which substantially accelerates the prediction of lattice thermal conductivity for both particle-like and wave-like thermal transport, including three-phonon and four-phonon scattering processes, and achieves speedups of five orders of magnitude compared to the conventional DFT calculations. We illustrate our approach through an in-depth study of Mg2GeSe4 as an exemplar thermoelectric material. Four phonon scattering is found to reduce lattice thermal conductivity by 22.5% at 300K and 26.7% at 900 K. The particle-like contribution to lattice thermal conductivity decreases, while the wave-like component increases with increasing temperature. The maximum figure of merit zT at 900K is found to be 0.4

### 110. Title: Accelerating Multi-Objective Collaborative Optimization of Doped Thermoelectric Materials via Artificial Intelligence
**Authors:** Yuxuan Zeng, Wenhao Xie, Wei Cao, Tan Peng, Yue Hou, Ziyu Wang, Jing Shi
**Year:** 2025
**ID:** `p110`

Source: arxiv Abstract: The thermoelectric performance of materials exhibits complex nonlinear dependencies on both elemental types and their proportions, rendering traditional trial-and-error approaches inefficient and time-consuming for material discovery. In this work, we present a deep learning model capable of accurately predicting thermoelectric properties of doped materials directly from their chemical formulas, achieving state-of-the-art performance. To enhance interpretability, we further incorporate sensitivity analysis techniques to elucidate how physical descriptors affect the thermoelectric figure of merit (zT). Moreover, we establish a coupled framework that integrates a surrogate model with a multi-objective genetic algorithm to efficiently explore the vast compositional spa

### 111. Title: Energy-GNoME: A Living Database of Selected Materials for Energy Applications
**Authors:** Paolo De Angelis, Giovanni Trezza, Giulio Barletta, Pietro Asinari, Eliodoro Chiavazzo
**Year:** 2024
**DOI:** 10.1016/j.egyai.2025.100605
**ID:** `p111`

Source: arxiv Abstract: Artificial Intelligence (AI) in materials science is driving significant advancements in the discovery of advanced materials for energy applications. The recent GNoME protocol identifies over 380,000 novel stable crystals. From this, we identify over 33,000 materials with potential as energy materials forming the Energy-GNoME database. Leveraging Machine Learning (ML) and Deep Learning (DL) tools, our protocol mitigates cross-domain data bias using feature spaces to identify potential candidates for thermoelectric materials, novel battery cathodes, and novel perovskites. Classifiers with both structural and compositional features identify domains of applicability, where we expect enhanced accuracy of the regressors. Such regressors are trained to predict key materia

### 112. Title: Database of Tensorial Optical and Transport Properties of Materials From the Wannier Function Method
**Authors:** Zhenyao Fang, Ting-Wei Hsu, Qimin Yan
**Year:** 2025
**ID:** `p112`

Source: arxiv Abstract: The discovery and design of functional materials for energy harvesting and electronic applications require accurate predictions of their optical and transport properties. While several existing databases contain the first-order optical properties and the electron transport properties calculated from high-throughput first-principles calculations, the amount of material entries is often limited and those functional properties are often reported in scalar form. Comprehensive databases for the tensorial properties still remain inadequate, which prevents from capturing the anisotropic effect in materials and the development of advanced machine learning models that incorporate the space group symmetry of materials. Therefore, in this work we present the largest-to-date da

### 113. Title: Machine-learning guided discovery of a new thermoelectric material
**DOI:** 10.1038/s41598-019-39278-z
**ID:** `p113`

Source: sciverse Abstract: Thermoelectric technologies are becoming indispensable in the quest for a sustainable future. Recently, an emerging phenomenon, the spin-driven thermoelectric effect (STE), has garnered much attention as a promising path towards low cost and versatile thermoelectric technology with easily scalable manufacturing. However, progress in development of STE devices is hindered by the lack of understanding of the fundamental physics and materials properties responsible for the effect. In such nascent scientific field, data-driven approaches relying on statistics and machine learning, instead of more traditional modeling methods, can exhibit their full potential. Here, we use machine learning modeling to establish the key physical parameters controlling STE. Guided by th

### 114. Title: Unsupervised machine learning for discovery of promising half-Heusler thermoelectric materials
**DOI:** 10.1038/s41524-022-00723-9
**ID:** `p114`

Source: sciverse Abstract: Thermoelectric materials can be potentially applied to waste heat recovery and solid-state cooling because they allow a direct energy conversion between heat and electricity and vice versa. The accelerated materials design based on machine learning has enabled the systematic discovery of promising materials. Herein we proposed a successful strategy to discover and design a series of promising half-Heusler thermoelectric materials through the iterative combination of unsupervised machine learning with the labeled known half-Heusler thermoelectric materials. Subsequently, optimized zT values of ~0.5 at 925 K for p-type Sc0.7Y0.3NiSb0.97Sn0.03 and ~0.3 at 778 K for n-type Sc0.65Y0.3Ti0.05NiSb were experimentally achieved on the same parent ScNiSb.

### 115. Title: Machine Learning Regression Guided Thermoelectric Materials Discovery – A Review
**DOI:** 10.30919/esmm5f451
**ID:** `p115`

Source: sciverse Abstract: Thermoelectric materials have increasingly been given attention recently due to their potential of being a solid-state solution in converting heat energy to electricity. Good performing thermoelectric materials are expected to have high electrical conductivity and low thermal conductivity which are usually positively correlated. This poses a challenge in finding suitable candidates. Designing thermoelectric materials often requires evaluating material properties in an iterative manner, which is experimentally and computationally expensive. Machine learning has been regarded as a promising tool to facilitate material design thanks to its fast inference time. In this paper, we summarize recent progress and present the entire workflow in machine learning application

### 116. Title: Thermoelectric Material Performance (<i>zT</i>) Predictions with Machine Learning
**DOI:** 10.1021/acsami.4c19149
**ID:** `p116`

Source: sciverse Abstract: Research efforts using the tools in machine- and deep learning models have begun to show success in predicting target properties such as thermoelectric (TE) properties, including the figure of merit (zT). These models were trained on various data sources that used experimental, crystallographic, and density functional theory (DFT) data. We developed an interpretable model on a huge experimental data set of ∼160,000 data points to predict the performance of thermoelectric materials. The model predicts the results of three different test sets with high accuracy, such as the root-mean-square error (RMSE) ranging from 0.15 to 0.20 and the evaluation coefficients (R2) ranging from 0.80 to 0.67. Furthermore, we highlight probable reasons such as literature error, varie

### 117. Title: Machine learning for predicting ZT values of high-performance thermoelectric materials in mid-temperature range
**DOI:** 10.1063/5.0160055
**ID:** `p117`

Source: sciverse Abstract: Machine learning (ML) is increasingly being adopted to accelerate the development of materials research. In this work, we applied the ML approach to predict the figure-of-merit (ZT) of thermoelectric (TE) materials. The experimental datasets were gathered from 150 published articles for five high-performance TE groups in the mid-temperature range, i.e., PbTe, Co4Sb12, Mg2Si, BiCuSeO, and Cu2Se, resulting in 1563 data points in total. The chemical formulas of individual compounds, including the dopant types and concentrations, were extracted as ML features using the Magpie software. The ZT value was set as the target value. The model was built based on different regression algorithms, and its accuracy for predicting ZT was evaluated using the coefficient of determ

### 118. Title: Machine Learning Approaches for Accelerating the Discovery of Thermoelectric Materials
**DOI:** 10.1021/bk-2022-1416.ch001
**ID:** `p118`

Source: sciverse Abstract: We provide here a summary of how machine learning techniques are being employed for the investigation of thermoelectric behaviour and for identifying new candidate thermoelectric materials. We show that while physics-based computational methods allow increasingly reliable prediction of the electron and phonon transport coefficients that determine the thermoelectric efficiency of materials, such methods are generally too expensive for high-throughput applications. Modern machine learning techniques, which make predictions based on existing data rather than on physical principles, can dramatically accelerate the computational design of thermoelectric materials. Using examples from recent literature, we provide an overview of the approaches that can be used for this

### 119. Title: Discovery of a New Cu-Based Chalcogenide with High zT Near Room Temperature: Low-Cost Alternative for the Bi2Te3-Based Thermoelectrics - resear
**DOI:** 10.58032/agh/n6qtvq
**ID:** `p119`

Source: sciverse Abstract: Copper-based chalcogenides are cost-effective and environmentally friendly thermoelectric (TE) materials for waste heat recovery. Despite demonstrating excellent thermoelectric performance, binary Cu2X (X = S, Se, and Te) chalcogenides undergo superionic phase transitions above room temperature, leading to microstructural evolution and unstable properties. In this work, a new γ-phase of Cu6Te3-xS1+x (0 &lt; x ≤ 1) is discovered, a narrow-bandgap semiconductor with outstanding thermoelectric performance and high stability. By substituting Te with S in metallic Cu6Te3S, the crystal symmetry is modified and structural phase transitions are eliminated. The γ-phase exhibits a significantly higher Seebeck coefficient of up to 200 µVK−1 compared to 8.8 µVK−1 for Cu6Te3S

### 120. Title: Improvement in Thermoelectric Properties and Development of Thermoelectric Devices for Room-Temperature Application
**DOI:** 10.24729/00017771
**ID:** `p120`

Source: sciverse

### 121. Title: A micrometer-thick oxide film with high thermoelectric performance at temperature ranging from 20-400 K
**Authors:** Jikun Chen, Hongyi Chen, Feng Hao, Xinyou Ke, Nuofu Chen, Takeaki Yajima, Yong Jiang, Xun Shi, Kexiong Zhou, Max Döbeli, Tiansong Zhang, Binghui Ge, Hongliang Dong, Huarong Zeng Wenwang Wu, Lidong Che
**Year:** 2017
**ID:** `p121`

Source: arxiv Abstract: Thermoelectric (TE) materials achieve localised conversion between thermal and electric energies, and the conversion efficiency is determined by a figure of merit zT. Up to date, two-dimensional electron gas (2DEG) related TE materials hold the records for zT near room-temperature. A sharp increase in zT up to ~2.0 was observed previously for superlattice materials such as PbSeTe, Bi2Te3/Sb2Te3 and SrNb0.2Ti0.8O3/SrTiO3, when the thicknesses of these TE materials were spatially confine within sub-nanometre scale. The two-dimensional confinement of carriers enlarges the density of states near the Fermi energy3-6 and triggers electron phonon coupling. This overcomes the conventional σ-S trade-off to more independently improve S, and thereby further increases thermoele

### 122. Title: Porosity-mediated High-performance Thermoelectric Materials
**Authors:** Xiaoxi Chen, Siyi Chang, Jin Chen, Pengfei Nan, Hao Wang, Shan Li, Xiyang Li, Xu Chen, Qiulin Liu, Xiaoshan Zhu, Binghui Ge, Wei Cai, Jiehe Sui, Shuqi Zheng, Fangwei Wang, Xiaolong Chen, Huaizhou Zhao
**Year:** 2018
**ID:** `p122`

Source: arxiv Abstract: Whether porosity can effectively improve thermoelectric performance is still an open question. Herein we report that thermoelectric performance can be significantly enhanced by creating porosity in n-type Mg3.225Mn0.025Sb1.5Bi0.49Te0.01, with a ZT of ~0.9 at 323 K and ~1.6 at 723 K, making the average ZT much higher for better performance. The large improvement at room temperature is significant considering that such a ZT value is comparable to the best ZT at this temperature in n-type Bi2Te3. The enhancement was mainly from the improved electrical mobility and multi-scale phonon scattering, particularly from the well-dispersed bismuth nano-precipitates in the porous structure. We further extend this approach to other thermoelectric materials such as half-Heuslers N

### 123. Title: Enhanced figure of merit in nanostructured (Bi, Sb) 2 Te 3 with optimized composition, prepared by a straightforward arc-melting procedure
**Authors:** F Serrano-Sánchez, M Gharsallah, NM Nemes, N Biskup, M Varela, JL Martínez, MT Fernández-Díaz, JA Alonso
**Year:** 2018
**DOI:** 10.1038/s41598-017-05428-4
**ID:** `p123`

Source: arxiv Abstract: Sb-doped Bi2Te3 is known since the 1950s as the best thermoelectric material for near-room temperature operation. Improvements in material performance are expected from nanostructuring procedures. We present a straightforward and fast method to synthesize already nanostructured pellets that show an enhanced ZT due to a remarkably low thermal conductivity and unusually high Seebeck coefficient for a nominal composition optimized for arc-melting: Bi0.35Sb1.65Te3. We provide a detailed structural analysis of the Bi2-xSbxTe3 series based on neutron powder diffraction as a function of composition and temperature that reveals the important role played by atomic vibrations. Arc-melting produces layered platelets with less than 50 nm-thick sheets. The low thermal conductivi

### 124. Title: High Thermoelectric <i>zT</i> in n‐Type Silver Selenide films at Room Temperature
**DOI:** 10.1002/aenm.201702024
**ID:** `p124`

Source: sciverse Abstract: Abstract In this work, a zT value as high as 1.2 at room temperature for n‐type Ag 2 Se films is reported grown by pulsed hybrid reactive magnetron sputtering (PHRMS). PHRMS is a novel technique developed in the lab that allows to grow film of selenides with different compositions in a few minutes with great quality. The improved zT value reported for room temperature results from the combination of the high power factors, similar to the best values reported for bulk Ag 2 Se (2440 ± 192 µW m −1 K −2 ), along with a reduced thermoelectric conductivity as low as 0.64 ± 0.1 W m −1 K −1 . The maximum power factor for these films is of 4655 ± 407 µW m −1 K −2 at 103 °C. This material shows promise to work for room temperature applications. Obtaining high zT or, in oth

### 125. Title: Layered cobalt oxide epitaxial films exhibiting thermoelectric <i>ZT</i> = 0.11 at room temperature
**DOI:** 10.1039/d0ta07565e
**ID:** `p125`

Source: sciverse Abstract: <p>A high <italic>ZT</italic> of 0.11 at room temperature was realized in layered cobalt oxide by substitution of heavy atomic mass Ba.</p>

### 126. Title: Room temperature Bi2Te3-based thermoelectric materials with high performance
**DOI:** 10.1007/s10854-020-03396-6
**ID:** `p126`

Source: sciverse Abstract: Several off-stoichiometric compositions Bi0.5Sb1.5+xTe3+δ (x=0.2; δ=0, 0.12, 0.14) were deliberately synthesized to produce in-situ composites based on compositional engineering approach. The structural characterization of these materials employing XRD, SEM, and HR-TEM reveals the formation of in-situ-composites containing Bi0.5Sb1.5Te3 as matrix phase and minor phases of either Sb rich or Te rich in different compositions. Thermoelectric properties of these Bi0.5Sb1.5+xTe3+δ (x=0.2; δ=0, 0.12, 0.14) composites were studied in a wide range of temperatures extending from room temperature to 500K. The electronic transport of these composites exhibits p-type semiconducting materials. The lowest thermal conductivity of~0.69W/mK @310K was observed for Bi0.5Sb1.7Te3.12

### 127. Title: High-performance near-room-temperature n-type Bi2Te3-based thermoelectric alloys with superior mechanical properties
**DOI:** 10.1007/s40843-024-3058-7
**ID:** `p127`

Source: sciverse Abstract: Hot deformation is an important technique for fabricating high-strength n-type Bi2Te3-based thermoelectric (TE) alloys. However, the poor controllability of the oxygen-induced donor-like effect during the fabrication process often results in an overhigh carrier concentration, significantly worsening the near-room-temperature TE performance. Here, by maximumly avoiding the oxygen-induced donor-like effect, the carrier concentration of n-type TeI4-doped Bi2Te2.7Se0.3 can maintain nearly the optimal one during the repetitive hot deformation processes while the enhanced texture contributes to higher carrier mobility. Moreover, the hot deformation-induced dislocations and local distortions are conducive to lowering the phonon transport. Consequently, a high zT of 1.0 

### 128. Title: High temperature thermoelectric properties of skutterudite-Bi2Te3 nanocomposites
**DOI:** 10.1016/j.intermet.2016.06.007
**ID:** `p128`

Source: sciverse Abstract: Nanocomposite engineering has been proved effective in diverse regimes of material research to attain a performance beyond each constituent phase. In this work, Yb-filled CoSb<sub>3</sub> (bulk matrix/host)-Bi<sub>0.4</sub>Sb<sub>1.6</sub>Te<sub>3</sub> (secondary inclusion) thermoelectric nanocomposites have been synthesized via an ex situ process. Bi<sub>0.4</sub>Sb<sub>1.6</sub>Te<sub>3</sub> inclusions are mainly distributed at the grain boundaries of Yb<sub>0.2</sub>Co<sub>4</sub>Sb<sub>12</sub> matrix in the composites. In particular, Te diffuses in situ from Bi<sub>0.4</sub>Sb<sub>1.6</sub>Te<sub>3</sub> through Yb<sub>0.2</sub>Co<sub>4</sub>Sb<sub>12</sub> matrix during the hot pressing process. This, combined with the grain boundary effect, results in fa

### 129. Title: Room Temperature Broadband Bi2Te3/PbS Colloidal Quantum Dots Infrared Photodetectors
**DOI:** 10.3390/s23094328
**ID:** `p129`

Source: sciverse Abstract: Lead sulfide colloidal quantum dots (PbS CQDs) are promising optoelectronic materials due to their unique properties, such as tunable band gap and strong absorption, which are of immense interest for application in photodetectors and solar cells. However, the tunable band gap of PbS CQDs would only cover visible short-wave infrared; the ability to detect longer wavelengths, such as mid- and long-wave infrared, is limited because they are restricted by the band gap of the bulk material. In this paper, a novel photodetector based on the synergistic effect of PbS CQDs and bismuth telluride (Bi2Te3) was developed for the detection of a mid-wave infrared band at room temperature. The device demonstrated good performance in the visible-near infrared band (i.e., between

### 130. Title: Thermoelectricity: High Thermoelectric <i>zT</i> in n‐Type Silver Selenide films at Room Temperature (Adv. Energy Mater. 8/2018)
**DOI:** 10.1002/aenm.201870033
**ID:** `p130`

Source: sciverse Abstract: In article number 1702024, Marisol Martin-Gonzalez and co-workers, fabricate Ag2Se films with a novel technique (pulsed reactive sputtering). The obtained films are state-of-the-art for this thermoelectric material in applications close to room temperature. This scalable technique and the good quality of the obtained films opens the door to develop a new generation of wearable devices powered by transforming human heat into electricity.

### 131. Title: Phonon dispersions measurements of a high-entropy GeTe-based thermoelectrics with glass-like lattice thermal conductivity
**DOI:** 10.5286/isis.e.rb2610187
**ID:** `p131`

Source: sciverse Abstract: GeTe-based high entropy alloys harbor good electron transport and exhibit glass-like ultralow lattice thermal conductivity, leading to excellent thermoelectric performance. So far, most efforts have been made to improve the TE performance in the system. Still, the microscopic mechanism of the disordered arrangement of atoms, phonon properties, and thermal conductivity has rarely been explicitly explored. Here, we propose to employ the MERLIN spectrometer to run a full map of the phonon dispersion for a high-entropy GeTe compound. Together with powder diffraction measurement and first-principle simulation, it is expected to shed light on the complex mechanism for the effects of high-entropy structure on lattice thermal conductivity.

### 132. Title: Band and Phonon Engineering for Thermoelectric Enhancements of Rhombohedral GeTe
**DOI:** 10.1021/acsami.9b07455
**ID:** `p132`

Source: sciverse Abstract: Rhombohedral GeTe can be approximated as the directional distortion of the cubic GeTe along [111]. Such a symmetry-breaking of the crystal structure results in an opposite arrangement in energy of the L and Σ valence bands, and a split of them into 3L+1Z and 6Σ+6η, respectively. This enables a manipulation of the overall band degeneracy for thermoelectric enhancements through a precise control of the degree of crystal structure deviating from a cubic structure for the alignment of the split bands. Here, we show the effect of AgBiSe2-alloying on the crystal structure as well as thermoelectric transport properties of rhombohedral GeTe. AgBiSe2-alloying is found to not only finely manipulate the crystal structure for band convergence and thereby an increased band de

### 133. Title: Soft Modes and Phonon Anharmonicity in Thermoelectric GeTe
**DOI:** 10.5291/ill-data.7-02-159
**ID:** `p133`

Source: sciverse

### 134. Title: Investigation on the barrier layer of Cu2Se liquid-like thermoelectric material
**DOI:** 10.12442/j.issn.1002-185x.2020.49.4.13521359
**ID:** `p134`

Source: sciverse Abstract: 首先选用Mo为 \\(\\mathrm{CuSe}\\) 的扩散阻抗材料，通过一步正弦热结圈结构的 \\(\\mathrm{CuSe / Mo / CuSe}\\) 三明治结构形式。发现 \\(\\mathrm{CuSe / Mo}\\) 质型界面具有较低的界面接触电阻率，但 \\(\\mathrm{CuSe / Mo}\\) 面界面结合强度较差，不利于器件的长时间稳定工作。随后，在通过Mo层中加入活性元素Mn，利用Mn在 \\(\\mathrm{CuSe / Mo}\\) 中易于扩散的特点，在探极低负荷面接触电阻率的同时，显著提高了异质界面的结合强度。高温后时间老化后， \\(\\mathrm{CuSe / Mo - Mn}\\) 界面仍然保持良好的界面结合和低的界面接触电阻率。表明Mo-Mn金属混合组成为与 \\(\\mathrm{CuSe}\\) 材料相匹配的扩散阻挡层，可以用开发区具有良好服役性能的 \\(\\mathrm{CuSe}\\) 蒸发热电体。

### 135. Title: GeTe Thermoelectrics
**DOI:** 10.1016/j.joule.2020.03.004
**ID:** `p135`

Source: sciverse Abstract: Although GeTe has been known as thermoelectrics since 1960s, it has attracted intensive renewed attention recently. GeTe undergoes a phase transition from a high-T cubic (c-GeTe) to a low-T rhombohedral structure (r-GeTe) through slightly sloping along the [111] direction at -720K. Previous thermoelectrode studies have shown that GeTe is a good candidate for a high-T c-GeTe. r-GeTe has been revealed to show a thermoelectric figure of merit Z as high as that of c-GeTe, because the symmetry breaking electronically induces a diversified rearrangement of split bands for a high band degeneracy and thermally allows hierarchical bonds and microstructures for a low lattice thermal conductivity. This work summarizes the advancements in both r- and c-GeTe and the correspon

### 136. Title: High Thermoelectric Performance in Phonon‐Glass Electron‐Crystal Like AgSbTe<sub>2</sub>
**DOI:** 10.1002/adma.202307058
**ID:** `p136`

Source: sciverse Abstract: Achieving glass-like ultra-low thermal conductivity in crystalline solids with high electrical conductivity, a crucial requirement for high-performance thermoelectrics , continues to be a formidable challenge. A careful balance between electrical and thermal transport is essential for optimizing the thermoelectric performance. Despite this inherent trade-off, the experimental realization of an ideal thermoelectric material with a phonon-glass electron-crystal (PGEC) nature has rarely been achieved. Here, PGEC-like AgSbTe2 is demonstrated by tuning the atomic disorder upon Yb doping, which results in an outstanding thermoelectric performance with figure of merit, zT ≈ 2.4 at 573 K. Yb-doping-induced enhanced atomic ordering decreases the overlap between the hole a

### 137. Title: Solution-Processed Cu2Se Nanocrystal Films with Bulk-Like Thermoelectric Performance
**DOI:** 10.1038/s41598-017-02944-1
**ID:** `p137`

Source: sciverse Abstract: Thermoelectric power generation can play a key role in a sustainable energy future by converting waste heat from power plants and other industrial processes into usable electrical power. Current thermoelectric devices, however, require energy intensive manufacturing processes such as alloying and spark plasma sintering. Here, we describe the fabrication of a p-type thermoelectric material, copper selenide (Cu2Se), utilizing solution-processing and thermal annealing to produce a thin film that achieves a figure of merit, ZT, which is as high as its traditionally processed counterpart, a value of 0.14 at room temperature. This is the first report of a fully solution-processed nanomaterial achieving performance equivalent to its bulk form and represents a general st

### 138. Title: Valence Band Modification and Enhanced Phonon‐Phonon Interactions for High Thermoelectric Performance in GeTe
**DOI:** 10.1002/adfm.202417260
**ID:** `p138`

Source: sciverse Abstract: The strong coupling between carrier and phonon transport in thermoelectric (TE) materials severely limits improvements to the figure of merit (ZT). In this work, an approach is proposed to weaken electron‐phonon coupling, effectively enhancing the TE performance of GeTe. Alloying with Zn4Sb3 reduces excessive carrier concentration (nH), widens the bandgap, and promotes band convergence, synergistically improving charge carrier transport and ensuring a high power factor. Additional Pb doping further optimizes nH, boosting the power factor even more. Moreover, phonon transport is suppressed through Pb doping, as reflected in enhanced acoustic‐optical interactions due to the crossing of optical and acoustic modes, and a reduction in sound group velocity. This reinfo

### 139. Title: Thermal conductivity of thermoelectric material β-Cu2Se: Implications on phonon thermal transport
**DOI:** 10.1063/1.4999405
**ID:** `p139`

Source: sciverse Abstract: Thermal transport properties associated with the thermal structure evolution of β-Cu2Se are studied using density functional theory (DFT) and molecular dynamics (MD) simulations. Thermal conductivity of β-Cu2Se is calculated over a temperature range of 400–1000K using reverse non-equilibrium molecular dynamics simulations. The thermal conductivity found through MD simulations decreases monotonically with increasing temperature, which is in line with the reported experimental data and our calculated DFT data. The average phonon mean free path evaluated using the kinetic theory, found to be within the range of 1.0–1.5A, decreases with increasing temperature. Furthermore, we have investigated the temperature-dependent heat transport phenomena using phonon density of

### 140. Title: Glass‐Like Phonon Dynamics and Thermal Transport in a GeTe Nano‐Composite at Low Temperature
**DOI:** 10.1002/smll.202310209
**ID:** `p140`

Source: sciverse Abstract: In this work, the experimental evidence of glass-like phonon dynamics and thermal conductivity in a nanocomposite made of GeTe and amorphous carbon is reported, which is of interest for microelectronics, and specifically phase change memories. It is shown that, the total thermal conductivity is reduced by a factor of three at room temperature with respect to pure GeTe, due to the reduction of both electronic and phononic contributions. This latter, similarly to glasses, is small and weakly increasing with temperature between 100 and 300 K, indicating a mostly diffusive thermal transport and reaching a value of 0.86(7) Wm-1K-1 at room temperature. A thorough investigation of the nanocomposite's phonon dynamics reveals the appearance of an excess intensity in the l
