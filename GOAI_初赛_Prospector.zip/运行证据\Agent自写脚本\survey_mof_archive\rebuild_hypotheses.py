# 重建 hypotheses.json v2.0：5 旧 + 3 新假设
import json

H = [
{
 "id": "", "title": "MOF-74(Ni)合成条件-微观结构-CO2容量火山形关系",
 "description": "通过冷凝回流与溶剂热两种路线合成MOF-74(Ni)，系统改变合成温度（120-160°C）与时长（6-48 h），定量改变产物中OMS密度、结晶度和缺陷浓度。假设CO2容量与可接触OMS密度及结晶度正相关，但存在最优合成窗口（约140°C、24-48h）。",
 "source_gap_id": "Gap 1",
 "materials": ["MOF-74(Ni)", "Ni-DOBDC"],
 "property": "CO2吸附容量（1 bar, 273 K/298 K）",
 "expected_relationship": "CO2容量随合成温度/时间呈火山形关系；最优窗口对应最大可接触OMS密度和适中缺陷浓度",
 "confidence": 0.97, "novelty_score": 0.75,
 "search_method": "bayesian", "search_iterations": 20, "candidates_explored": 31,
 "external_validation": {}, "validation_status": "pending",
 "evidence_chain": ["p17", "p7", "p1"],
 "llm_plausibility_score": 0.0, "llm_explanation": ""
},
{
 "id": "", "title": "Ni/Co-MOF-74双金属比例-容量非对称协同机制",
 "description": "制备Ni:Co比例为10:0、9:1、6:1、1:1、1:6、1:9、0:10的MOF-74系列。假设容量不是Co含量的单调函数，而在Ni1Co1处出现极大值（8.30 mmol/g），因为Ni和Co在DOBDC链上形成异金属Ni-O-Co交替排列产生更强CO2结合位点。",
 "source_gap_id": "Gap 2",
 "materials": ["Ni_xCo_y-MOF-74"],
 "property": "CO2吸附容量（0 °C, 1 bar）",
 "expected_relationship": "容量序列为Ni1Co1>Ni1Co6>Co>Ni>Ni6Co1；容量与异金属Ni-O-Co对密度正相关",
 "confidence": 0.97, "novelty_score": 0.88,
 "search_method": "bayesian", "search_iterations": 20, "candidates_explored": 31,
 "external_validation": {}, "validation_status": "pending",
 "evidence_chain": ["p29", "p7", "p17"],
 "llm_plausibility_score": 0.0, "llm_explanation": ""
},
{
 "id": "", "title": "胺功能化MOF最佳负载量与孔道结构预测关系",
 "description": "在MIL-101、MOF-177、MOF-808、HP-PMOF等不同孔径/孔容MOF中负载PEI/TEPA/DETA/EDA，系统改变胺负载量（0-100 wt%）。假设最佳胺负载量随初始孔容和孔径增大而线性升高，随胺链长/分子体积增加而下降；胺效率随负载量呈衰减曲线。",
 "source_gap_id": "Gap 3",
 "materials": ["PEI@MIL-101(Cr)", "TEPA@MOF-177", "TEPA@MOF-808", "HP-PMOF-DETA"],
 "property": "低压CO2容量（0.15 bar/400 ppm）及胺效率",
 "expected_relationship": "最佳胺负载量与MOF孔容/孔径正相关，与胺分子体积负相关；超过最佳值后容量下降",
 "confidence": 0.99, "novelty_score": 0.75,
 "search_method": "bayesian", "search_iterations": 20, "candidates_explored": 31,
 "external_validation": {}, "validation_status": "pending",
 "evidence_chain": ["p38", "p40", "p41", "p1", "p135", "p136"],
 "llm_plausibility_score": 0.0, "llm_explanation": ""
},
{
 "id": "", "title": "开放金属位点密度与湿度耐受性的权衡曲线",
 "description": "选择OMS密度不同的同构MOF-74系列（Mg/Ni/Co）以及无OMS的ZIF-94、有化学位点的en-CPM-200、水固定型TYUT-ATZ-β，在0-90% RH模拟烟气下测CO2容量保持率。假设OMS密度越高干态容量越高但湿态保持率越低；最优OMS密度位于中等Qst（约30-40 kJ/mol）区间。",
 "source_gap_id": "Gap 4",
 "materials": ["Mg-MOF-74", "Ni-MOF-74", "Co-MOF-74", "ZIF-94", "en-CPM-200", "TYUT-ATZ-β"],
 "property": "湿态CO2容量保持率（RH 0-90%）",
 "expected_relationship": "OMS密度与湿态容量保持率近似线性负相关；存在最优OMS密度使湿态工作容量最大化",
 "confidence": 0.83, "novelty_score": 0.82,
 "search_method": "bayesian", "search_iterations": 20, "candidates_explored": 31,
 "external_validation": {}, "validation_status": "pending",
 "evidence_chain": ["p30", "p49", "p115", "p104", "p164"],
 "llm_plausibility_score": 0.0, "llm_explanation": ""
},
{
 "id": "", "title": "孔径-压力窗口统一描述：从超微孔DAC到中孔高压捕获",
 "description": "利用CRAFTED数据库（726 MOF的GCMC等温线）及实验数据（ZU-16-Co、SIFSIX-3-Ni、MOF-74(Ni)、agw型）构建孔径-压力-CO2容量三维曲面。假设每个目标压力下CO2容量随孔径呈单峰分布，最优孔径d*随压力降低而减小：0.01 bar→3.5-4.0 Å，0.15 bar→4-6 Å，1 bar→6-10 Å。",
 "source_gap_id": "Gap 5",
 "materials": ["ZU-16-Co", "SIFSIX-3-Ni", "MOF-74(Ni)", "CRAFTED/CoRE MOF数据库材料集"],
 "property": "CO2吸附容量（0.01/0.15/1 bar分压下的最优孔径d*）",
 "expected_relationship": "最优孔径d*与log10(P)负相关；超微孔在低压下因高Qst占优，中孔在中高压下优势显现",
 "confidence": 0.82, "novelty_score": 0.85,
 "search_method": "bayesian", "search_iterations": 20, "candidates_explored": 31,
 "external_validation": {}, "validation_status": "pending",
 "evidence_chain": ["p78", "p82", "p17", "p10", "p151", "p123"],
 "llm_plausibility_score": 0.0, "llm_explanation": ""
},
{
 "id": "", "title": "缺陷类型决定CO2容量效应方向：占位型（甲酸盐）抑制 vs 造孔型（配体缺失）提升",
 "description": "在同一MOF-74骨架上分别引入两类缺陷：(a) DMF分解产生的甲酸盐缺陷（占据/屏蔽OMS）；(b) 配体缺失缺陷（Cl-竞争/调制剂，制造介孔）。假设缺陷效应方向由缺陷化学角色决定而非浓度：甲酸盐缺陷使容量随浓度定量下降（p121），配体缺失缺陷使容量与Qst提升（p122，饱和容量+50%、Qst 36→46 kJ/mol）。存在缺陷浓度-容量非单调关系的分岔点。",
 "source_gap_id": "Gap 7",
 "materials": ["MOF-74(Mg/Ni/Co)", "甲酸缺陷MOF-74", "配体缺失缺陷MOF-74"],
 "property": "CO2吸附容量与Qst（1 bar）",
 "expected_relationship": "缺陷类型（占位vs造孔）是容量效应方向的开关；同类型缺陷浓度-容量关系单调，跨类型则方向相反",
 "confidence": 0.85, "novelty_score": 0.90,
 "search_method": "hybrid", "search_iterations": 0, "candidates_explored": 0,
 "external_validation": {}, "validation_status": "pending",
 "evidence_chain": ["p121", "p122", "p17"],
 "llm_plausibility_score": 0.0, "llm_explanation": ""
},
{
 "id": "", "title": "水效应二象性临界线：吸附机制（物理vs化学）决定水对CO2捕获的符号",
 "description": "系统收集物理吸附MOF（Mg-MOF-74、ELM-11、ZIF）与化学吸附MOF（胺化体系：HP-PMOF-DETA、PEI@MIL-100、MOF-808-AA、mmen-Mg2(dobpdc)、TYUT-ATZ-β）的干/湿态容量数据。假设存在以胺负载量或Qst为横轴的符号翻转临界线：低Qst/低胺负载（物理主导）→水负效应；高胺负载（化学主导）→水正效应（碳酸氢盐路径、胺可及性提升、水固定位点）；中间过渡区存在最优RH。",
 "source_gap_id": "Gap 8",
 "materials": ["Mg-MOF-74", "ELM-11", "HP-PMOF-DETA", "PEI@MIL-100(Cr)", "MOF-808-AA", "mmen-Mg2(dobpdc)", "TYUT-ATZ-β"],
 "property": "湿态/干态CO2容量比（RH 0-90%）",
 "expected_relationship": "水效应符号由吸附机制决定：物理吸附负、化学吸附正；存在Qst或胺负载临界值",
 "confidence": 0.85, "novelty_score": 0.88,
 "search_method": "hybrid", "search_iterations": 0, "candidates_explored": 0,
 "external_validation": {}, "validation_status": "pending",
 "evidence_chain": ["p30", "p49", "p152", "p132", "p135", "p136", "p158", "p164", "p168"],
 "llm_plausibility_score": 0.0, "llm_explanation": ""
},
{
 "id": "", "title": "等温线形状决定循环级性能：阶梯等温线MOF的TSA/VSA工作容量与再生能耗优势",
 "description": "对比阶梯等温线MOF（F4_MIL-140A(Ce)、mmen-Mg2(dobpdc)、二胺接枝体系）与常规Langmuir型MOF（MOF-177、HKUST-1、UiO-66、13X）的循环级性能。假设TSA/VSA工作容量（Δ载量）与等温线阶梯陡度正相关、与再生温度摆幅负相关；MOF-177类弱吸附体在TSA中无正工作容量（p137），而相变MOF在PVSA中恢复率/纯度最优（p154）。",
 "source_gap_id": "Gap 9",
 "materials": ["F4_MIL-140A(Ce)", "mmen-Mg2(dobpdc)", "MOF-177", "HKUST-1", "13X", "CALF-20"],
 "property": "TSA/VSA循环工作容量（Δ载量）与寄生能耗",
 "expected_relationship": "阶梯等温线MOF的工作容量和能耗表现系统优于Langmuir型；工作容量与阶梯压力/陡度强相关",
 "confidence": 0.75, "novelty_score": 0.90,
 "search_method": "hybrid", "search_iterations": 0, "candidates_explored": 0,
 "external_validation": {}, "validation_status": "pending",
 "evidence_chain": ["p137", "p145", "p154", "p128", "p176"],
 "llm_plausibility_score": 0.0, "llm_explanation": ""
}
]

with open("workspace/outputs/literature_survey/discovery/hypotheses.json", "w", encoding="utf-8") as f:
    json.dump(H, f, ensure_ascii=False, indent=2)
print("已重建 hypotheses.json:", len(H), "个假设")
for i, h in enumerate(H):
    print(i, ":", h["title"][:45], "| gap:", h["source_gap_id"], "| status:", h["validation_status"])
